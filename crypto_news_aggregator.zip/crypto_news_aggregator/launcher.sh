#!/bin/bash
set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

C_RESET='\033[0m'; C_RED='\033[0;31m'; C_GREEN='\033[0;32m'; C_YELLOW='\033[0;33m'; C_CYAN='\033[0;36m'; C_BOLD='\033[1m'
echo_header() { echo -e "\n${C_CYAN}${C_BOLD}# $1${C_RESET}"; }
echo_info() { echo -e "${C_GREEN}✓${C_RESET} $1"; }
echo_warn() { echo -e "${C_YELLOW}⚠️${C_RESET} $1"; }
echo_error() { echo -e "${C_RED}✗${C_RESET} $1" >&2; exit 1; }

detect_compose_command() {
    if docker compose version >/dev/null 2>&1; then COMPOSE_CMD="docker compose";
    elif command -v docker-compose >/dev/null 2>&1; then COMPOSE_CMD="docker-compose";
    else echo_error "Docker Compose не найден."; fi
}

clean_deploy() {
    echo_header "1. Остановка и удаление старых контейнеров..."
    $COMPOSE_CMD down --remove-orphans
    echo_info "Старые контейнеры удалены."

    echo_header "2. Принудительная пересборка образов без кэша..."
    $COMPOSE_CMD build --no-cache
    echo_info "Образы успешно пересобраны."

    echo_header "3. Запуск новых сервисов..."
    $COMPOSE_CMD up -d
    echo_info "Сервисы запущены в фоновом режиме."

    echo_header "4. Инициализация/обновление схемы базы данных..."
    # Даем Postgres время на полную инициализацию
    sleep 5
    $COMPOSE_CMD exec aggregator python core/main.py --init-db
    echo_info "Схема базы данных актуальна."
    
    IP_ADDR=$(hostname -I | awk '{print $1}' || echo "localhost")
    echo -e "\n${C_GREEN}${C_BOLD}======================================================="
    echo -e "🎉 СИСТЕМА УСПЕШНО РАЗВЕРНУТА И РАБОТАЕТ 🎉"
    echo -e "=======================================================${C_RESET}"
    echo -e "\n${C_BOLD}➡️  Ваш дашборд доступен по адресу: ${C_CYAN}http://${IP_ADDR}:8080${C_RESET}\n"
}

# ... (остальные функции меню stop, logs, wipe без изменений) ...
main_menu() {
    detect_compose_command
    clear
    echo_header "Панель Управления Проектом 'Атлант' (phrphrphr, v5.0)"
    echo "1. 🚀 Чистый перезапуск (Рекомендуется)"
    echo "2. ⏹️  Остановить сервисы"
    echo "3. 📜 Посмотреть логи"
    read -p "Выберите опцию [1]: " choice; choice=${choice:-1}
    case $choice in 1) clean_deploy ;; 2) $COMPOSE_CMD down ;; 3) $COMPOSE_CMD logs -f ;; esac
}

main_menu