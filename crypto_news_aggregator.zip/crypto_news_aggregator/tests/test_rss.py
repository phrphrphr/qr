"""
Tests for the RSS collector module.
"""

import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, patch, MagicMock
import feedparser

from sources.rss import RSSCollector, process_feed_entry
from core.storage import Article


class TestRSSCollector:
    """Test RSS collector functionality."""
    
    @pytest_asyncio.async_test
    async def test_process_feed_entry(self, mock_config):
        """Test processing a single RSS feed entry."""
        # Mock feed entry
        entry = {
            'title': 'Bitcoin Reaches New High',
            'link': 'https://example.com/bitcoin-high',
            'description': 'Bitcoin has reached $100,000.',
            'published': 'Wed, 18 Jun 2025 12:00:00 GMT',
            'author': 'John Doe'
        }
        
        # Process entry
        with patch('sources.rss.article_repo') as mock_repo:
            mock_repo.find_by_url.return_value = None
            
            article = await process_feed_entry(
                entry, 
                "https://example.com/feed.xml", 
                "Test Feed"
            )
        
        # Verify
        assert article is not None
        assert article.title == 'Bitcoin Reaches New High'
        assert article.url == 'https://example.com/bitcoin-high'
        assert article.source_type == 'rss'
        assert article.source_name == 'Test Feed'
        assert 'Bitcoin has reached $100,000.' in article.cleaned_text
    
    @pytest_asyncio.async_test
    async def test_skip_duplicate_entry(self):
        """Test skipping duplicate RSS entries."""
        entry = {
            'title': 'Test Article',
            'link': 'https://example.com/test',
            'description': 'Test content'
        }
        
        # Mock existing article
        existing_article = Article(url='https://example.com/test')
        
        with patch('sources.rss.article_repo') as mock_repo:
            mock_repo.find_by_url.return_value = existing_article
            
            article = await process_feed_entry(
                entry,
                "https://example.com/feed.xml",
                "Test Feed"
            )
        
        # Should return None for duplicates
        assert article is None
    
    @pytest_asyncio.async_test
    async def test_fetch_feed_with_cache(self):
        """Test fetching RSS feed with caching."""
        mock_feed_content = """<?xml version="1.0"?>
        <rss version="2.0">
            <channel>
                <title>Test Feed</title>
                <item>
                    <title>Test Article</title>
                    <link>https://example.com/test</link>
                </item>
            </channel>
        </rss>"""
        
        async with RSSCollector() as collector:
            with patch('sources.rss.fetch_url') as mock_fetch:
                mock_fetch.return_value = {
                    'status': 200,
                    'content': mock_feed_content,
                    'headers': {'etag': 'test-etag'}
                }
                
                feed_data, error = await collector.fetch_feed_with_cache(
                    "https://example.com/feed.xml"
                )
        
        # Verify
        assert error is None
        assert hasattr(feed_data, 'entries')
        assert len(feed_data.entries) == 1
        assert feed_data.entries[0].title == "Test Article"


@pytest.mark.parametrize("entry_data,expected_valid", [
    (
        {'title': 'Valid Article', 'link': 'https://example.com/valid', 'description': 'Content'},
        True
    ),
    (
        {'title': '', 'link': 'https://example.com/invalid', 'description': 'Content'},
        False  # Empty title
    ),
    (
        {'title': 'No Link Article', 'description': 'Content'},
        False  # Missing link
    ),
])
def test_entry_validation(entry_data, expected_valid):
    """Test RSS entry validation."""
    from sources.rss import ContentExtractor
    
    extractor = ContentExtractor()
    content = extractor.extract_content(entry_data)
    
    # Basic validation
    has_required_fields = bool(entry_data.get('link') and entry_data.get('title'))
    assert (has_required_fields and len(content) > 0) == expected_valid