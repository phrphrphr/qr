"""
Pytest configuration and shared fixtures.
"""

import asyncio
import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, MagicMock
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from core.storage import Base, Article, SourceState
from utils.helpers import load_config


@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def test_db():
    """Create a test database."""
    # Use in-memory SQLite for testing
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    
    # Create tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Create session factory
    TestSessionFactory = sessionmaker(
        engine, class_=AsyncSession, expire_on_commit=False
    )
    
    yield TestSessionFactory
    
    # Cleanup
    await engine.dispose()


@pytest.fixture
def mock_config():
    """Mock configuration for testing."""
    return {
        "sources": {
            "rss": {
                "urls": ["https://example.com/rss.xml"],
                "poll_interval": 300
            },
            "telegram": {
                "api_id": "123456",
                "api_hash": "test_hash",
                "channels": ["test_channel"]
            },
            "exchanges": {
                "bybit": {"enabled": True},
                "binance": {"enabled": True}
            }
        },
        "database": {
            "url": "sqlite+aiosqlite:///:memory:"
        },
        "deduplication": {
            "minhash_threshold": 0.85
        },
        "logging": {
            "level": "DEBUG"
        }
    }


@pytest.fixture
def sample_article():
    """Sample article for testing."""
    return Article(
        source_type="rss",
        source_name="Test Feed",
        url="https://example.com/article/1",
        title="Test Article",
        raw_content="<p>This is a test article content.</p>",
        cleaned_text="This is a test article content.",
        content_hash="abcd1234",
        metadata={"test": True}
    )


@pytest.fixture
def mock_rss_feed():
    """Mock RSS feed data."""
    return """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
    <channel>
        <title>Test Crypto Feed</title>
        <description>Test cryptocurrency news feed</description>
        <link>https://example.com</link>
        <item>
            <title>Bitcoin Price Reaches New High</title>
            <link>https://example.com/article/bitcoin-high</link>
            <description>Bitcoin has reached a new all-time high of $100,000.</description>
            <pubDate>Wed, 18 Jun 2025 12:00:00 GMT</pubDate>
            <guid>https://example.com/article/bitcoin-high</guid>
        </item>
        <item>
            <title>Ethereum 2.0 Update Released</title>
            <link>https://example.com/article/eth-update</link>
            <description>The latest Ethereum 2.0 update brings significant improvements.</description>
            <pubDate>Wed, 18 Jun 2025 10:00:00 GMT</pubDate>
            <guid>https://example.com/article/eth-update</guid>
        </item>
    </channel>
</rss>"""


@pytest.fixture
def mock_telegram_message():
    """Mock Telegram message."""
    mock_msg = MagicMock()
    mock_msg.id = 12345
    mock_msg.text = "🚨 BREAKING: Bitcoin reaches $100,000! #Bitcoin #Crypto"
    mock_msg.date = "2025-06-18T12:00:00Z"
    mock_msg.views = 1000
    mock_msg.forwards = 50
    mock_msg.media = None
    mock_msg.reply_to_msg_id = None
    mock_msg.edit_date = None
    return mock_msg


@pytest.fixture
def mock_exchange_announcement():
    """Mock exchange announcement data."""
    return {
        "id": "12345",
        "title": "Trading Maintenance Notice",
        "content": "We will perform system maintenance on June 18, 2025.",
        "date": "2025-06-18T12:00:00Z",
        "type": "maintenance",
        "url": "https://exchange.com/announcement/12345"
    }