"""
Tests for the content cleaner module.
"""

import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, patch, MagicMock

from processing.cleaner import ArticleCleaner, ContentExtractor
from core.storage import Article


class TestContentExtractor:
    """Test content extraction functionality."""
    
    def test_extract_with_newspaper_basic(self):
        """Test basic content extraction with Newspaper."""
        extractor = ContentExtractor()
        
        # Mock newspaper Article
        with patch('processing.cleaner.NewspaperArticle') as MockArticle:
            mock_article = MagicMock()
            mock_article.title = "Test Article Title"
            mock_article.text = "This is the main article content."
            mock_article.authors = ["John Doe"]
            mock_article.summary = "Article summary"
            mock_article.keywords = ["test", "article"]
            
            MockArticle.return_value = mock_article
            
            result = extractor.extract_with_newspaper(
                "https://example.com/article",
                "<html><body><h1>Test</h1></body></html>"
            )
        
        # Verify
        assert result['title'] == "Test Article Title"
        assert result['text'] == "This is the main article content."
        assert result['authors'] == ["John Doe"]
        assert result['summary'] == "Article summary"
        assert result['keywords'] == ["test", "article"]
        assert result['error'] is None
    
    def test_extract_metadata_from_html(self):
        """Test metadata extraction from HTML."""
        extractor = ContentExtractor()
        
        html_content = """
        <html>
            <head>
                <meta property="og:title" content="OG Title">
                <meta property="og:description" content="OG Description">
                <meta name="author" content="Jane Smith">
                <meta property="article:published_time" content="2025-06-18T12:00:00Z">
            </head>
        </html>
        """
        
        metadata = extractor.extract_metadata(html_content)
        
        # Verify
        assert metadata['og_title'] == "OG Title"
        assert metadata['og_description'] == "OG Description"
        assert metadata['article_author'] == "Jane Smith"
        assert metadata['article_published_time'] == "2025-06-18T12:00:00Z"


class TestArticleCleaner:
    """Test article cleaning functionality."""
    
    @pytest_asyncio.async_test
    async def test_clean_article_success(self):
        """Test successful article cleaning."""
        cleaner = ArticleCleaner()
        
        # Mock the content extraction
        with patch.object(cleaner.extractor, 'extract_with_newspaper') as mock_extract:
            mock_extract.return_value = {
                'title': 'Cleaned Title',
                'text': 'Cleaned article content with more than fifty characters to pass validation.',
                'summary': 'Article summary',
                'keywords': ['crypto', 'bitcoin'],
                'authors': ['Author Name'],
                'error': None
            }
            
            result = await cleaner.clean_article("https://example.com/article")
        
        # Verify
        assert result['error'] is None
        assert result['title'] == 'Cleaned Title'
        assert len(result['cleaned_text']) > 50
        assert 'crypto' in result['keywords']
        assert result['processing_stats']['extraction_method'] == 'newspaper'
    
    @pytest_asyncio.async_test
    async def test_process_telegram_article(self):
        """Test processing Telegram article."""
        cleaner = ArticleCleaner()
        
        # Create test Telegram article
        article = Article(
            id=1,
            source_type='telegram',
            source_name='test_channel',
            url='telegram://test_channel/12345',
            title='Crypto News Update',
            raw_content='🚨 Bitcoin reaches new high! #Bitcoin #Crypto',
            cleaned_text='Bitcoin reaches new high! #Bitcoin #Crypto',
            is_processed=False
        )
        
        with patch.object(cleaner, 'article_repo') as mock_repo:
            mock_repo.update = AsyncMock()
            
            success = await cleaner.process_article(article)
        
        # Verify
        assert success is True
        assert article.is_processed is True
        assert article.summary is not None
        mock_repo.update.assert_called_once()
    
    @pytest_asyncio.async_test
    async def test_enhance_keywords(self):
        """Test keyword enhancement with NLTK."""
        cleaner = ArticleCleaner()
        
        # Test text
        text = """
        Bitcoin and cryptocurrency markets are experiencing significant volatility.
        Ethereum blockchain technology continues to evolve with new developments.
        Trading volume has increased substantially in recent weeks.
        """
        
        # This test will only run if NLTK is available
        try:
            keywords = await cleaner._enhance_keywords(text)
            
            # Should extract meaningful keywords
            assert isinstance(keywords, list)
            # Should filter out common words
            assert 'the' not in keywords
            assert 'and' not in keywords
            
        except AttributeError:
            # NLTK not available, skip test
            pytest.skip("NLTK not available for keyword enhancement")


@pytest.mark.parametrize("text,expected_length", [
    ("Short text.", 1),
    ("This is a longer text with multiple sentences. It should be split properly.", 2),
    ("One. Two. Three. Four. Five sentences total.", 3),  # Should limit to 3
])
@pytest_asyncio.async_test
async def test_generate_summary(text, expected_length):
    """Test summary generation."""
    cleaner = ArticleCleaner()
    
    summary = await cleaner._generate_summary(text, max_sentences=3)
    
    # Count sentences in summary
    sentence_count = len([s for s in summary.split('.') if s.strip()])
    assert sentence_count <= expected_length
    assert len(summary) <= len(text)