"""
Tests for the storage module.
"""

import pytest
import pytest_asyncio
from datetime import datetime, timezone

from core.storage import Article, ArticleRepository, SourceStateRepository


@pytest_asyncio.fixture
async def article_repo(test_db):
    """Article repository with test database."""
    repo = ArticleRepository()
    repo.AsyncSessionFactory = test_db
    return repo


@pytest_asyncio.fixture
async def state_repo(test_db):
    """Source state repository with test database."""
    repo = SourceStateRepository()
    repo.AsyncSessionFactory = test_db
    return repo


class TestArticleRepository:
    """Test ArticleRepository functionality."""
    
    @pytest_asyncio.async_test
    async def test_add_article(self, article_repo, sample_article):
        """Test adding a new article."""
        # Add article
        result = await article_repo.add(sample_article)
        
        # Verify
        assert result.id is not None
        assert result.title == "Test Article"
        assert result.source_type == "rss"
    
    @pytest_asyncio.async_test
    async def test_find_by_url(self, article_repo, sample_article):
        """Test finding article by URL."""
        # Add article
        await article_repo.add(sample_article)
        
        # Find by URL
        found = await article_repo.find_by_url(sample_article.url)
        
        # Verify
        assert found is not None
        assert found.url == sample_article.url
        assert found.title == sample_article.title
    
    @pytest_asyncio.async_test
    async def test_upsert_new_article(self, article_repo, sample_article):
        """Test upserting a new article."""
        # Upsert
        result, created = await article_repo.upsert(sample_article)
        
        # Verify
        assert created is True
        assert result.id is not None
        assert result.title == sample_article.title
    
    @pytest_asyncio.async_test
    async def test_upsert_existing_article(self, article_repo, sample_article):
        """Test upserting an existing article."""
        # Add original article
        await article_repo.add(sample_article)
        
        # Create updated version
        updated_article = Article(
            source_type=sample_article.source_type,
            source_name=sample_article.source_name,
            url=sample_article.url,
            title="Updated Title",
            raw_content=sample_article.raw_content,
            cleaned_text="Updated content"
        )
        
        # Upsert
        result, created = await article_repo.upsert(updated_article)
        
        # Verify
        assert created is False
        assert result.title == "Updated Title"
        assert result.cleaned_text == "Updated content"
    
    @pytest_asyncio.async_test
    async def test_get_statistics(self, article_repo):
        """Test getting article statistics."""
        # Add test articles
        articles = [
            Article(
                source_type="rss",
                source_name="Feed1",
                url=f"https://example.com/article/{i}",
                title=f"Article {i}",
                is_processed=(i % 2 == 0),
                is_duplicate=(i % 3 == 0)
            )
            for i in range(10)
        ]
        
        await article_repo.bulk_add(articles)
        
        # Get statistics
        stats = await article_repo.get_statistics()
        
        # Verify
        assert stats['total_articles'] == 10
        assert stats['processed_articles'] == 5  # Half are processed
        assert stats['duplicate_articles'] >= 3  # Every 3rd is duplicate
        assert 'by_source_type' in stats
        assert stats['by_source_type']['rss'] == 10


class TestSourceStateRepository:
    """Test SourceStateRepository functionality."""
    
    @pytest_asyncio.async_test
    async def test_set_and_get_state(self, state_repo):
        """Test setting and getting state."""
        # Set state
        await state_repo.set_state(
            "rss", 
            "test_feed", 
            "last_message_id", 
            "12345"
        )
        
        # Get state
        result = await state_repo.get_state("rss", "test_feed", "last_message_id")
        
        # Verify
        assert result == "12345"
    
    @pytest_asyncio.async_test
    async def test_update_existing_state(self, state_repo):
        """Test updating existing state."""
        # Set initial state
        await state_repo.set_state("telegram", "channel1", "last_id", "100")
        
        # Update state
        await state_repo.set_state("telegram", "channel1", "last_id", "200")
        
        # Get state
        result = await state_repo.get_state("telegram", "channel1", "last_id")
        
        # Verify
        assert result == "200"
    
    @pytest_asyncio.async_test
    async def test_get_nonexistent_state(self, state_repo):
        """Test getting non-existent state."""
        result = await state_repo.get_state("nonexistent", "source", "key")
        assert result is None