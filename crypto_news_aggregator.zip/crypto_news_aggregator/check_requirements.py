#!/usr/bin/env python3
"""
Скрипт проверки установленных зависимостей.

Автор: phrphrphr
Дата: 2025-06-18 11:12:09 UTC
"""

import sys
import pkg_resources
from pathlib import Path

def check_requirements(requirements_file="requirements.txt"):
    """Проверка установленных зависимостей."""
    print(f"🔍 Проверка зависимостей из {requirements_file}")
    print("=" * 60)
    
    if not Path(requirements_file).exists():
        print(f"❌ Файл {requirements_file} не найден!")
        return False
    
    with open(requirements_file, 'r') as f:
        requirements = f.read().splitlines()
    
    # Фильтруем комментарии и пустые строки
    requirements = [
        req.strip() for req in requirements 
        if req.strip() and not req.strip().startswith('#') and not req.strip().startswith('-r')
    ]
    
    missing = []
    installed = []
    
    for requirement in requirements:
        try:
            pkg_resources.require(requirement)
            installed.append(requirement)
            print(f"✅ {requirement}")
        except (pkg_resources.DistributionNotFound, pkg_resources.VersionConflict) as e:
            missing.append(requirement)
            print(f"❌ {requirement} - {e}")
    
    print("=" * 60)
    print(f"📊 Статистика:")
    print(f"   Установлено: {len(installed)}")
    print(f"   Отсутствует: {len(missing)}")
    print(f"   Всего: {len(requirements)}")
    
    if missing:
        print(f"\n❌ Отсутствующие зависимости:")
        for req in missing:
            print(f"   - {req}")
        print(f"\n💡 Для установки выполните:")
        print(f"   pip install {' '.join(missing)}")
        return False
    else:
        print(f"\n🎉 Все зависимости установлены!")
        return True

if __name__ == "__main__":
    req_file = sys.argv[1] if len(sys.argv) > 1 else "requirements.txt"
    success = check_requirements(req_file)
    sys.exit(0 if success else 1)