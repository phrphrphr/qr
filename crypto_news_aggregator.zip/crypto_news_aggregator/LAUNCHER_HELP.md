# Руководство по использованию лаунчера

## Быстрый старт

### Linux/macOS
```bash
chmod +x launcher.sh
./launcher.sh
```

### Windows
```cmd
launcher.bat
```

## Автоматическая установка
```bash
./launcher.sh --quick-install
```

## Режимы работы

1. **Интерактивный режим** - полноценное меню управления
2. **Быстрая установка** - автоматическая настройка и запуск
3. **Диагностический режим** - проверка системы
4. **Debug режим** - подробное логирование

## Поддерживаемые системы

- ✅ Ubuntu/Debian
- ✅ CentOS/RHEL  
- ✅ macOS
- ✅ Windows 10/11
- ✅ Arch Linux

## Требования

- Docker 20.10+
- Docker Compose 2.0+
- 4GB+ RAM
- 10GB+ свободного места

## Решение проблем

### Docker не запускается
```bash
sudo systemctl start docker
sudo usermod -aG docker $USER
```

### Ошибки разрешений
```bash
sudo chown -R $USER:$USER .
```

### Порты заняты
```bash
sudo netstat -tlpn | grep :5432
sudo netstat -tlpn | grep :6379
```