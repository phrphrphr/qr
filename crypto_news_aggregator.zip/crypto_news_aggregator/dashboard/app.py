import os
import io
import csv
import requests
from flask import Flask, render_template, jsonify, request, Response
from sqlalchemy import create_engine, text, exc
from urllib.parse import urlparse

app = Flask(__name__)
engine = create_engine(os.getenv('DATABASE_URL'))
AGGREGATOR_API_URL = "http://aggregator:5001"

@app.route('/')
def index():
    return render_template('index.html')

# --- API Настроек ---
@app.route('/api/settings', methods=['GET'])
def get_settings():
    """Получает все настройки из БД."""
    with engine.connect() as connection:
        result = connection.execute(text("SELECT key, value FROM settings"))
        settings = {row.key: row.value for row in result}
        return jsonify(settings)

@app.route('/api/settings', methods=['POST'])
def save_settings():
    """Сохраняет или обновляет настройки."""
    data = request.json
    with engine.connect() as connection:
        trans = connection.begin()
        for key, value in data.items():
            if value: # Сохраняем только непустые значения
                stmt = text("""
                    INSERT INTO settings (key, value) VALUES (:key, :value)
                    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;
                """)
                connection.execute(stmt, {"key": key, "value": value})
        trans.commit()
    return jsonify({"success": True, "message": "Настройки успешно сохранены."})

# --- Остальные API без существенных изменений ---
@app.route('/api/data')
def get_data():
    with engine.connect() as connection:
        stats_query = text("SELECT (SELECT COUNT(*) FROM articles) as total, (SELECT COUNT(DISTINCT source_name) FROM sources WHERE is_active = true) as sources;")
        stats = dict(connection.execute(stats_query).fetchone()._mapping)
        articles_query = text("SELECT title, url, source_name, published_at FROM articles ORDER BY published_at DESC LIMIT 50;")
        articles = [dict(row._mapping) for row in connection.execute(articles_query)]
        return jsonify({"stats": stats, "articles": articles})

@app.route('/api/sources', methods=['GET'])
def get_sources():
    with engine.connect() as connection:
        result = connection.execute(text("SELECT id, name, url, type, is_active FROM sources ORDER BY id"))
        return jsonify([dict(row._mapping) for row in result])

@app.route('/api/sources/bulk', methods=['POST'])
def add_sources_bulk():
    data = request.json
    urls = [u.strip() for u in data.get('urls', []) if u.strip()]
    source_type = data.get('type', 'rss')
    added_count = 0
    with engine.connect() as connection:
        trans = connection.begin()
        for url in urls:
            name = urlparse(url).netloc.replace('www.', '').split('.')[0].capitalize()
            stmt = text("INSERT INTO sources (name, url, type, is_active) VALUES (:name, :url, :type, true) ON CONFLICT (url) DO NOTHING")
            result = connection.execute(stmt, {"name": name, "url": url, "type": source_type})
            if result.rowcount > 0: added_count += 1
        trans.commit()
    return jsonify({"success": True, "message": f"Добавлено {added_count} из {len(urls)} источников."})

@app.route('/api/sources/<int:source_id>', methods=['DELETE'])
def delete_source(source_id):
    # ... (код без изменений) ...
    return jsonify({"success": True})

@app.route('/api/actions/start_parsing', methods=['POST'])
def start_parsing():
    # ... (код без изменений) ...
    return jsonify({"success": True})

@app.route('/api/actions/export_csv', methods=['GET'])
def export_csv():
    # ... (код без изменений) ...
    return Response("CSV data")