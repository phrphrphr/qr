document.addEventListener('DOMContentLoaded', function() {
    // --- Элементы DOM ---
    const settingsForm = document.getElementById('settings-form');
    // ... (остальные элементы как раньше)

    // --- Загрузка данных ---
    async function loadSettings() {
        const settings = await apiCall('/api/settings');
        if (settings) {
            for (const key in settings) {
                const input = document.getElementById(key);
                if (input) {
                    input.value = settings[key];
                }
            }
        }
    }

    // --- Обработчики событий ---
    settingsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(settingsForm);
        const settings = Object.fromEntries(formData.entries());
        
        const result = await apiCall('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
        });

        if (result) {
            alert(result.message);
        }
    });

    // ... (остальные обработчики без изменений, как в предыдущем шаге)

    // --- Первоначальная загрузка ---
    function initialLoad() {
        loadData();
        loadSources();
        loadSettings(); // <-- Добавили загрузку настроек
    }

    initialLoad();
    setInterval(loadData, 30000);
});

// --- Вспомогательные функции (apiCall, loadData, loadSources, handleBulkAdd) ---
// Эти функции остаются такими же, как в предыдущем ответе.
// Просто убедитесь, что они присутствуют в вашем файле.
async function apiCall(url, options = {}) { /* ... */ }
async function loadData() { /* ... */ }
async function loadSources() { /* ... */ }
async function handleBulkAdd(form, textareaId, sourceType) { /* ... */ }