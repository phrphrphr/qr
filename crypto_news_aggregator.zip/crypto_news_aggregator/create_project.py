#!/usr/bin/env python3
"""
Автоматическое создание всех файлов проекта.

Автор: phrphrphr
Дата: 2025-06-18 11:53:44 UTC
"""

import os
from pathlib import Path

def create_project_structure():
    """Создание структуры проекта."""
    print("🚀 Создание структуры проекта Crypto News Aggregator")
    print("👤 Пользователь: phrphrphr")
    print("⏰ Время: 2025-06-18 11:53:44 UTC")
    print("=" * 60)
    
    # Создание директорий
    directories = [
        'core',
        'sources', 
        'processing',
        'utils',
        'tests',
        'logs',
        'sessions',
        'data',
        'cache'
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"📁 Создана директория: {directory}")
    
    # Создание __init__.py файлов
    init_dirs = ['core', 'sources', 'processing', 'utils', 'tests']
    for directory in init_dirs:
        init_file = Path(directory) / '__init__.py'
        if not init_file.exists():
            init_file.write_text(f'"""Модуль {directory}."""\n')
            print(f"📄 Создан файл: {init_file}")
    
    print("=" * 60)
    print("✅ Структура проекта создана успешно!")
    print("💡 Теперь скопируйте файлы из чата в соответствующие директории")
    return True

if __name__ == "__main__":
    create_project_structure()