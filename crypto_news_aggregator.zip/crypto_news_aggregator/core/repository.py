from sqlalchemy.orm import sessionmaker
from .storage import Article, get_db_engine

class ArticleRepository:
    def __init__(self, engine):
        self.engine = engine
        self.Session = sessionmaker(bind=engine)

    def find_by_url(self, url):
        with self.Session() as session:
            return session.query(Article).filter_by(url=url).first()

    def add(self, article_data):
        if self.find_by_url(article_data['url']):
            return None # Дубликат

        article = Article(**article_data)
        with self.Session() as session:
            session.add(article)
            session.commit()
            return article