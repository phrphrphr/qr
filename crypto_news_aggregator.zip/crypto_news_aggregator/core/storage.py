import os
from sqlalchemy import create_engine, text, Column, Integer, String, Boolean, DateTime, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Settings(Base):
    """Таблица для хранения настроек и API-ключей."""
    __tablename__ = 'settings'
    key = Column(String, primary_key=True)
    # ВАЖНО: В реальной продакшн-системе это поле должно быть зашифровано.
    # Для простоты примера храним как текст.
    value = Column(String, nullable=False)

class Source(Base):
    __tablename__ = 'sources'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    url = Column(String, nullable=False, unique=True)
    type = Column(String, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

class Article(Base):
    __tablename__ = 'articles'
    id = Column(Integer, primary_key=True)
    source_name = Column(String, nullable=False)
    source_type = Column(String, nullable=False, default='rss')
    url = Column(String, unique=True, nullable=False, index=True)
    title = Column(String, nullable=False)
    raw_content = Column(String)
    cleaned_text = Column(String)
    content_hash = Column(String, index=True)
    published_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, server_default=text('NOW()'))
    is_processed = Column(Boolean, default=False)
    is_duplicate = Column(Boolean, default=False)
    extra_data = Column(JSONB)

class SourceState(Base):
    __tablename__ = 'source_states'
    id = Column(Integer, primary_key=True)
    source_name = Column(String, nullable=False)
    key = Column(String, nullable=False)
    value = Column(String, nullable=False)
    updated_at = Column(DateTime, server_default=text('NOW()'), onupdate=text('NOW()'))
    __table_args__ = (UniqueConstraint('source_name', 'key', name='_source_key_uc'),)

def get_db_engine():
    db_url = os.getenv('DATABASE_URL', f"postgresql+psycopg2://{os.getenv('POSTGRES_USER')}:{os.getenv('POSTGRES_PASSWORD')}@postgres:5432/{os.getenv('POSTGRES_DB')}")
    return create_engine(db_url)

def init_db():
    engine = get_db_engine()
    Base.metadata.create_all(engine)