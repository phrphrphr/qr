import os
import threading
import argparse
from flask import Flask, jsonify
from sqlalchemy import text
from loguru import logger

from core.storage import init_db, get_db_engine
from sources.rss import RssSource

# --- Настройка логирования ---
log_level = os.getenv("LOG_LEVEL", "INFO")
logger.add("logs/aggregator.log", rotation="10 MB", retention="10 days", level=log_level, backtrace=True, diagnose=True)
logger.add(lambda msg: print(msg, end=''), level=log_level) # Дублирование в stdout для Docker logs

app = Flask(__name__)
engine = get_db_engine()

def get_sources_from_db():
    with engine.connect() as connection:
        query = text("SELECT id, name, url, type FROM sources WHERE is_active = true")
        result = connection.execute(query).fetchall()
        return [dict(row._mapping) for row in result]

def run_single_parser(source):
    logger.info(f"Запуск парсера для: {source['name']} ({source['type']})")
    try:
        if source['type'] == 'rss':
            parser = RssSource(name=source['name'], url=source['url'], db_engine=engine)
            parser.run()
        elif source['type'] in ['telegram', 'exchange']:
             logger.warning(f"Парсер для типа '{source['type']}' еще не реализован. Пропуск.")
        else:
             logger.error(f"Неизвестный тип источника: {source['type']}")
        logger.info(f"Успешно завершен парсер для: {source['name']}")
    except Exception as e:
        logger.exception(f"Критическая ошибка в парсере для {source['name']}: {e}")

def run_parsing_job():
    logger.info("="*50)
    logger.info("Получена команда на запуск парсинга...")
    sources = get_sources_from_db()
    if not sources:
        logger.warning("Нет активных источников в базе данных. Пропуск парсинга.")
        return

    threads = []
    for source in sources:
        thread = threading.Thread(target=run_single_parser, args=(source,))
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()
    logger.info("Задача парсинга всех источников завершена.")

@app.route('/actions/start_parsing', methods=['POST'])
def handle_start_parsing():
    threading.Thread(target=run_parsing_job).start()
    return jsonify({"success": True, "message": "Задача парсинга запущена."})

def main():
    parser = argparse.ArgumentParser(description="Crypto News Aggregator")
    parser.add_argument('--init-db', action='store_true', help='Инициализировать/обновить схему БД.')
    args = parser.parse_args()

    if args.init_db:
        logger.info("Инициализация базы данных...")
        init_db()
        logger.success("База данных успешно инициализирована/обновлена.")
        return

    logger.info("Запуск API-сервера для сервиса Агрегатор на порту 5001...")
    app.run(host='0.0.0.0', port=5001)

if __name__ == '__main__':
    main()