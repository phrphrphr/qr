"""
Диспетчер задач для Crypto News Aggregator.

Автор: phrphrphr
Дата: 2025-06-18 11:53:44 UTC
"""

import asyncio
from typing import Dict, Any, List
from loguru import logger


class TaskManager:
    """Менеджер задач."""
    
    def __init__(self):
        self.tasks: Dict[str, asyncio.Task] = {}
        self.stats = {
            'total_runs': 0,
            'successful_runs': 0,
            'failed_runs': 0
        }
    
    def register_task(self, name: str, task: asyncio.Task):
        """Регистрация задачи."""
        self.tasks[name] = task
        logger.debug(f"Задача '{name}' зарегистрирована")
    
    def get_status(self) -> Dict[str, Any]:
        """Получение статуса всех задач."""
        status = {
            'tasks': {},
            'task_summary': {
                'total': len(self.tasks),
                'running': 0,
                'completed': 0,
                'failed': 0
            },
            'stats': self.stats
        }
        
        for name, task in self.tasks.items():
            if task.done():
                if task.exception():
                    task_status = 'failed'
                    status['task_summary']['failed'] += 1
                else:
                    task_status = 'completed'
                    status['task_summary']['completed'] += 1
            else:
                task_status = 'running'
                status['task_summary']['running'] += 1
            
            status['tasks'][name] = {
                'status': task_status,
                'done': task.done()
            }
        
        return status


class Dispatcher:
    """Главный диспетчер системы."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.task_manager = TaskManager()
        self.running = False
    
    async def run(self):
        """Запуск основного цикла диспетчера."""
        logger.info("🎛️ Диспетчер запущен")
        self.running = True
        
        try:
            # Создаем и запускаем демо-задачи
            demo_tasks = [
                self.demo_rss_collector(),
                self.demo_stats_reporter(),
                self.demo_health_checker()
            ]
            
            # Запускаем задачи параллельно
            await asyncio.gather(*demo_tasks, return_exceptions=True)
            
        except Exception as e:
            logger.error(f"Ошибка в диспетчере: {e}")
        finally:
            self.running = False
            logger.info("🎛️ Диспетчер остановлен")
    
    async def demo_rss_collector(self):
        """Демо RSS коллектор."""
        logger.info("📡 Запущен демо RSS коллектор")
        
        try:
            for i in range(5):
                if not self.running:
                    break
                
                logger.info(f"📰 RSS: Симуляция сбора новостей #{i+1}")
                await asyncio.sleep(2)
                
                # Симулируем успешный сбор
                self.task_manager.stats['total_runs'] += 1
                self.task_manager.stats['successful_runs'] += 1
            
            logger.success("✅ Демо RSS коллектор завершен")
            
        except Exception as e:
            logger.error(f"❌ Ошибка в RSS коллекторе: {e}")
            self.task_manager.stats['failed_runs'] += 1
    
    async def demo_stats_reporter(self):
        """Демо отчетчик статистики."""
        logger.info("📊 Запущен демо отчетчик статистики")
        
        try:
            for i in range(3):
                if not self.running:
                    break
                
                status = self.task_manager.get_status()
                logger.info(f"📈 Статистика: всего запусков {status['stats']['total_runs']}")
                await asyncio.sleep(5)
            
            logger.success("✅ Демо отчетчик завершен")
            
        except Exception as e:
            logger.error(f"❌ Ошибка в отчетчике: {e}")
    
    async def demo_health_checker(self):
        """Демо проверка здоровья системы."""
        logger.info("🩺 Запущена демо проверка здоровья")
        
        try:
            for i in range(10):
                if not self.running:
                    break
                
                # Симулируем проверку
                if i % 3 == 0:
                    logger.info("💓 Система здорова")
                
                await asyncio.sleep(3)
            
            logger.success("✅ Проверка здоровья завершена")
            
        except Exception as e:
            logger.error(f"❌ Ошибка проверки здоровья: {e}")
    
    def stop(self):
        """Остановка диспетчера."""
        logger.info("🛑 Получен сигнал остановки диспетчера")
        self.running = False