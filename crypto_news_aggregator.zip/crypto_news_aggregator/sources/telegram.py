"""
Advanced Telegram collector with intelligent message processing and state management.
"""

import asyncio
import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

from telethon import TelegramClient, events
from telethon.errors import (
    ChannelPrivateError, ChannelInvalidError, FloodWaitError,
    SessionPasswordNeededError, PhoneCodeInvalidError
)
from telethon.tl.functions.messages import GetHistoryRequest
from telethon.tl.types import Channel, Chat, User, Message, MessageService
from loguru import logger

from core.storage import Article, ArticleRepository, SourceStateRepository
from utils.helpers import load_config, clean_text, generate_hash, RateLimiter
from utils.logging import PerformanceLogger


class TelegramError(Exception):
    """Custom exception for Telegram operations."""
    pass


class MessageProcessor:
    """Advanced message content processor."""
    
    @staticmethod
    def extract_urls(text: str) -> List[str]:
        """Extract URLs from message text."""
        url_pattern = re.compile(
            r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        )
        return url_pattern.findall(text)
    
    @staticmethod
    def extract_hashtags(text: str) -> List[str]:
        """Extract hashtags from message text."""
        hashtag_pattern = re.compile(r'#\w+')
        return [tag[1:] for tag in hashtag_pattern.findall(text)]  # Remove # symbol
    
    @staticmethod
    def extract_mentions(text: str) -> List[str]:
        """Extract mentions from message text."""
        mention_pattern = re.compile(r'@\w+')
        return [mention[1:] for mention in mention_pattern.findall(text)]  # Remove @ symbol
    
    @staticmethod
    def detect_language(text: str) -> str:
        """Simple language detection based on character patterns."""
        if not text:
            return "unknown"
        
        # Count different character types
        latin_chars = len(re.findall(r'[a-zA-Z]', text))
        cyrillic_chars = len(re.findall(r'[а-яёА-ЯЁ]', text))
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
        arabic_chars = len(re.findall(r'[\u0600-\u06ff]', text))
        
        total_chars = latin_chars + cyrillic_chars + chinese_chars + arabic_chars
        
        if total_chars == 0:
            return "unknown"
        
        # Determine dominant script
        if cyrillic_chars / total_chars > 0.3:
            return "ru"
        elif chinese_chars / total_chars > 0.3:
            return "zh"
        elif arabic_chars / total_chars > 0.3:
            return "ar"
        else:
            return "en"
    
    @staticmethod
    def calculate_engagement_score(message: Message) -> float:
        """Calculate engagement score based on message metrics."""
        score = 0.0
        
        # Base score for views
        if hasattr(message, 'views') and message.views:
            score += min(message.views / 1000, 10)  # Max 10 points for views
        
        # Score for forwards
        if hasattr(message, 'forwards') and message.forwards:
            score += min(message.forwards * 2, 20)  # Max 20 points for forwards
        
        # Score for replies
        if hasattr(message, 'replies') and message.replies:
            score += min(message.replies.replies * 3, 15)  # Max 15 points for replies
        
        # Score for reactions
        if hasattr(message, 'reactions') and message.reactions:
            total_reactions = sum(r.count for r in message.reactions.results)
            score += min(total_reactions * 0.5, 10)  # Max 10 points for reactions
        
        return round(score, 2)
    
    @staticmethod
    def is_relevant_crypto_content(text: str) -> Tuple[bool, float]:
        """
        Determine if content is crypto-related and calculate relevance score.
        
        Returns:
            Tuple of (is_relevant, relevance_score)
        """
        if not text:
            return False, 0.0
        
        text_lower = text.lower()
        
        # Crypto keywords with weights
        crypto_keywords = {
            # High weight keywords
            'bitcoin': 3.0, 'btc': 3.0, 'ethereum': 3.0, 'eth': 3.0,
            'cryptocurrency': 2.5, 'crypto': 2.5, 'blockchain': 2.5,
            'defi': 2.0, 'nft': 2.0, 'altcoin': 2.0, 'stablecoin': 2.0,
            
            # Medium weight keywords
            'trading': 1.5, 'hodl': 1.5, 'mining': 1.5, 'wallet': 1.5,
            'exchange': 1.5, 'binance': 1.5, 'coinbase': 1.5, 'bybit': 1.5,
            
            # Lower weight keywords
            'price': 1.0, 'market': 1.0, 'pump': 1.0, 'dump': 1.0,
            'bull': 1.0, 'bear': 1.0, 'moon': 1.0, 'lambo': 1.0,
        }
        
        # Calculate relevance score
        relevance_score = 0.0
        keyword_count = 0
        
        for keyword, weight in crypto_keywords.items():
            count = text_lower.count(keyword)
            if count > 0:
                relevance_score += count * weight
                keyword_count += count
        
        # Normalize score
        if keyword_count > 0:
            relevance_score = min(relevance_score / len(text.split()) * 100, 100)
        
        # Consider relevant if score > 5.0 or contains high-weight keywords
        is_relevant = (
            relevance_score > 5.0 or 
            any(keyword in text_lower for keyword in ['bitcoin', 'btc', 'ethereum', 'eth'])
        )
        
        return is_relevant, round(relevance_score, 2)


class TelegramCollector:
    """Advanced Telegram message collector with intelligent processing."""
    
    def __init__(self, api_id: str, api_hash: str, session_name: str = "crypto_aggregator"):
        """
        Initialize Telegram collector.
        
        Args:
            api_id: Telegram API ID
            api_hash: Telegram API hash
            session_name: Session file name
        """
        self.api_id = api_id
        self.api_hash = api_hash
        self.session_name = session_name
        
        # Ensure sessions directory exists
        self.sessions_dir = Path("sessions")
        self.sessions_dir.mkdir(exist_ok=True)
        self.session_path = self.sessions_dir / session_name
        
        # Initialize client
        self.client = TelegramClient(str(self.session_path), api_id, api_hash)
        
        # Repositories
        self.article_repo = ArticleRepository()
        self.state_repo = SourceStateRepository()
        
        # Processing components
        self.processor = MessageProcessor()
        self.rate_limiter = RateLimiter(max_calls=30, time_window=60)  # 30 calls per minute
        
        # State tracking
        self.processed_messages: Set[int] = set()
        self.channel_metadata = {}
        self.running = False
        
        logger.info(f"Initialized Telegram collector with session: {session_name}")
    
    async def start(self) -> bool:
        """
        Start Telegram client with proper authentication.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            await self.client.start()
            
            # Get current user info
            me = await self.client.get_me()
            logger.info(f"Telegram client started successfully for user: {me.first_name}")
            
            self.running = True
            return True
            
        except SessionPasswordNeededError:
            logger.error("Two-factor authentication enabled. Please provide password.")
            return False
        except Exception as e:
            logger.error(f"Failed to start Telegram client: {e}")
            return False
    
    async def stop(self):
        """Stop Telegram client gracefully."""
        self.running = False
        if self.client.is_connected():
            await self.client.disconnect()
            logger.info("Telegram client disconnected")
    
    async def resolve_channel(self, channel_identifier: str) -> Optional[Channel]:
        """
        Resolve channel by username, invite link, or ID.
        
        Args:
            channel_identifier: Channel username, invite link, or ID
            
        Returns:
            Channel entity or None if not found
        """
        try:
            # Clean channel identifier
            if channel_identifier.startswith('@'):
                channel_identifier = channel_identifier[1:]
            elif channel_identifier.startswith('t.me/'):
                channel_identifier = channel_identifier.split('/')[-1]
            
            # Get entity
            entity = await self.client.get_entity(channel_identifier)
            
            if isinstance(entity, Channel):
                # Store channel metadata
                metadata = {
                    'id': entity.id,
                    'title': entity.title,
                    'username': entity.username,
                    'participants_count': getattr(entity, 'participants_count', 0),
                    'megagroup': getattr(entity, 'megagroup', False),
                    'verified': getattr(entity, 'verified', False),
                    'scam': getattr(entity, 'scam', False),
                    'restricted': getattr(entity, 'restricted', False),
                    'access_hash': entity.access_hash,
                    'resolved_at': datetime.now(timezone.utc).isoformat()
                }
                
                self.channel_metadata[channel_identifier] = metadata
                
                # Save metadata to database
                await self.state_repo.set_state(
                    'telegram',
                    channel_identifier,
                    'channel_metadata',
                    json.dumps(metadata)
                )
                
                logger.info(f"Resolved channel: {entity.title} (@{entity.username})")
                return entity
            else:
                logger.warning(f"{channel_identifier} is not a channel")
                return None
                
        except (ChannelPrivateError, ChannelInvalidError) as e:
            logger.error(f"Cannot access channel {channel_identifier}: {e}")
            return None
        except Exception as e:
            logger.error(f"Error resolving channel {channel_identifier}: {e}")
            return None
    
    async def get_last_message_id(self, channel_name: str) -> Optional[int]:
        """Get last processed message ID for a channel."""
        try:
            id_str = await self.state_repo.get_state('telegram', channel_name, 'last_message_id')
            return int(id_str) if id_str and id_str.isdigit() else None
        except Exception as e:
            logger.error(f"Error getting last message ID for {channel_name}: {e}")
            return None
    
    async def set_last_message_id(self, channel_name: str, message_id: int):
        """Set last processed message ID for a channel."""
        try:
            metadata = {
                'updated_at': datetime.now(timezone.utc).isoformat(),
                'message_id': message_id
            }
            await self.state_repo.set_state(
                'telegram', 
                channel_name, 
                'last_message_id', 
                str(message_id),
                metadata
            )
        except Exception as e:
            logger.error(f"Error setting last message ID for {channel_name}: {e}")
    
    async def process_message(self, message: Message, channel_name: str) -> Optional[Article]:
        """
        Process Telegram message with advanced content analysis.
        
        Args:
            message: Telegram message object
            channel_name: Channel name
            
        Returns:
            Processed Article or None if not suitable
        """
        try:
            # Skip service messages and messages without text
            if isinstance(message, MessageService) or not message.text:
                return None
            
            # Skip very short messages
            if len(message.text.strip()) < 20:
                return None
            
            # Check crypto relevance
            is_relevant, relevance_score = self.processor.is_relevant_crypto_content(message.text)
            if not is_relevant:
                logger.debug(f"Skipping non-crypto message from {channel_name}")
                return None
            
            # Generate unique URL-like identifier
            url = f"telegram://{channel_name}/{message.id}"
            
            # Check if already processed
            existing = await self.article_repo.find_by_url(url)
            if existing:
                return None
            
            # Clean and process text
            cleaned_text = clean_text(message.text)
            
            # Extract title (first line or first sentence)
            title_match = re.match(r'^(.+?)(?:\n|[.!?])', cleaned_text)
            title = title_match.group(1).strip() if title_match else cleaned_text[:100]
            
            # Limit title length
            if len(title) > 255:
                title = title[:252] + "..."
            
            # Get message timestamp
            published_at = message.date.replace(tzinfo=timezone.utc)
            
            # Process message entities and extract metadata
            urls = self.processor.extract_urls(message.text)
            hashtags = self.processor.extract_hashtags(message.text)
            mentions = self.processor.extract_mentions(message.text)
            language = self.processor.detect_language(message.text)
            engagement_score = self.processor.calculate_engagement_score(message)
            
            # Generate content hash
            content_hash = generate_hash(cleaned_text)
            
            # Comprehensive metadata
            metadata = {
                'message_id': message.id,
                'channel_name': channel_name,
                'urls': urls,
                'hashtags': hashtags,
                'mentions': mentions,
                'language': language,
                'relevance_score': relevance_score,
                'engagement_score': engagement_score,
                'has_media': bool(message.media),
                'views': getattr(message, 'views', None),
                'forwards': getattr(message, 'forwards', None),
                'reply_to_msg_id': message.reply_to_msg_id,
                'grouped_id': getattr(message, 'grouped_id', None),
                'edit_date': message.edit_date.isoformat() if message.edit_date else None,
                'post_author': getattr(message, 'post_author', None),
                'via_bot_id': message.via_bot_id,
                'from_id': message.from_id.user_id if hasattr(message.from_id, 'user_id') else None,
                'channel_metadata': self.channel_metadata.get(channel_name, {})
            }
            
            # Handle reactions if available
            if hasattr(message, 'reactions') and message.reactions:
                reactions = []
                for reaction in message.reactions.results:
                    reactions.append({
                        'emoticon': getattr(reaction.reaction, 'emoticon', ''),
                        'count': reaction.count
                    })
                metadata['reactions'] = reactions
            
            # Create article
            article = Article(
                source_type='telegram',
                source_name=channel_name,
                url=url,
                title=title,
                raw_content=message.text,
                cleaned_text=cleaned_text,
                published_at=published_at,
                date_quality="exact",
                content_hash=content_hash,
                language=language,
                is_processed=False,
                metadata=metadata
            )
            
            # Update word count
            article.update_word_count()
            
            return article
            
        except Exception as e:
            logger.error(f"Error processing Telegram message {message.id} from {channel_name}: {e}")
            return None
    
    async def fetch_channel_history(
        self, 
        channel: Channel, 
        limit: int = 100,
        max_age_hours: int = 24
    ) -> Tuple[List[Article], Dict[str, any]]:
        """
        Fetch message history from channel with intelligent filtering.
        
        Args:
            channel: Channel entity
            limit: Maximum messages to fetch
            max_age_hours: Maximum age of messages to process
            
        Returns:
            Tuple of (articles, stats)
        """
        channel_name = channel.username or f"channel{channel.id}"
        logger.info(f"Fetching messages from Telegram channel: {channel_name}")
        
        stats = {
            'channel_name': channel_name,
            'total_messages': 0,
            'processed_messages': 0,
            'new_articles': 0,
            'skipped_messages': 0,
            'errors': 0,
            'oldest_message_date': None,
            'newest_message_date': None
        }
        
        try:
            # Rate limiting
            await self.rate_limiter.acquire()
            
            # Get last processed message ID
            last_message_id = await self.get_last_message_id(channel_name)
            
            # Calculate age cutoff
            age_cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
            
            # Fetch messages
            messages = []
            offset_id = 0
            newest_id = last_message_id
            
            with PerformanceLogger(f"fetch_telegram_history", channel=channel_name):
                while len(messages) < limit:
                    try:
                        history = await self.client(GetHistoryRequest(
                            peer=channel,
                            offset_id=offset_id,
                            offset_date=None,
                            add_offset=0,
                            limit=min(100, limit - len(messages)),
                            max_id=0,
                            min_id=last_message_id or 0,
                            hash=0
                        ))
                        
                        if not history.messages:
                            break
                        
                        # Filter messages by age
                        for msg in history.messages:
                            if msg.date.replace(tzinfo=timezone.utc) >= age_cutoff:
                                messages.append(msg)
                        
                        offset_id = history.messages[-1].id
                        
                        # Avoid infinite loop
                        if len(history.messages) < 100:
                            break
                            
                    except FloodWaitError as e:
                        logger.warning(f"Flood wait error, sleeping for {e.seconds} seconds")
                        await asyncio.sleep(e.seconds)
                    except Exception as e:
                        logger.error(f"Error fetching history batch: {e}")
                        stats['errors'] += 1
                        break
            
            # Sort messages by ID (ascending)
            messages.sort(key=lambda m: m.id)
            stats['total_messages'] = len(messages)
            
            if messages:
                stats['oldest_message_date'] = messages[0].date.isoformat()
                stats['newest_message_date'] = messages[-1].date.isoformat()
            
            # Process messages
            articles = []
            
            for message in messages:
                stats['processed_messages'] += 1
                
                # Skip if already processed
                if message.id in self.processed_messages:
                    stats['skipped_messages'] += 1
                    continue
                
                # Track newest message ID
                if newest_id is None or message.id > newest_id:
                    newest_id = message.id
                
                try:
                    article = await self.process_message(message, channel_name)
                    if article:
                        # Save article
                        await self.article_repo.add(article)
                        articles.append(article)
                        stats['new_articles'] += 1
                    else:
                        stats['skipped_messages'] += 1
                    
                    # Add to processed set
                    self.processed_messages.add(message.id)
                    
                except Exception as e:
                    stats['errors'] += 1
                    logger.error(f"Error processing message {message.id}: {e}")
            
            # Update last message ID
            if newest_id and (last_message_id is None or newest_id > last_message_id):
                await self.set_last_message_id(channel_name, newest_id)
            
            logger.info(
                f"Processed {stats['processed_messages']} messages from {channel_name}, "
                f"created {stats['new_articles']} articles, "
                f"skipped {stats['skipped_messages']}, "
                f"errors: {stats['errors']}"
            )
            
            return articles, stats
            
        except Exception as e:
            stats['errors'] += 1
            logger.error(f"Critical error fetching history from {channel_name}: {e}")
            return [], stats
    
    async def process_channels(self, channel_names: List[str]) -> Tuple[int, Dict[str, any]]:
        """
        Process multiple channels with comprehensive error handling.
        
        Args:
            channel_names: List of channel identifiers
            
        Returns:
            Tuple of (total_articles, overall_stats)
        """
        overall_stats = {
            'start_time': datetime.now(timezone.utc).isoformat(),
            'total_channels': len(channel_names),
            'processed_channels': 0,
            'total_articles': 0,
            'total_errors': 0,
            'channel_stats': {}
        }
        
        for channel_name in channel_names:
            try:
                # Resolve channel
                channel = await self.resolve_channel(channel_name)
                if not channel:
                    overall_stats['total_errors'] += 1
                    continue
                
                # Fetch and process messages
                articles, channel_stats = await self.fetch_channel_history(channel)
                
                # Update overall stats
                overall_stats['processed_channels'] += 1
                overall_stats['total_articles'] += len(articles)
                overall_stats['total_errors'] += channel_stats['errors']
                overall_stats['channel_stats'][channel_name] = channel_stats
                
            except Exception as e:
                overall_stats['total_errors'] += 1
                logger.error(f"Error processing channel {channel_name}: {e}")
        
        overall_stats['end_time'] = datetime.now(timezone.utc).isoformat()
        return overall_stats['total_articles'], overall_stats


async def listen_for_messages():
    """
    Main Telegram message listener with comprehensive monitoring.
    """
    logger.info("Starting Telegram message listener")
    
    # Load configuration
    config = load_config()
    telegram_config = config.get('sources', {}).get('telegram', {})
    
    # Get credentials
    api_id = telegram_config.get('api_id') or os.environ.get('TELEGRAM_API_ID')
    api_hash = telegram_config.get('api_hash') or os.environ.get('TELEGRAM_API_HASH')
    
    if not api_id or not api_hash:
        logger.error("Telegram API credentials not found. Set TELEGRAM_API_ID and TELEGRAM_API_HASH.")
        return
    
    # Get channel list
    channel_names = telegram_config.get('channels', [])
    if not channel_names:
        logger.warning("No Telegram channels configured. Telegram listener will be inactive.")
        return
    
    # Configuration
    poll_interval = telegram_config.get('poll_interval', 600)  # 10 minutes default
    session_name = telegram_config.get('session_name', 'crypto_aggregator')
    max_age_hours = telegram_config.get('max_message_age_hours', 24)
    
    # Initialize collector
    collector = TelegramCollector(api_id, api_hash, session_name)
    
    try:
        # Start client
        if not await collector.start():
            logger.error("Failed to start Telegram client")
            return
        
        logger.info(f"Monitoring {len(channel_names)} Telegram channels")
        
        # Main polling loop
        while collector.running:
            cycle_start = datetime.now(timezone.utc)
            
            try:
                # Process all channels
                total_articles, cycle_stats = await collector.process_channels(channel_names)
                
                # Log cycle summary
                processing_time = (datetime.now(timezone.utc) - cycle_start).total_seconds()
                logger.info(
                    f"Telegram polling cycle completed: "
                    f"{total_articles} new articles, "
                    f"{cycle_stats['total_errors']} errors, "
                    f"{processing_time:.2f}s"
                )
                
                # Save cycle statistics
                cycle_stats['processing_time'] = processing_time
                state_repo = SourceStateRepository()
                await state_repo.set_state(
                    'telegram',
                    'polling_service',
                    'last_cycle',
                    cycle_stats['end_time'],
                    metadata=cycle_stats
                )
                
            except Exception as e:
                logger.error(f"Error in Telegram polling cycle: {e}")
            
            # Wait for next cycle
            await asyncio.sleep(poll_interval)
            
    finally:
        # Ensure client is stopped
        await collector.stop()