"""
Advanced cryptocurrency exchange collector with comprehensive API support.
"""

import asyncio
import json
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from urllib.parse import urljoin

import aiohttp
import ccxt.async_support as ccxt
from loguru import logger

from core.storage import Article, ArticleRepository, SourceStateRepository
from utils.helpers import (
    load_config, parse_date, clean_text, generate_hash, 
    RateLimiter, fetch_url
)
from utils.logging import PerformanceLogger

# Try to import exchange-specific clients
try:
    from pybit.unified_trading import HTTP as PybitClient
    PYBIT_AVAILABLE = True
except ImportError:
    logger.warning("pybit not available. Using direct API calls for Bybit.")
    PYBIT_AVAILABLE = False

try:
    from binance.spot import Spot as BinanceClient
    from binance.error import BinanceAPIException
    BINANCE_CLIENT_AVAILABLE = True
except ImportError:
    logger.warning("python-binance not available. Using direct API calls for Binance.")
    BINANCE_CLIENT_AVAILABLE = False


class ExchangeError(Exception):
    """Base exception for exchange operations."""
    pass


class AnnouncementProcessor:
    """Process and validate exchange announcements."""
    
    @staticmethod
    def is_valid_announcement(data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Validate announcement data structure.
        
        Args:
            data: Announcement data dictionary
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        required_fields = ['id', 'title']
        
        for field in required_fields:
            if field not in data or not data[field]:
                return False, f"Missing required field: {field}"
        
        # Check for minimum content length
        title = str(data.get('title', ''))
        content = str(data.get('content', '') or data.get('description', ''))
        
        if len(title) < 5:
            return False, "Title too short"
        
        if len(content) < 10:
            return False, "Content too short"
        
        return True, "Valid announcement"
    
    @staticmethod
    def calculate_importance_score(data: Dict[str, Any]) -> float:
        """
        Calculate importance score based on announcement content.
        
        Args:
            data: Announcement data
            
        Returns:
            Importance score (0.0 to 10.0)
        """
        score = 5.0  # Base score
        
        title = str(data.get('title', '')).lower()
        content = str(data.get('content', '') or data.get('description', '')).lower()
        full_text = f"{title} {content}"
        
        # High importance keywords
        high_impact_keywords = [
            'maintenance', 'suspended', 'delisting', 'listing', 'trading halt',
            'withdrawal', 'deposit', 'emergency', 'security', 'hack', 'breach'
        ]
        
        # Medium importance keywords
        medium_impact_keywords = [
            'upgrade', 'update', 'new feature', 'announcement', 'launch',
            'partnership', 'integration', 'promotion', 'bonus', 'reward'
        ]
        
        # Low importance keywords
        low_impact_keywords = [
            'newsletter', 'blog', 'community', 'social', 'event', 'contest'
        ]
        
        # Calculate score adjustments
        for keyword in high_impact_keywords:
            if keyword in full_text:
                score += 2.0
        
        for keyword in medium_impact_keywords:
            if keyword in full_text:
                score += 1.0
        
        for keyword in low_impact_keywords:
            if keyword in full_text:
                score += 0.5
        
        # Adjust based on announcement type/category
        announcement_type = str(data.get('type', '') or data.get('category', '')).lower()
        
        if 'maintenance' in announcement_type or 'system' in announcement_type:
            score += 1.5
        elif 'product' in announcement_type or 'feature' in announcement_type:
            score += 1.0
        elif 'marketing' in announcement_type or 'promotion' in announcement_type:
            score += 0.5
        
        return min(max(score, 0.0), 10.0)  # Clamp between 0 and 10
    
    @staticmethod
    def extract_affected_symbols(data: Dict[str, Any]) -> List[str]:
        """
        Extract cryptocurrency symbols mentioned in announcement.
        
        Args:
            data: Announcement data
            
        Returns:
            List of symbol strings
        """
        symbols = set()
        
        title = str(data.get('title', ''))
        content = str(data.get('content', '') or data.get('description', ''))
        full_text = f"{title} {content}".upper()
        
        # Common crypto symbols pattern
        import re
        symbol_pattern = r'\b([A-Z]{2,8}(?:USD|USDT|BTC|ETH)?)\b'
        potential_symbols = re.findall(symbol_pattern, full_text)
        
        # Filter out common false positives
        false_positives = {
            'API', 'FAQ', 'UTC', 'GMT', 'USD', 'EUR', 'GBP', 'JPY',
            'HTML', 'HTTP', 'HTTPS', 'URL', 'DNS', 'SSL', 'TLS',
            'APP', 'APK', 'IOS', 'MAC', 'WIN', 'PDF', 'CSV', 'JSON'
        }
        
        for symbol in potential_symbols:
            if symbol not in false_positives and len(symbol) >= 2:
                symbols.add(symbol)
        
        return sorted(list(symbols))


class BaseExchangeCollector(ABC):
    """Abstract base class for exchange collectors."""
    
    def __init__(self, exchange_id: str):
        """
        Initialize exchange collector.
        
        Args:
            exchange_id: Unique exchange identifier
        """
        self.exchange_id = exchange_id
        self.article_repo = ArticleRepository()
        self.state_repo = SourceStateRepository()
        self.processor = AnnouncementProcessor()
        self.rate_limiter = RateLimiter(max_calls=30, time_window=60)
        self.session: Optional[aiohttp.ClientSession] = None
        self.ccxt_client = None
        
        logger.info(f"Initialized {exchange_id} collector")
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            headers={'User-Agent': 'CryptoNewsAggregator/1.0'}
        )
        await self.initialize_clients()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.cleanup()
    
    async def initialize_clients(self):
        """Initialize exchange-specific clients."""
        try:
            # Initialize CCXT client
            if hasattr(ccxt, self.exchange_id.lower()):
                exchange_class = getattr(ccxt, self.exchange_id.lower())
                self.ccxt_client = exchange_class({
                    'enableRateLimit': True,
                    'sandbox': False,
                    'timeout': 30000
                })
                logger.debug(f"Initialized CCXT client for {self.exchange_id}")
        except Exception as e:
            logger.warning(f"Failed to initialize CCXT client for {self.exchange_id}: {e}")
    
    async def cleanup(self):
        """Clean up resources."""
        if self.ccxt_client:
            await self.ccxt_client.close()
        if self.session:
            await self.session.close()
    
    async def get_last_announcement_id(self) -> Optional[str]:
        """Get the last processed announcement ID."""
        return await self.state_repo.get_state('exchange', self.exchange_id, 'last_announcement_id')
    
    async def set_last_announcement_id(self, announcement_id: str, metadata: Optional[Dict] = None):
        """Set the last processed announcement ID."""
        await self.state_repo.set_state(
            'exchange', 
            self.exchange_id, 
            'last_announcement_id', 
            announcement_id,
            metadata or {}
        )
    
    async def create_article_from_announcement(self, data: Dict[str, Any]) -> Optional[Article]:
        """
        Create Article object from announcement data.
        
        Args:
            data: Announcement data dictionary
            
        Returns:
            Article object or None if invalid
        """
        try:
            # Validate announcement
            is_valid, error_msg = self.processor.is_valid_announcement(data)
            if not is_valid:
                logger.debug(f"Invalid announcement from {self.exchange_id}: {error_msg}")
                return None
            
            # Extract data
            announcement_id = str(data.get('id'))
            title = str(data.get('title', ''))
            content = str(data.get('content', '') or data.get('description', ''))
            url = data.get('url', '') or self.generate_announcement_url(announcement_id)
            
            # Check if already exists
            existing = await self.article_repo.find_by_url(url)
            if existing:
                return None
            
            # Parse date
            date_str = data.get('date', '') or data.get('releaseDate', '') or data.get('dateTimestamp', '')
            published_at = parse_date(date_str) if date_str else datetime.now(timezone.utc)
            date_quality = "exact" if date_str else "estimated"
            
            # Clean content
            cleaned_text = clean_text(content)
            
            # Generate hash
            content_hash = generate_hash(cleaned_text)
            
            # Calculate importance and extract symbols
            importance_score = self.processor.calculate_importance_score(data)
            affected_symbols = self.processor.extract_affected_symbols(data)
            
            # Create comprehensive metadata
            metadata = {
                'announcement_id': announcement_id,
                'exchange': self.exchange_id,
                'original_data': data,
                'importance_score': importance_score,
                'affected_symbols': affected_symbols,
                'type': data.get('type', ''),
                'category': data.get('category', ''),
                'tags': data.get('tags', []),
                'status': data.get('status', 'active'),
                'language': data.get('language', 'en'),
                'processed_at': datetime.now(timezone.utc).isoformat()
            }
            
            # Create article
            article = Article(
                source_type='exchange',
                source_name=self.exchange_id,
                url=url,
                title=title[:500],  # Limit title length
                raw_content=content,
                cleaned_text=cleaned_text,
                published_at=published_at,
                date_quality=date_quality,
                content_hash=content_hash,
                is_processed=False,
                metadata=metadata
            )
            
            # Update word count
            article.update_word_count()
            
            return article
            
        except Exception as e:
            logger.error(f"Error creating article from {self.exchange_id} announcement: {e}")
            return None
    
    @abstractmethod
    def generate_announcement_url(self, announcement_id: str) -> str:
        """Generate URL for announcement."""
        pass
    
    @abstractmethod
    async def fetch_announcements_data(self) -> Tuple[List[Dict], Optional[str]]:
        """
        Fetch announcements from exchange API.
        
        Returns:
            Tuple of (announcements_list, error_message)
        """
        pass
    
    async def fetch_announcements(self) -> Tuple[List[Article], Dict[str, Any]]:
        """
        Main method to fetch and process announcements.
        
        Returns:
            Tuple of (articles_list, processing_stats)
        """
        stats = {
            'exchange': self.exchange_id,
            'start_time': datetime.now(timezone.utc).isoformat(),
            'total_announcements': 0,
            'new_articles': 0,
            'skipped_announcements': 0,
            'errors': 0,
            'processing_time': 0
        }
        
        start_time = time.time()
        
        try:
            with PerformanceLogger(f"fetch_{self.exchange_id}_announcements"):
                # Rate limiting
                await self.rate_limiter.acquire()
                
                # Fetch data
                announcements_data, error = await self.fetch_announcements_data()
                
                if error:
                    stats['errors'] = 1
                    logger.error(f"Failed to fetch announcements from {self.exchange_id}: {error}")
                    return [], stats
                
                stats['total_announcements'] = len(announcements_data)
                
                # Process announcements
                articles = []
                last_id = await self.get_last_announcement_id()
                newest_id = last_id
                
                for announcement_data in announcements_data:
                    try:
                        announcement_id = str(announcement_data.get('id'))
                        
                        # Skip if already processed
                        if last_id and announcement_id <= last_id:
                            stats['skipped_announcements'] += 1
                            continue
                        
                        # Track newest ID
                        if newest_id is None or announcement_id > newest_id:
                            newest_id = announcement_id
                        
                        # Create article
                        article = await self.create_article_from_announcement(announcement_data)
                        if article:
                            articles.append(article)
                        else:
                            stats['skipped_announcements'] += 1
                            
                    except Exception as e:
                        stats['errors'] += 1
                        logger.error(f"Error processing announcement: {e}")
                
                # Bulk save articles
                if articles:
                    await self.article_repo.bulk_add(articles)
                    stats['new_articles'] = len(articles)
                
                # Update last announcement ID
                if newest_id and newest_id != last_id:
                    await self.set_last_announcement_id(newest_id, {
                        'updated_at': datetime.now(timezone.utc).isoformat(),
                        'total_processed': stats['total_announcements']
                    })
                
                stats['processing_time'] = time.time() - start_time
                
                logger.info(
                    f"Processed {stats['total_announcements']} announcements from {self.exchange_id}, "
                    f"created {stats['new_articles']} articles in {stats['processing_time']:.2f}s"
                )
                
                return articles, stats
                
        except Exception as e:
            stats['errors'] += 1
            stats['processing_time'] = time.time() - start_time
            logger.error(f"Critical error fetching announcements from {self.exchange_id}: {e}")
            return [], stats


class BybitCollector(BaseExchangeCollector):
    """Bybit exchange announcements collector."""
    
    def __init__(self):
        super().__init__('bybit')
        self.api_base = "https://api.bybit.com"
        self.announcements_endpoint = "/v5/announcements/index"
        self.web_base = "https://announcements.bybit.com"
        self.pybit_client = None
    
    async def initialize_clients(self):
        """Initialize Bybit-specific clients."""
        await super().initialize_clients()
        
        if PYBIT_AVAILABLE:
            try:
                self.pybit_client = PybitClient()
                logger.debug("Initialized Pybit client")
            except Exception as e:
                logger.warning(f"Failed to initialize Pybit client: {e}")
    
    def generate_announcement_url(self, announcement_id: str) -> str:
        """Generate Bybit announcement URL."""
        return f"{self.web_base}/en-US/article/{announcement_id}"
    
    async def fetch_announcements_data(self) -> Tuple[List[Dict], Optional[str]]:
        """Fetch announcements from Bybit API."""
        try:
            # Try Pybit client first
            if self.pybit_client:
                try:
                    response = self.pybit_client.get_announcements(
                        locale="en-US",
                        limit=50
                    )
                    
                    if response.get('retCode') == 0:
                        announcements = response.get('result', {}).get('list', [])
                        logger.debug(f"Fetched {len(announcements)} announcements via Pybit")
                        return announcements, None
                    else:
                        logger.warning(f"Pybit API error: {response.get('retMsg', 'Unknown error')}")
                        
                except Exception as e:
                    logger.warning(f"Pybit client failed, falling back to direct API: {e}")
            
            # Fallback to direct API call
            url = f"{self.api_base}{self.announcements_endpoint}"
            params = {
                'locale': 'en-US',
                'limit': 50
            }
            
            result = await fetch_url(
                url,
                session=self.session,
                headers={'Accept': 'application/json'}
            )
            
            if result['status'] == 200 and result['content']:
                data = json.loads(result['content'])
                
                if data.get('retCode') == 0:
                    announcements = data.get('result', {}).get('list', [])
                    logger.debug(f"Fetched {len(announcements)} announcements via direct API")
                    return announcements, None
                else:
                    error_msg = f"API error: {data.get('retMsg', 'Unknown error')}"
                    return [], error_msg
            else:
                return [], f"HTTP error: {result.get('error', result['status'])}"
                
        except Exception as e:
            return [], str(e)


class BinanceCollector(BaseExchangeCollector):
    """Binance exchange announcements collector."""
    
    def __init__(self):
        super().__init__('binance')
        self.api_base = "https://www.binance.com"
        self.announcements_endpoint = "/bapi/composite/v1/public/cms/article/catalog/list/query"
        self.web_base = "https://www.binance.com"
        self.binance_client = None
    
    async def initialize_clients(self):
        """Initialize Binance-specific clients."""
        await super().initialize_clients()
        
        if BINANCE_CLIENT_AVAILABLE:
            try:
                self.binance_client = BinanceClient()
                logger.debug("Initialized Binance client")
            except Exception as e:
                logger.warning(f"Failed to initialize Binance client: {e}")
    
    def generate_announcement_url(self, announcement_id: str) -> str:
        """Generate Binance announcement URL."""
        return f"{self.web_base}/en/support/announcement/{announcement_id}"
    
    async def fetch_announcements_data(self) -> Tuple[List[Dict], Optional[str]]:
        """Fetch announcements from Binance API."""
        try:
            url = f"{self.api_base}{self.announcements_endpoint}"
            params = {
                'catalogId': 48,  # Announcements catalog
                'pageNo': 1,
                'pageSize': 20,
                'rnd': str(int(time.time() * 1000))  # Cache busting
            }
            
            result = await fetch_url(
                url,
                session=self.session,
                headers={
                    'Accept': 'application/json',
                    'Referer': 'https://www.binance.com/en/support/announcement'
                }
            )
            
            if result['status'] == 200 and result['content']:
                data = json.loads(result['content'])
                
                if data.get('success'):
                    announcements = data.get('data', {}).get('articles', [])
                    logger.debug(f"Fetched {len(announcements)} announcements from Binance")
                    return announcements, None
                else:
                    error_msg = f"API error: {data.get('message', 'Unknown error')}"
                    return [], error_msg
            else:
                return [], f"HTTP error: {result.get('error', result['status'])}"
                
        except Exception as e:
            return [], str(e)


class KucoinCollector(BaseExchangeCollector):
    """KuCoin exchange announcements collector."""
    
    def __init__(self):
        super().__init__('kucoin')
        self.api_base = "https://www.kucoin.com"
        self.announcements_endpoint = "/_api/cms/articles"
        self.web_base = "https://www.kucoin.com"
    
    def generate_announcement_url(self, announcement_id: str) -> str:
        """Generate KuCoin announcement URL."""
        return f"{self.web_base}/news/{announcement_id}"
    
    async def fetch_announcements_data(self) -> Tuple[List[Dict], Optional[str]]:
        """Fetch announcements from KuCoin API."""
        try:
            url = f"{self.api_base}{self.announcements_endpoint}"
            params = {
                'category': 'announcement',
                'lang': 'en_US',
                'page': 1,
                'pageSize': 20
            }
            
            result = await fetch_url(
                url,
                session=self.session,
                headers={'Accept': 'application/json'}
            )
            
            if result['status'] == 200 and result['content']:
                data = json.loads(result['content'])
                
                if data.get('success'):
                    announcements = data.get('data', {}).get('items', [])
                    logger.debug(f"Fetched {len(announcements)} announcements from KuCoin")
                    return announcements, None
                else:
                    return [], f"API error: {data.get('msg', 'Unknown error')}"
            else:
                return [], f"HTTP error: {result.get('error', result['status'])}"
                
        except Exception as e:
            return [], str(e)


# Registry of available collectors
EXCHANGE_COLLECTORS = {
    'bybit': BybitCollector,
    'binance': BinanceCollector,
    'kucoin': KucoinCollector
}


async def fetch_announcements():
    """
    Main function to fetch announcements from all configured exchanges.
    """
    logger.info("Starting exchange announcements collection")
    
    # Load configuration
    config = load_config()
    exchanges_config = config.get('sources', {}).get('exchanges', {})
    
    if not exchanges_config:
        logger.warning("No exchanges configured. Exchange collection will be inactive.")
        return
    
    # Configuration
    poll_interval = exchanges_config.get('poll_interval', 3600)  # 1 hour default
    max_concurrent = exchanges_config.get('max_concurrent', 3)
    
    # Initialize enabled collectors
    enabled_collectors = []
    for exchange_id, exchange_config in exchanges_config.items():
        if exchange_id in ('poll_interval', 'max_concurrent'):
            continue
            
        if exchange_config.get('enabled', False):
            if exchange_id in EXCHANGE_COLLECTORS:
                collector_class = EXCHANGE_COLLECTORS[exchange_id]
                enabled_collectors.append((exchange_id, collector_class))
            else:
                logger.warning(f"No collector available for exchange: {exchange_id}")
    
    if not enabled_collectors:
        logger.warning("No exchange collectors enabled.")
        return
    
    logger.info(f"Enabled {len(enabled_collectors)} exchange collectors")
    
    # Main polling loop
    while True:
        cycle_start = time.time()
        cycle_stats = {
            'start_time': datetime.now(timezone.utc).isoformat(),
            'total_exchanges': len(enabled_collectors),
            'processed_exchanges': 0,
            'total_articles': 0,
            'total_errors': 0,
            'exchange_stats': {}
        }
        
        try:
            # Process exchanges with concurrency limit
            semaphore = asyncio.Semaphore(max_concurrent)
            
            async def process_exchange(exchange_id: str, collector_class):
                async with semaphore:
                    async with collector_class() as collector:
                        return await collector.fetch_announcements()
            
            # Create tasks
            tasks = [
                process_exchange(exchange_id, collector_class)
                for exchange_id, collector_class in enabled_collectors
            ]
            
            # Execute tasks
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            for i, result in enumerate(results):
                exchange_id = enabled_collectors[i][0]
                
                if isinstance(result, Exception):
                    cycle_stats['total_errors'] += 1
                    logger.error(f"Error processing {exchange_id}: {result}")
                    cycle_stats['exchange_stats'][exchange_id] = {
                        'error': str(result),
                        'articles': 0
                    }
                else:
                    articles, stats = result
                    cycle_stats['processed_exchanges'] += 1
                    cycle_stats['total_articles'] += len(articles)
                    cycle_stats['total_errors'] += stats.get('errors', 0)
                    cycle_stats['exchange_stats'][exchange_id] = stats
        
        except Exception as e:
            logger.error(f"Critical error in exchange polling cycle: {e}")
            cycle_stats['total_errors'] += 1
        
        # Calculate cycle statistics
        cycle_stats['processing_time'] = time.time() - cycle_start
        cycle_stats['end_time'] = datetime.now(timezone.utc).isoformat()
        
        # Log cycle summary
        logger.info(
            f"Exchange polling cycle completed: "
            f"{cycle_stats['total_articles']} new articles, "
            f"{cycle_stats['total_errors']} errors, "
            f"{cycle_stats['processing_time']:.2f}s"
        )
        
        # Save cycle statistics
        try:
            state_repo = SourceStateRepository()
            await state_repo.set_state(
                'exchange',
                'polling_service',
                'last_cycle',
                cycle_stats['end_time'],
                metadata=cycle_stats
            )
        except Exception as e:
            logger.error(f"Failed to save exchange cycle stats: {e}")
        
        # Wait for next cycle
        sleep_time = max(poll_interval - cycle_stats['processing_time'], 300)  # Minimum 5 minutes
        logger.debug(f"Sleeping for {sleep_time:.0f} seconds until next exchange cycle")
        await asyncio.sleep(sleep_time)