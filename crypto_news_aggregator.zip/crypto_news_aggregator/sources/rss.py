import feedparser
import xxhash
from datetime import datetime
from dateutil.parser import parse as parse_date
from loguru import logger
from core.repository import ArticleRepository

class RssSource:
    def __init__(self, name, url, db_engine):
        self.name = name
        self.url = url
        self.repo = ArticleRepository(db_engine)
        logger.info(f"[RSS: {self.name}] Инициализирован с URL: {self.url}")

    def run(self):
        feed = feedparser.parse(self.url)
        if feed.bozo:
            logger.error(f"[RSS: {self.name}] Ошибка парсинга RSS-ленты: {feed.bozo_exception}")
            return

        for entry in feed.entries:
            try:
                published_time = parse_date(entry.published) if 'published' in entry else datetime.now()
                content = entry.get('summary', entry.get('description', ''))
                
                article_data = {
                    "source_name": self.name,
                    "source_type": "rss",
                    "url": entry.link,
                    "title": entry.title,
                    "raw_content": content,
                    "published_at": published_time,
                    "content_hash": xxhash.xxh64(content).hexdigest()
                }
                
                if not self.repo.add(article_data):
                    logger.trace(f"Дубликат пропущен: {entry.link}")

            except Exception as e:
                logger.exception(f"Не удалось обработать запись из {self.name}: {entry.title}")