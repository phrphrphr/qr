#!/bin/bash

# ==============================================================================
# Самодостаточный установщик для Crypto News Aggregator (версия для архива)
#
# Этот скрипт не требует Git. Он должен быть запущен из корневой
# директории распакованного проекта.
#
# Автор: phrphrphr
# Дата: 2025-06-18 04:10:22 UTC
# Версия: 1.2 (Исправлена проблема с рабочей директорией)
# ==============================================================================

# --- Определение местоположения скрипта и смена директории ---
# Это КЛЮЧЕВОЙ блок для корректной работы. Он гарантирует, что все
# относительные пути будут работать, независимо от того, как запущен скрипт.
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

# --- Конфигурация ---
# Основные файлы для проверки, что мы в правильной директории
REQUIRED_FILES=("docker-compose.yml" "core/main.py" "requirements.txt")

# --- Цвета для вывода ---
C_RESET='\033[0m'
C_RED='\033[0;31m'
C_GREEN='\033[0;32m'
C_YELLOW='\033[0;33m'
C_BLUE='\033[0;34m'
C_CYAN='\033[0;36m'
C_BOLD='\033[1m'

# --- Функции ---
echo_info() {
    echo -e "${C_BLUE}INFO:${C_RESET} $1"
}

echo_success() {
    echo -e "${C_GREEN}${C_BOLD}SUCCESS:${C_RESET} $1"
}

echo_warn() {
    echo -e "${C_YELLOW}WARNING:${C_RESET} $1"
}

echo_error() {
    echo -e "${C_RED}${C_BOLD}ERROR:${C_RESET} $1" >&2
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

ask_confirm() {
    while true; do
        read -p "$1 [y/n]: " yn
        case $yn in
            [Yy]* ) return 0;;
            [Nn]* ) return 1;;
            * ) echo "Пожалуйста, ответьте yes или no.";;
        esac
    done
}

# --- Начало скрипта ---
clear
cat << "EOF"
                                                                    
   ____                  _        __  __           _      _           
  / ___|_ __ _   _ _ __ | |_     |  \/  | __ _ ___| | __ | |__   ___  
 | |   | '__| | | | '_ \| __|____| |\/| |/ _` / __| |/ / | '_ \ / _ \ 
 | |___| |  | |_| | |_) | ||_____| |  | | (_| \__ \   <  | | | |  __/ 
  \____|_|   \__, | .__/ \__|    |_|  |_|\__,_|___/_|\_\ |_| |_|\___| 
             |___/|_|                                               
                                                                    
         --== Установщик Модульного Агрегатора Крипто-Новостей ==--
EOF
echo ""
echo_info "Добро пожаловать! Этот скрипт поможет вам установить и запустить агрегатор."
echo_info "Автор: phrphrphr | Дата: 2025-06-18 04:10:22 UTC"
echo ""

# --- 1. Проверка зависимостей и местоположения ---
echo_info "Шаг 1/5: Проверка зависимостей и целостности проекта..."

# Проверка зависимостей
dependencies=("docker" "docker-compose")
missing_deps=()
for dep in "${dependencies[@]}"; do
    if ! command_exists "$dep"; then
        missing_deps+=("$dep")
    fi
done

if [ ${#missing_deps[@]} -ne 0 ]; then
    echo_error "Обнаружены отсутствующие зависимости: ${missing_deps[*]}"
    echo_info "Пожалуйста, установите их перед продолжением."
    echo_info "Инструкции по установке Docker: https://docs.docker.com/get-docker/"
    exit 1
fi

# Проверка местоположения
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo_error "Не найден необходимый файл: '$file'."
        echo_error "Пожалуйста, убедитесь, что вы запускаете этот скрипт из корневой директории проекта."
        exit 1
    fi
done

echo_success "Все зависимости и файлы проекта найдены."
echo ""

# --- 2. Настройка конфигурации ---
echo_info "Шаг 2/5: Настройка конфигурационных файлов..."

if [ ! -f ".env" ];
then
    if [ -f ".env.example" ]; then
        echo_info "Создание файла .env из .env.example..."
        cp .env.example .env
        echo_success "Файл .env создан."
    else
        echo_error "Файл .env.example не найден. Невозможно создать .env."
        exit 1
    fi
else
    echo_info "Файл .env уже существует."
fi

# Проверка и запрос на заполнение Telegram API ключей
while true; do
    set -o allexport
    source .env > /dev/null 2>&1
    set +o allexport

    if [ -z "$TELEGRAM_API_ID" ] || [ -z "$TELEGRAM_API_HASH" ]; then
        echo_warn "Ваши Telegram API ключи не установлены в файле .env."
        echo_info "Пожалуйста, откройте файл .env в другом окне терминала и введите ваши ключи."
        echo_info "Вы можете получить их на ${C_CYAN}https://my.telegram.org${C_RESET}"
        ask_confirm "Вы заполнили TELEGRAM_API_ID и TELEGRAM_API_HASH в файле .env?"
        if [ $? -ne 0 ]; then
            echo_error "Установка прервана. Пожалуйста, заполните ключи для продолжения."
            exit 1
        fi
    else
        echo_success "Telegram API ключи успешно найдены в .env."
        break
    fi
done
echo ""

echo_info "Вы можете дополнительно настроить источники данных в файле 'core/config.yaml'."
echo ""

# --- 3. Сборка и запуск Docker-контейнеров ---
echo_info "Шаг 3/5: Сборка и запуск Docker-контейнеров..."
if ask_confirm "Готовы начать сборку и запуск Docker-контейнеров?"; then
    echo_info "Сборка Docker-образов... Это может занять несколько минут."
    docker-compose build
    if [ $? -ne 0 ]; then
        echo_error "Сборка Docker-образов не удалась."
        exit 1
    fi
    echo_success "Сборка завершена."
    echo ""

    echo_info "Запуск сервисов в фоновом режиме..."
    docker-compose up -d
    if [ $? -ne 0 ]; then
        echo_error "Не удалось запустить сервисы."
        exit 1
    fi
    echo_success "Сервисы успешно запущены."
    echo ""

    echo_info "Ожидание полной готовности базы данных (20 секунд)..."
    sleep 20
else
    echo_error "Установка отменена пользователем."
    exit 1
fi

# --- 4. Инициализация базы данных ---
echo_info "Шаг 4/5: Инициализация базы данных..."
if ask_confirm "Инициализировать базу данных? (Создаст таблицы, если они не существуют)"; then
    echo_info "Запуск инициализации базы данных..."
    docker-compose run --rm aggregator python core/main.py --init-db
    if [ $? -ne 0 ]; then
        echo_error "Инициализация базы данных не удалась."
        echo_info "Попробуйте запустить команду вручную: docker-compose run --rm aggregator python core/main.py --init-db"
        exit 1
    fi
else
    echo_warn "Инициализация базы данных пропущена. Система может работать некорректно."
fi
echo ""

# --- 5. Завершение ---
echo_info "Шаг 5/5: Завершение установки."
echo ""
echo_success "Установка и запуск Crypto News Aggregator завершены!"
echo ""
echo -e "${C_CYAN}========================= ${C_BOLD}Полезные команды${C_RESET}${C_CYAN} =========================${C_RESET}"
echo -e "  (Выполнять из директории проекта)"
echo ""
echo -e "  - Посмотреть логи агрегатора:  ${C_YELLOW}docker-compose logs -f aggregator${C_RESET}"
echo -e "  - Остановить все сервисы:      ${C_YELLOW}docker-compose down${C_RESET}"
echo -e "  - Посмотреть статистику:       ${C_YELLOW}docker-compose run --rm aggregator python core/main.py --stats${C_RESET}"
echo -e "  - Запустить все сервисы снова: ${C_YELLOW}docker-compose up -d${C_RESET}"
echo -e "${C_CYAN}====================================================================${C_RESET}"
echo ""
echo_info "Для получения рекомендаций по безопасности, масштабированию и поддержке проекта, пожалуйста, ознакомьтесь с файлом RECOMMENDATIONS.md."
echo ""
