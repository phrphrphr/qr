"""
Настройка системы логирования.

Автор: phrphrphr
Дата: 2025-06-18 11:53:44 UTC
"""

import sys
from pathlib import Path
from loguru import logger


def setup_logging(level="INFO", log_file=None):
    """
    Настройка системы логирования.
    
    Args:
        level: Уровень логирования (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Путь к файлу логов (необязательно)
    """
    # Удаляем стандартный обработчик
    logger.remove()
    
    # Консольное логирование с цветами
    logger.add(
        sys.stdout,
        level=level,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        colorize=True
    )
    
    # Файловое логирование
    if log_file is None:
        log_file = "logs/aggregator_{time}.log"
    
    # Создаем директорию для логов, если её нет
    Path(log_file).parent.mkdir(exist_ok=True)
    
    logger.add(
        log_file,
        level=level,
        rotation="1 day",
        retention="30 days",
        compression="zip",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        encoding="utf-8"
    )
    
    logger.info(f"📝 Логирование настроено: уровень {level}")
    return True