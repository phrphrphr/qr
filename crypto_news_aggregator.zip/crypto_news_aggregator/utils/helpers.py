"""
Вспомогательные функции для Crypto News Aggregator.

Автор: phrphrphr
Дата: 2025-06-18 11:53:44 UTC
"""

import yaml
import os
from pathlib import Path
from loguru import logger


def load_config(config_path="core/config.yaml"):
    """Загрузка конфигурации из YAML файла."""
    try:
        config_file = Path(config_path)
        if not config_file.exists():
            logger.warning(f"Файл конфигурации {config_path} не найден, создаю базовую конфигурацию")
            config = get_default_config()
            save_config(config, config_path)
            return config
        
        with open(config_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        logger.debug(f"Конфигурация загружена из {config_path}")
        return config
        
    except Exception as e:
        logger.error(f"Ошибка загрузки конфигурации: {e}")
        return get_default_config()


def save_config(config, config_path="core/config.yaml"):
    """Сохранение конфигурации в YAML файл."""
    try:
        config_file = Path(config_path)
        config_file.parent.mkdir(exist_ok=True)
        
        with open(config_file, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True, indent=2)
        
        logger.info(f"Конфигурация сохранена в {config_path}")
        return True
        
    except Exception as e:
        logger.error(f"Ошибка сохранения конфигурации: {e}")
        return False


def get_default_config():
    """Базовая конфигурация по умолчанию."""
    return {
        'app': {
            'name': 'Crypto News Aggregator',
            'version': '1.0.0',
            'author': 'phrphrphr',
            'created': '2025-06-18 11:53:44 UTC'
        },
        'sources': {
            'rss': {
                'urls': [
                    'https://cointelegraph.com/rss',
                    'https://www.coindesk.com/arc/outboundfeeds/rss/',
                    'https://bitcoinist.com/feed/',
                    'https://decrypt.co/feed'
                ],
                'poll_interval': 1800,
                'max_concurrent_feeds': 5,
                'timeout': 30,
                'enabled': True
            },
            'telegram': {
                'api_id': os.getenv('TELEGRAM_API_ID', ''),
                'api_hash': os.getenv('TELEGRAM_API_HASH', ''),
                'session_name': 'crypto_aggregator',
                'channels': [
                    'cointelegraph',
                    'cryptonews',
                    'bitcoin'
                ],
                'poll_interval': 600,
                'max_message_age_hours': 24,
                'enabled': bool(os.getenv('TELEGRAM_API_ID'))
            },
            'exchanges': {
                'poll_interval': 3600,
                'max_concurrent': 3,
                'timeout': 30,
                'bybit': {'enabled': True},
                'binance': {'enabled': True}
            }
        },
        'database': {
            'url': get_database_url(),
            'pool_size': 20,
            'max_overflow': 40,
            'echo': False,
            'pool_timeout': 30,
            'pool_recycle': 3600
        },
        'processing': {
            'cleaner': {
                'enabled': True,
                'batch_size': 10,
                'timeout': 60
            },
            'deduplication': {
                'enabled': True,
                'minhash_threshold': 0.85,
                'batch_size': 20,
                'cache_refresh_hours': 6
            }
        },
        'logging': {
            'level': os.getenv('LOG_LEVEL', 'INFO'),
            'path': 'logs/agg_{time}.log',
            'rotation': '1 day',
            'retention': '30 days',
            'compression': 'zip'
        }
    }


def get_database_url():
    """Получение URL базы данных из переменных окружения."""
    # Проверяем, запускаемся ли мы в Docker
    if os.path.exists('/.dockerenv') or os.getenv('DOCKER_CONTAINER'):
        # В Docker контейнере используем имя сервиса
        host = 'postgres'
    else:
        # Локально используем localhost
        host = 'localhost'
    
    user = os.getenv('POSTGRES_USER', 'cryptonews')
    password = os.getenv('POSTGRES_PASSWORD', 'cryptonews')
    db = os.getenv('POSTGRES_DB', 'cryptonews')
    port = os.getenv('POSTGRES_PORT', '5432')
    
    return f'postgresql+asyncpg://{user}:{password}@{host}:{port}/{db}'


def clean_text(text):
    """Очистка текста от лишних символов."""
    if not text:
        return ""
    
    # Базовая очистка
    text = str(text).strip()
    text = ' '.join(text.split())  # Удаление лишних пробелов
    
    return text


def ensure_directories():
    """Создание необходимых директорий."""
    directories = ['logs', 'sessions', 'data', 'cache', 'core']
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
    
    logger.debug(f"Директории созданы: {', '.join(directories)}")
    return True


def get_system_info():
    """Получение информации о системе."""
    import platform
    import psutil
    
    try:
        info = {
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'cpu_count': psutil.cpu_count(),
            'memory_total': f"{psutil.virtual_memory().total // 1024**3}GB",
            'disk_free': f"{psutil.disk_usage('/').free // 1024**3}GB"
        }
        return info
    except Exception as e:
        logger.warning(f"Не удалось получить информацию о системе: {e}")
        return {}