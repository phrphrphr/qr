#!/bin/bash

# ==============================================================================
# Автозапуск Crypto News Aggregator
#
# Автор: phrphrphr  
# Дата: 2025-06-18 11:00:44 UTC
# ==============================================================================

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

echo "🚀 Автозапуск Crypto News Aggregator"
echo "Время: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Пользователь: phrphrphr"

# Проверка существования лаунчера
if [ ! -f "launcher.sh" ]; then
    echo "❌ launcher.sh не найден"
    exit 1
fi

# Запуск с автоустановкой
chmod +x launcher.sh
./launcher.sh --quick-install

# Проверка результата
if [ $? -eq 0 ]; then
    echo "✅ Система запущена успешно"
    echo "📊 Для мониторинга используйте: ./launcher.sh"
else
    echo "❌ Ошибка запуска системы"
    exit 1
fi