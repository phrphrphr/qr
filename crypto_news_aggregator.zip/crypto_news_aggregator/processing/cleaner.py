"""
Advanced content cleaning and NLP processing with Newspaper4k and custom enhancements.
"""

import asyncio
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Union
from urllib.parse import urlparse

from newspaper import Article as NewspaperArticle, Config as NewspaperConfig
from loguru import logger

from core.storage import Article, ArticleRepository, ProcessingQueue
from utils.helpers import parse_date, clean_text, generate_hash, extract_domain
from utils.logging import PerformanceLogger

# Try to import optional dependencies
try:
    from playwright.async_api import async_playwright, Browser, Page
    PLAYWRIGHT_AVAILABLE = True
    logger.info("Playwright available for JavaScript rendering")
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    logger.warning("Playwright not available. JS-heavy sites may not render properly.")

try:
    import nltk
    from nltk.tokenize import sent_tokenize, word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False
    logger.warning("NLTK not available. Advanced NLP features disabled.")

try:
    from textstat import flesch_reading_ease, flesch_kincaid_grade, automated_readability_index
    TEXTSTAT_AVAILABLE = True
except ImportError:
    TEXTSTAT_AVAILABLE = False
    logger.warning("textstat not available. Readability analysis disabled.")


class ContentCleaningError(Exception):
    """Exception raised during content cleaning operations."""
    pass


class ReadabilityAnalyzer:
    """Analyze text readability and complexity."""
    
    @staticmethod
    def analyze_readability(text: str) -> Dict[str, Any]:
        """
        Analyze text readability using multiple metrics.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with readability metrics
        """
        if not text or not TEXTSTAT_AVAILABLE:
            return {}
        
        try:
            metrics = {
                'flesch_reading_ease': flesch_reading_ease(text),
                'flesch_kincaid_grade': flesch_kincaid_grade(text),
                'automated_readability_index': automated_readability_index(text),
                'word_count': len(text.split()),
                'sentence_count': len(sent_tokenize(text)) if NLTK_AVAILABLE else text.count('.'),
                'avg_words_per_sentence': 0,
                'complexity_level': 'unknown'
            }
            
            # Calculate average words per sentence
            if metrics['sentence_count'] > 0:
                metrics['avg_words_per_sentence'] = round(
                    metrics['word_count'] / metrics['sentence_count'], 2
                )
            
            # Determine complexity level
            flesch_score = metrics['flesch_reading_ease']
            if flesch_score >= 90:
                metrics['complexity_level'] = 'very_easy'
            elif flesch_score >= 80:
                metrics['complexity_level'] = 'easy'
            elif flesch_score >= 70:
                metrics['complexity_level'] = 'fairly_easy'
            elif flesch_score >= 60:
                metrics['complexity_level'] = 'standard'
            elif flesch_score >= 50:
                metrics['complexity_level'] = 'fairly_difficult'
            elif flesch_score >= 30:
                metrics['complexity_level'] = 'difficult'
            else:
                metrics['complexity_level'] = 'very_difficult'
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error analyzing readability: {e}")
            return {}


class ContentExtractor:
    """Advanced content extraction with multiple strategies."""
    
    def __init__(self):
        """Initialize content extractor."""
        self.newspaper_config = NewspaperConfig()
        self.newspaper_config.browser_user_agent = (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        )
        self.newspaper_config.request_timeout = 15
        self.newspaper_config.fetch_images = False
        self.newspaper_config.memoize_articles = False
        self.newspaper_config.follow_meta_refresh = True
        
        # Domains that typically require JavaScript rendering
        self.js_heavy_domains = {
            'bloomberg.com', 'wsj.com', 'ft.com', 'cnbc.com', 'marketwatch.com',
            'reuters.com', 'cnn.com', 'bbc.com', 'forbes.com', 'techcrunch.com'
        }
        
        # Browser instance for Playwright
        self.browser: Optional[Browser] = None
    
    async def __aenter__(self):
        """Async context manager entry."""
        if PLAYWRIGHT_AVAILABLE:
            try:
                playwright = await async_playwright().__aenter__()
                self.browser = await playwright.chromium.launch(
                    headless=True,
                    args=['--no-sandbox', '--disable-dev-shm-usage']
                )
                logger.debug("Playwright browser initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize Playwright browser: {e}")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.browser:
            await self.browser.close()
    
    def requires_javascript(self, url: str) -> bool:
        """
        Determine if a URL likely requires JavaScript rendering.
        
        Args:
            url: URL to check
            
        Returns:
            True if JavaScript rendering is recommended
        """
        domain = extract_domain(url)
        return domain in self.js_heavy_domains
    
    async def fetch_with_playwright(self, url: str, timeout: int = 30) -> Optional[str]:
        """
        Fetch page content using Playwright for JavaScript rendering.
        
        Args:
            url: URL to fetch
            timeout: Timeout in seconds
            
        Returns:
            HTML content or None if failed
        """
        if not self.browser:
            logger.error("Playwright browser not available")
            return None
        
        try:
            page: Page = await self.browser.new_page()
            
            # Set viewport and user agent
            await page.set_viewport_size({"width": 1920, "height": 1080})
            await page.set_extra_http_headers({
                'Accept-Language': 'en-US,en;q=0.9'
            })
            
            # Navigate to page
            await page.goto(
                url,
                timeout=timeout * 1000,
                wait_until='networkidle'
            )
            
            # Wait for content to load
            await page.wait_for_timeout(2000)
            
            # Get page content
            html = await page.content()
            await page.close()
            
            logger.debug(f"Successfully fetched {url} with Playwright ({len(html)} chars)")
            return html
            
        except Exception as e:
            logger.error(f"Error fetching {url} with Playwright: {e}")
            return None
    
    def extract_with_newspaper(
        self, 
        url: str, 
        html_content: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Extract content using Newspaper3k library.
        
        Args:
            url: Article URL
            html_content: Optional pre-fetched HTML
            
        Returns:
            Dictionary with extracted content
        """
        result = {
            'title': '',
            'text': '',
            'authors': [],
            'publish_date': None,
            'top_image': '',
            'summary': '',
            'keywords': [],
            'meta_description': '',
            'meta_keywords': '',
            'canonical_link': '',
            'error': None
        }
        
        try:
            # Create article object
            article = NewspaperArticle(url, config=self.newspaper_config)
            
            # Set HTML if provided
            if html_content:
                article.set_html(html_content)
                article.parse()
            else:
                article.download()
                article.parse()
            
            # Extract basic information
            result['title'] = article.title or ''
            result['text'] = article.text or ''
            result['authors'] = list(article.authors) or []
            result['publish_date'] = article.publish_date
            result['top_image'] = article.top_image or ''
            result['meta_description'] = article.meta_description or ''
            result['meta_keywords'] = article.meta_keywords or ''
            result['canonical_link'] = article.canonical_link or ''
            
            # Run NLP processing
            try:
                article.nlp()
                result['summary'] = article.summary or ''
                result['keywords'] = list(article.keywords) or []
            except Exception as e:
                logger.warning(f"NLP processing failed for {url}: {e}")
                # Create basic summary from first few sentences
                if result['text']:
                    sentences = re.split(r'(?<=[.!?])\s+', result['text'])
                    result['summary'] = ' '.join(sentences[:3]) if sentences else ''
            
            return result
            
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Newspaper extraction failed for {url}: {e}")
            return result
    
    def extract_metadata(self, html_content: str) -> Dict[str, Any]:
        """
        Extract additional metadata from HTML.
        
        Args:
            html_content: HTML content
            
        Returns:
            Dictionary with metadata
        """
        metadata = {}
        
        try:
            # Extract Open Graph tags
            og_patterns = {
                'og_title': r'<meta property="og:title" content="([^"]*)"',
                'og_description': r'<meta property="og:description" content="([^"]*)"',
                'og_image': r'<meta property="og:image" content="([^"]*)"',
                'og_url': r'<meta property="og:url" content="([^"]*)"',
                'og_type': r'<meta property="og:type" content="([^"]*)"',
                'og_site_name': r'<meta property="og:site_name" content="([^"]*)"'
            }
            
            for key, pattern in og_patterns.items():
                match = re.search(pattern, html_content, re.IGNORECASE)
                if match:
                    metadata[key] = match.group(1)
            
            # Extract Twitter Card tags
            twitter_patterns = {
                'twitter_card': r'<meta name="twitter:card" content="([^"]*)"',
                'twitter_title': r'<meta name="twitter:title" content="([^"]*)"',
                'twitter_description': r'<meta name="twitter:description" content="([^"]*)"',
                'twitter_image': r'<meta name="twitter:image" content="([^"]*)"'
            }
            
            for key, pattern in twitter_patterns.items():
                match = re.search(pattern, html_content, re.IGNORECASE)
                if match:
                    metadata[key] = match.group(1)
            
            # Extract article metadata
            article_patterns = {
                'article_author': r'<meta name="author" content="([^"]*)"',
                'article_published_time': r'<meta property="article:published_time" content="([^"]*)"',
                'article_modified_time': r'<meta property="article:modified_time" content="([^"]*)"',
                'article_section': r'<meta property="article:section" content="([^"]*)"',
                'article_tag': r'<meta property="article:tag" content="([^"]*)"'
            }
            
            for key, pattern in article_patterns.items():
                matches = re.findall(pattern, html_content, re.IGNORECASE)
                if matches:
                    metadata[key] = matches if len(matches) > 1 else matches[0]
            
            return metadata
            
        except Exception as e:
            logger.error(f"Error extracting metadata: {e}")
            return {}


class ArticleCleaner:
    """Main article cleaning and processing class."""
    
    def __init__(self):
        """Initialize article cleaner."""
        self.extractor = ContentExtractor()
        self.readability_analyzer = ReadabilityAnalyzer()
        self.article_repo = ArticleRepository()
        
        # Initialize NLTK components if available
        if NLTK_AVAILABLE:
            try:
                nltk.data.find('tokenizers/punkt')
                nltk.data.find('corpora/stopwords')
                nltk.data.find('corpora/wordnet')
                self.lemmatizer = WordNetLemmatizer()
                self.stop_words = set(stopwords.words('english'))
                logger.debug("NLTK components initialized")
            except LookupError:
                logger.warning("NLTK data not found. Download with: python -m nltk.downloader punkt stopwords wordnet")
    
    async def clean_article(
        self, 
        url: str, 
        html_content: Optional[str] = None,
        force_javascript: bool = False
    ) -> Dict[str, Any]:
        """
        Clean and process article content with advanced extraction.
        
        Args:
            url: Article URL
            html_content: Optional pre-fetched HTML content
            force_javascript: Force JavaScript rendering
            
        Returns:
            Dictionary with cleaned and processed content
        """
        logger.debug(f"Cleaning article: {url}")
        
        result = {
            'url': url,
            'title': '',
            'cleaned_text': '',
            'summary': '',
            'keywords': [],
            'authors': [],
            'publish_date': None,
            'top_image': '',
            'metadata': {},
            'readability': {},
            'processing_stats': {
                'extraction_method': 'newspaper',
                'javascript_used': False,
                'processing_time': 0,
                'word_count': 0,
                'error': None
            },
            'error': None
        }
        
        start_time = time.time()
        
        try:
            async with self.extractor as extractor:
                # Determine if JavaScript rendering is needed
                use_javascript = (
                    force_javascript or 
                    (not html_content and extractor.requires_javascript(url))
                )
                
                # Fetch content with JavaScript if needed
                if use_javascript and PLAYWRIGHT_AVAILABLE:
                    html_content = await extractor.fetch_with_playwright(url)
                    result['processing_stats']['javascript_used'] = True
                    result['processing_stats']['extraction_method'] = 'playwright'
                
                # Extract content using Newspaper
                extraction_result = extractor.extract_with_newspaper(url, html_content)
                
                if extraction_result.get('error'):
                    result['error'] = f"Extraction failed: {extraction_result['error']}"
                    return result
                
                # Process extracted content
                result['title'] = extraction_result.get('title', '')
                raw_text = extraction_result.get('text', '')
                result['cleaned_text'] = clean_text(raw_text)
                result['summary'] = extraction_result.get('summary', '')
                result['keywords'] = extraction_result.get('keywords', [])
                result['authors'] = extraction_result.get('authors', [])
                result['publish_date'] = extraction_result.get('publish_date')
                result['top_image'] = extraction_result.get('top_image', '')
                
                # Extract additional metadata if HTML is available
                if html_content:
                    additional_metadata = extractor.extract_metadata(html_content)
                    result['metadata'].update(additional_metadata)
                
                # Add basic metadata
                result['metadata'].update({
                    'meta_description': extraction_result.get('meta_description', ''),
                    'meta_keywords': extraction_result.get('meta_keywords', ''),
                    'canonical_link': extraction_result.get('canonical_link', ''),
                    'domain': extract_domain(url),
                    'extracted_at': datetime.now(timezone.utc).isoformat()
                })
                
                # Analyze readability
                if result['cleaned_text']:
                    result['readability'] = self.readability_analyzer.analyze_readability(
                        result['cleaned_text']
                    )
                    result['processing_stats']['word_count'] = result['readability'].get('word_count', 0)
                
                # Enhance keywords with NLTK if available
                if NLTK_AVAILABLE and result['cleaned_text']:
                    enhanced_keywords = await self._enhance_keywords(result['cleaned_text'])
                    if enhanced_keywords:
                        result['keywords'].extend(enhanced_keywords)
                        result['keywords'] = list(set(result['keywords']))  # Remove duplicates
                
                # Generate improved summary if original is poor
                if len(result['summary']) < 50 and result['cleaned_text']:
                    result['summary'] = await self._generate_summary(result['cleaned_text'])
                
                result['processing_stats']['processing_time'] = time.time() - start_time
                
                logger.debug(
                    f"Successfully cleaned article {url}: "
                    f"{result['processing_stats']['word_count']} words, "
                    f"{len(result['keywords'])} keywords, "
                    f"{result['processing_stats']['processing_time']:.2f}s"
                )
                
                return result
                
        except Exception as e:
            result['error'] = str(e)
            result['processing_stats']['processing_time'] = time.time() - start_time
            result['processing_stats']['error'] = str(e)
            logger.error(f"Error cleaning article {url}: {e}")
            return result
    
    async def _enhance_keywords(self, text: str, max_keywords: int = 10) -> List[str]:
        """
        Enhance keywords using NLTK processing.
        
        Args:
            text: Text to analyze
            max_keywords: Maximum number of keywords to return
            
        Returns:
            List of enhanced keywords
        """
        if not NLTK_AVAILABLE or not hasattr(self, 'lemmatizer'):
            return []
        
        try:
            # Tokenize and process text
            words = word_tokenize(text.lower())
            
            # Filter out stop words and non-alphabetic tokens
            filtered_words = [
                self.lemmatizer.lemmatize(word)
                for word in words
                if word.isalpha() and word not in self.stop_words and len(word) > 2
            ]
            
            # Count word frequencies
            word_freq = {}
            for word in filtered_words:
                word_freq[word] = word_freq.get(word, 0) + 1
            
            # Get most frequent words
            sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
            keywords = [word for word, freq in sorted_words[:max_keywords] if freq > 1]
            
            return keywords
            
        except Exception as e:
            logger.error(f"Error enhancing keywords: {e}")
            return []
    
    async def _generate_summary(self, text: str, max_sentences: int = 3) -> str:
        """
        Generate a basic extractive summary.
        
        Args:
            text: Text to summarize
            max_sentences: Maximum number of sentences in summary
            
        Returns:
            Generated summary
        """
        try:
            # Split into sentences
            if NLTK_AVAILABLE:
                sentences = sent_tokenize(text)
            else:
                sentences = re.split(r'(?<=[.!?])\s+', text)
            
            if len(sentences) <= max_sentences:
                return text
            
            # Simple extraction: take first few sentences
            # In a more advanced implementation, this could use TF-IDF or other methods
            summary_sentences = sentences[:max_sentences]
            return ' '.join(summary_sentences)
            
        except Exception as e:
            logger.error(f"Error generating summary: {e}")
            return text[:200] + "..." if len(text) > 200 else text
    
    async def process_article(self, article: Article, force_reprocess: bool = False) -> bool:
        """
        Process a single article with comprehensive cleaning and analysis.
        
        Args:
            article: Article object to process
            force_reprocess: Force reprocessing even if already processed
            
        Returns:
            True if successful, False otherwise
        """
        # Skip if already processed (unless forced)
        if article.is_processed and not force_reprocess:
            logger.debug(f"Article {article.id} already processed, skipping")
            return True
        
        try:
            logger.info(f"Processing article {article.id}: {article.title}")
            
            with PerformanceLogger(f"process_article_{article.id}"):
                # For Telegram messages, use simple processing
                if article.source_type == 'telegram':
                    return await self._process_telegram_article(article)
                
                # For other sources, use full content extraction
                return await self._process_web_article(article)
                
        except Exception as e:
            logger.error(f"Error processing article {article.id}: {e}")
            return False
    
    async def _process_telegram_article(self, article: Article) -> bool:
        """Process Telegram article with simple text analysis."""
        try:
            # Basic text cleaning (already done during collection)
            if not article.cleaned_text:
                article.cleaned_text = clean_text(article.raw_content or '')
            
            # Generate basic summary
            if not article.summary and article.cleaned_text:
                article.summary = await self._generate_summary(article.cleaned_text)
            
            # Extract keywords
            if not article.keywords and article.cleaned_text:
                keywords = await self._enhance_keywords(article.cleaned_text)
                article.keywords = ','.join(keywords)
            
            # Analyze readability
            readability = self.readability_analyzer.analyze_readability(article.cleaned_text)
            
            # Update metadata
            metadata = article.metadata or {}
            metadata.update({
                'readability': readability,
                'processed_at': datetime.now(timezone.utc).isoformat(),
                'processing_method': 'telegram_simple'
            })
            article.metadata = metadata
            
            # Update word count and mark as processed
            article.update_word_count()
            article.is_processed = True
            
            # Save to database
            await self.article_repo.update(article)
            
            logger.debug(f"Successfully processed Telegram article {article.id}")
            return True
            
        except Exception as e:
            logger.error(f"Error processing Telegram article {article.id}: {e}")
            return False
    
    async def _process_web_article(self, article: Article) -> bool:
        """Process web article with full content extraction."""
        try:
            # Determine if JavaScript rendering is needed
            force_js = article.source_type == 'rss' and self.extractor.requires_javascript(article.url)
            
            # Clean the article
            cleaning_result = await self.clean_article(
                article.url,
                article.raw_content,
                force_javascript=force_js
            )
            
            if cleaning_result.get('error'):
                logger.warning(f"Cleaning failed for article {article.id}: {cleaning_result['error']}")
                # Use existing content if cleaning fails
                if not article.cleaned_text and article.raw_content:
                    article.cleaned_text = clean_text(article.raw_content)
            else:
                # Update article with cleaned content
                if cleaning_result.get('title') and len(cleaning_result['title']) > len(article.title or ''):
                    article.title = cleaning_result['title'][:500]
                
                if cleaning_result.get('cleaned_text'):
                    article.cleaned_text = cleaning_result['cleaned_text']
                
                if cleaning_result.get('summary'):
                    article.summary = cleaning_result['summary']
                
                if cleaning_result.get('keywords'):
                    article.keywords = ','.join(cleaning_result['keywords'])
                
                # Update publish date if we found a better one
                if (cleaning_result.get('publish_date') and 
                    article.date_quality != 'exact' and 
                    cleaning_result['publish_date']):
                    article.published_at = cleaning_result['publish_date']
                    article.date_quality = 'extracted'
                
                # Update metadata
                metadata = article.metadata or {}
                metadata.update(cleaning_result.get('metadata', {}))
                metadata.update({
                    'readability': cleaning_result.get('readability', {}),
                    'processing_stats': cleaning_result.get('processing_stats', {}),
                    'processed_at': datetime.now(timezone.utc).isoformat()
                })
                article.metadata = metadata
            
            # Update word count and content hash
            article.update_word_count()
            article.update_content_hash()
            
            # Mark as processed
            article.is_processed = True
            
            # Save to database
            await self.article_repo.update(article)
            
            logger.info(f"Successfully processed web article {article.id}")
            return True
            
        except Exception as e:
            logger.error(f"Error processing web article {article.id}: {e}")
            return False


async def process_unprocessed_articles(batch_size: int = 10) -> Dict[str, int]:
    """
    Process a batch of unprocessed articles.
    
    Args:
        batch_size: Number of articles to process in one batch
        
    Returns:
        Dictionary with processing statistics
    """
    stats = {
        'processed': 0,
        'failed': 0,
        'skipped': 0
    }
    
    article_repo = ArticleRepository()
    cleaner = ArticleCleaner()
    
    try:
        # Get unprocessed articles
        articles = await article_repo.get_unprocessed(batch_size, 'clean')
        
        if not articles:
            return stats
        
        logger.info(f"Processing {len(articles)} unprocessed articles")
        
        # Process articles
        for article in articles:
            try:
                success = await cleaner.process_article(article)
                if success:
                    stats['processed'] += 1
                else:
                    stats['failed'] += 1
            except Exception as e:
                logger.error(f"Error processing article {article.id}: {e}")
                stats['failed'] += 1
        
        logger.info(
            f"Batch processing complete. "
            f"Processed: {stats['processed']}, "
            f"Failed: {stats['failed']}"
        )
        
        return stats
        
    except Exception as e:
        logger.error(f"Error in batch processing: {e}")
        return stats


async def cleaner_worker():
    """
    Worker function that continuously processes unprocessed articles.
    """
    logger.info("Starting article cleaner worker")
    
    # Configuration
    batch_size = 10
    sleep_interval = 60  # seconds
    max_retries = 3
    
    consecutive_empty = 0
    max_consecutive_empty = 5
    
    while True:
        try:
            # Process a batch
            stats = await process_unprocessed_articles(batch_size)
            
            # Adjust sleep based on activity
            if stats['processed'] == 0:
                consecutive_empty += 1
                # Increase sleep time if no work
                current_sleep = sleep_interval * min(consecutive_empty, max_consecutive_empty)
            else:
                consecutive_empty = 0
                current_sleep = sleep_interval
            
            logger.debug(
                f"Cleaner worker cycle: {stats['processed']} processed, "
                f"{stats['failed']} failed, sleeping {current_sleep}s"
            )
            
            await asyncio.sleep(current_sleep)
            
        except Exception as e:
            logger.error(f"Error in cleaner worker: {e}")
            await asyncio.sleep(sleep_interval)