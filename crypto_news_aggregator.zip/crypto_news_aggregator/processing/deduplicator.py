"""
Advanced deduplication system using MinHash and machine learning techniques.
"""

import asyncio
import json
import math
import pickle
import time
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Set, Tuple, Any, Union
import hashlib
import re

import numpy as np
from loguru import logger

from core.storage import Article, ArticleRepository, SourceStateRepository
from utils.helpers import load_config, clean_text, generate_hash
from utils.logging import PerformanceLogger

# Try to import deduplication libraries
try:
    from datasketch import MinHash, MinHashLSH
    DATASKETCH_AVAILABLE = True
    logger.info("datasketch available for MinHash deduplication")
except ImportError:
    DATASKETCH_AVAILABLE = False
    logger.warning("datasketch not available. Using fallback similarity methods.")

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
    logger.info("scikit-learn available for TF-IDF similarity")
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn not available. TF-IDF similarity disabled.")

try:
    import difflib
    DIFFLIB_AVAILABLE = True
except ImportError:
    DIFFLIB_AVAILABLE = False


class DeduplicationError(Exception):
    """Exception raised during deduplication operations."""
    pass


class TextPreprocessor:
    """Advanced text preprocessing for similarity detection."""
    
    @staticmethod
    def normalize_text(text: str) -> str:
        """
        Normalize text for comparison.
        
        Args:
            text: Input text
            
        Returns:
            Normalized text
        """
        if not text:
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove common noise patterns
        noise_patterns = [
            r'\[.*?\]',  # Remove [brackets]
            r'\(.*?\)',  # Remove (parentheses) 
            r'http[s]?://\S+',  # Remove URLs
            r'@\w+',  # Remove mentions
            r'#\w+',  # Remove hashtags
            r'\d{4}-\d{2}-\d{2}',  # Remove dates
            r'\d{2}:\d{2}',  # Remove times
        ]
        
        for pattern in noise_patterns:
            text = re.sub(pattern, ' ', text)
        
        # Remove punctuation and special characters
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # Remove extra spaces again
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    @staticmethod
    def extract_shingles(text: str, k: int = 3) -> Set[str]:
        """
        Extract k-shingles (k-grams) from text.
        
        Args:
            text: Input text
            k: Size of shingles
            
        Returns:
            Set of k-shingles
        """
        if not text or len(text) < k:
            return set()
        
        # Character-level shingles
        char_shingles = {text[i:i+k] for i in range(len(text) - k + 1)}
        
        # Word-level shingles
        words = text.split()
        if len(words) >= k:
            word_shingles = {' '.join(words[i:i+k]) for i in range(len(words) - k + 1)}
            return char_shingles.union(word_shingles)
        
        return char_shingles
    
    @staticmethod
    def extract_features(text: str) -> Dict[str, Any]:
        """
        Extract various features from text for similarity comparison.
        
        Args:
            text: Input text
            
        Returns:
            Dictionary of extracted features
        """
        if not text:
            return {}
        
        words = text.split()
        
        features = {
            'length': len(text),
            'word_count': len(words),
            'unique_words': len(set(words)),
            'avg_word_length': sum(len(word) for word in words) / len(words) if words else 0,
            'sentence_count': len([s for s in re.split(r'[.!?]+', text) if s.strip()]),
            'numeric_count': len(re.findall(r'\d+', text)),
            'uppercase_ratio': sum(1 for c in text if c.isupper()) / len(text) if text else 0,
            'punctuation_count': len(re.findall(r'[^\w\s]', text)),
        }
        
        return features
    
    @staticmethod
    def structural_similarity(features1: Dict[str, Any], features2: Dict[str, Any]) -> float:
        """
        Calculate structural similarity between two feature sets.
        
        Args:
            features1: First feature set
            features2: Second feature set
            
        Returns:
            Similarity score (0.0 to 1.0)
        """
        if not features1 or not features2:
            return 0.0
        
        # Compare numerical features
        numeric_features = ['length', 'word_count', 'unique_words', 'avg_word_length', 
                          'sentence_count', 'numeric_count', 'punctuation_count']
        
        similarities = []
        
        for feature in numeric_features:
            val1 = features1.get(feature, 0)
            val2 = features2.get(feature, 0)
            
            if val1 == val2 == 0:
                similarities.append(1.0)
            elif val1 == 0 or val2 == 0:
                similarities.append(0.0)
            else:
                # Use relative difference
                similarity = 1.0 - abs(val1 - val2) / max(val1, val2)
                similarities.append(max(0.0, similarity))
        
        # Compare ratio features
        ratio_features = ['uppercase_ratio']
        for feature in ratio_features:
            val1 = features1.get(feature, 0)
            val2 = features2.get(feature, 0)
            similarities.append(1.0 - abs(val1 - val2))
        
        return sum(similarities) / len(similarities) if similarities else 0.0


class MinHashDeduplicator:
    """Advanced MinHash-based deduplication system."""
    
    def __init__(self, 
                 threshold: float = 0.85,
                 num_perm: int = 128,
                 lsh_threshold: float = 0.8,
                 cache_size: int = 10000):
        """
        Initialize MinHash deduplicator.
        
        Args:
            threshold: Similarity threshold for duplicates
            num_perm: Number of permutations for MinHash
            lsh_threshold: LSH threshold for candidate generation
            cache_size: Size of in-memory cache
        """
        self.threshold = threshold
        self.num_perm = num_perm
        self.lsh_threshold = lsh_threshold
        self.cache_size = cache_size
        
        self.preprocessor = TextPreprocessor()
        
        # Initialize LSH if available
        if DATASKETCH_AVAILABLE:
            self.lsh = MinHashLSH(threshold=lsh_threshold, num_perm=num_perm)
            logger.info(f"Initialized MinHashLSH with threshold={lsh_threshold}")
        else:
            self.lsh = None
            logger.warning("LSH not available, using brute force comparison")
        
        # Cache for recent signatures
        self.signature_cache: Dict[int, MinHash] = {}
        self.feature_cache: Dict[int, Dict[str, Any]] = {}
        
        logger.info(f"Initialized MinHashDeduplicator with threshold={threshold}")
    
    def compute_minhash(self, text: str) -> Optional['MinHash']:
        """
        Compute MinHash signature for text.
        
        Args:
            text: Input text
            
        Returns:
            MinHash object or None if datasketch unavailable
        """
        if not DATASKETCH_AVAILABLE:
            return None
        
        # Normalize text
        normalized_text = self.preprocessor.normalize_text(text)
        
        # Extract shingles
        shingles = self.preprocessor.extract_shingles(normalized_text, k=3)
        
        if not shingles:
            return None
        
        # Create MinHash
        minhash = MinHash(num_perm=self.num_perm)
        for shingle in shingles:
            minhash.update(shingle.encode('utf-8'))
        
        return minhash
    
    def compute_jaccard_similarity(self, text1: str, text2: str) -> float:
        """
        Compute Jaccard similarity between two texts.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Jaccard similarity score
        """
        # Normalize texts
        norm_text1 = self.preprocessor.normalize_text(text1)
        norm_text2 = self.preprocessor.normalize_text(text2)
        
        # Extract shingles
        shingles1 = self.preprocessor.extract_shingles(norm_text1)
        shingles2 = self.preprocessor.extract_shingles(norm_text2)
        
        if not shingles1 and not shingles2:
            return 1.0
        if not shingles1 or not shingles2:
            return 0.0
        
        # Calculate Jaccard similarity
        intersection = len(shingles1.intersection(shingles2))
        union = len(shingles1.union(shingles2))
        
        return intersection / union if union > 0 else 0.0
    
    def compute_combined_similarity(self, text1: str, text2: str) -> float:
        """
        Compute combined similarity using multiple methods.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Combined similarity score
        """
        similarities = []
        
        # MinHash similarity
        if DATASKETCH_AVAILABLE:
            minhash1 = self.compute_minhash(text1)
            minhash2 = self.compute_minhash(text2)
            
            if minhash1 and minhash2:
                similarities.append(minhash1.jaccard(minhash2))
        
        # Jaccard similarity
        jaccard_sim = self.compute_jaccard_similarity(text1, text2)
        similarities.append(jaccard_sim)
        
        # Structural similarity
        features1 = self.preprocessor.extract_features(text1)
        features2 = self.preprocessor.extract_features(text2)
        structural_sim = self.preprocessor.structural_similarity(features1, features2)
        similarities.append(structural_sim)
        
        # TF-IDF cosine similarity
        if SKLEARN_AVAILABLE:
            try:
                vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
                tfidf_matrix = vectorizer.fit_transform([text1, text2])
                cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
                similarities.append(cosine_sim)
            except Exception as e:
                logger.debug(f"TF-IDF similarity failed: {e}")
        
        # Sequence similarity using difflib
        if DIFFLIB_AVAILABLE:
            seq_sim = difflib.SequenceMatcher(None, text1, text2).ratio()
            similarities.append(seq_sim)
        
        # Weighted average (give more weight to MinHash and Jaccard)
        if len(similarities) >= 3:
            weights = [0.3, 0.3, 0.2] + [0.2 / (len(similarities) - 3)] * (len(similarities) - 3)
        else:
            weights = [1.0 / len(similarities)] * len(similarities)
        
        return sum(sim * weight for sim, weight in zip(similarities, weights))
    
    async def update_cache(self, article_repo: ArticleRepository):
        """
        Update the in-memory cache with recent article signatures.
        
        Args:
            article_repo: Article repository instance
        """
        try:
            with PerformanceLogger("update_dedup_cache"):
                # Get recent articles with content
                async with article_repo.get_session() as session:
                    from sqlalchemy.future import select
                    from core.storage import Article
                    
                    query = select(Article.id, Article.cleaned_text, Article.metadata).filter(
                        Article.cleaned_text.isnot(None),
                        Article.cleaned_text != ''
                    ).order_by(Article.created_at.desc()).limit(self.cache_size)
                    
                    result = await session.execute(query)
                    rows = result.fetchall()
                
                # Clear old cache
                self.signature_cache.clear()
                self.feature_cache.clear()
                
                # Rebuild LSH index
                if self.lsh:
                    self.lsh = MinHashLSH(threshold=self.lsh_threshold, num_perm=self.num_perm)
                
                # Process articles
                for article_id, cleaned_text, metadata in rows:
                    if not cleaned_text:
                        continue
                    
                    # Compute and cache MinHash
                    if DATASKETCH_AVAILABLE:
                        minhash = self.compute_minhash(cleaned_text)
                        if minhash:
                            self.signature_cache[article_id] = minhash
                            if self.lsh:
                                self.lsh.insert(article_id, minhash)
                    
                    # Cache features
                    features = self.preprocessor.extract_features(cleaned_text)
                    self.feature_cache[article_id] = features
                
                logger.info(f"Updated deduplication cache with {len(self.signature_cache)} signatures")
                
        except Exception as e:
            logger.error(f"Error updating deduplication cache: {e}")
    
    async def find_duplicates(self, article: Article) -> List[Tuple[int, float, Dict[str, Any]]]:
        """
        Find potential duplicates for an article.
        
        Args:
            article: Article to check for duplicates
            
        Returns:
            List of (article_id, similarity_score, details) tuples
        """
        if not article.cleaned_text:
            return []
        
        duplicates = []
        
        try:
            with PerformanceLogger(f"find_duplicates_article_{article.id}"):
                # Use LSH for candidate generation if available
                candidates = set()
                
                if self.lsh and DATASKETCH_AVAILABLE:
                    minhash = self.compute_minhash(article.cleaned_text)
                    if minhash:
                        lsh_candidates = self.lsh.query(minhash)
                        candidates.update(lsh_candidates)
                        logger.debug(f"LSH found {len(lsh_candidates)} candidates for article {article.id}")
                
                # Fallback: check against cache
                if not candidates:
                    candidates = set(self.signature_cache.keys())
                
                # Remove self if present
                candidates.discard(article.id)
                
                # Calculate similarities
                article_features = self.preprocessor.extract_features(article.cleaned_text)
                
                for candidate_id in candidates:
                    try:
                        # Get candidate text (this would need to be cached or fetched)
                        # For now, we'll use structural similarity only
                        candidate_features = self.feature_cache.get(candidate_id)
                        
                        if candidate_features:
                            structural_sim = self.preprocessor.structural_similarity(
                                article_features, candidate_features
                            )
                            
                            if structural_sim >= self.threshold:
                                details = {
                                    'structural_similarity': structural_sim,
                                    'comparison_method': 'structural',
                                    'features_compared': True
                                }
                                duplicates.append((candidate_id, structural_sim, details))
                    
                    except Exception as e:
                        logger.debug(f"Error comparing with candidate {candidate_id}: {e}")
                
                # Sort by similarity score
                duplicates.sort(key=lambda x: x[1], reverse=True)
                
                logger.debug(f"Found {len(duplicates)} potential duplicates for article {article.id}")
                
        except Exception as e:
            logger.error(f"Error finding duplicates for article {article.id}: {e}")
        
        return duplicates
    
    async def is_duplicate(self, text: str, article_repo: ArticleRepository) -> Tuple[bool, Optional[int], float]:
        """
        Check if text is a duplicate of existing content.
        
        Args:
            text: Text to check
            article_repo: Article repository instance
            
        Returns:
            Tuple of (is_duplicate, duplicate_article_id, similarity_score)
        """
        if not text:
            return False, None, 0.0
        
        try:
            # Ensure cache is updated
            if not self.signature_cache:
                await self.update_cache(article_repo)
            
            # Quick check using content hash
            content_hash = generate_hash(text)
            
            # Check for exact content hash matches
            async with article_repo.get_session() as session:
                from sqlalchemy.future import select
                from core.storage import Article
                
                query = select(Article.id).filter(Article.content_hash == content_hash)
                result = await session.execute(query)
                exact_match = result.scalar_one_or_none()
                
                if exact_match:
                    return True, exact_match, 1.0
            
            # Use LSH for candidate generation
            best_similarity = 0.0
            best_match_id = None
            
            if self.lsh and DATASKETCH_AVAILABLE:
                minhash = self.compute_minhash(text)
                if minhash:
                    candidates = self.lsh.query(minhash)
                    
                    for candidate_id in candidates:
                        if candidate_id in self.signature_cache:
                            candidate_minhash = self.signature_cache[candidate_id]
                            similarity = minhash.jaccard(candidate_minhash)
                            
                            if similarity > best_similarity:
                                best_similarity = similarity
                                best_match_id = candidate_id
            
            is_duplicate = best_similarity >= self.threshold
            return is_duplicate, best_match_id, best_similarity
            
        except Exception as e:
            logger.error(f"Error checking for duplicates: {e}")
            return False, None, 0.0


class DeduplicationService:
    """Main deduplication service coordinating all operations."""
    
    def __init__(self):
        """Initialize deduplication service."""
        # Load configuration
        config = load_config()
        dedup_config = config.get('deduplication', {})
        
        self.threshold = dedup_config.get('minhash_threshold', 0.85)
        self.batch_size = dedup_config.get('batch_size', 20)
        self.cache_refresh_interval = dedup_config.get('cache_refresh_hours', 6) * 3600
        
        # Initialize repositories
        self.article_repo = ArticleRepository()
        self.state_repo = SourceStateRepository()
        
        # Initialize deduplicator
        self.deduplicator = MinHashDeduplicator(threshold=self.threshold)
        
        # State tracking
        self.last_cache_update = 0
        
        logger.info(f"Initialized deduplication service with threshold={self.threshold}")
    
    async def ensure_cache_updated(self):
        """Ensure deduplication cache is up to date."""
        current_time = time.time()
        
        if (current_time - self.last_cache_update) > self.cache_refresh_interval:
            logger.info("Refreshing deduplication cache")
            await self.deduplicator.update_cache(self.article_repo)
            self.last_cache_update = current_time
    
    async def process_article_deduplication(self, article: Article) -> Dict[str, Any]:
        """
        Process deduplication for a single article.
        
        Args:
            article: Article to process
            
        Returns:
            Dictionary with deduplication results
        """
        result = {
            'article_id': article.id,
            'is_duplicate': False,
            'duplicate_of': None,
            'similarity_score': 0.0,
            'potential_duplicates': [],
            'processing_time': 0,
            'method_used': 'minhash'
        }
        
        start_time = time.time()
        
        try:
            # Ensure cache is updated
            await self.ensure_cache_updated()
            
            # Find duplicates
            duplicates = await self.deduplicator.find_duplicates(article)
            
            if duplicates:
                # Mark as duplicate if best match exceeds threshold
                best_match = duplicates[0]
                best_id, best_similarity, details = best_match
                
                if best_similarity >= self.threshold:
                    result['is_duplicate'] = True
                    result['duplicate_of'] = best_id
                    result['similarity_score'] = best_similarity
                    
                    # Update article in database
                    article.is_duplicate = True
                    article.duplicate_of = best_id
                    
                    # Update metadata
                    metadata = article.metadata or {}
                    metadata['deduplication'] = {
                        'is_duplicate': True,
                        'duplicate_of': best_id,
                        'similarity_score': best_similarity,
                        'detected_at': datetime.now(timezone.utc).isoformat(),
                        'method': 'minhash',
                        'details': details
                    }
                    article.metadata = metadata
                    
                    await self.article_repo.update(article)
                
                # Store all potential duplicates
                result['potential_duplicates'] = [
                    {
                        'article_id': dup_id,
                        'similarity_score': similarity,
                        'details': details
                    }
                    for dup_id, similarity, details in duplicates[:10]  # Limit to top 10
                ]
            
            result['processing_time'] = time.time() - start_time
            
            if result['is_duplicate']:
                logger.info(
                    f"Article {article.id} marked as duplicate of {result['duplicate_of']} "
                    f"(similarity: {result['similarity_score']:.3f})"
                )
            
            return result
            
        except Exception as e:
            result['error'] = str(e)
            result['processing_time'] = time.time() - start_time
            logger.error(f"Error processing deduplication for article {article.id}: {e}")
            return result
    
    async def process_batch(self) -> Dict[str, Any]:
        """
        Process a batch of articles for deduplication.
        
        Returns:
            Dictionary with batch processing statistics
        """
        stats = {
            'processed': 0,
            'duplicates_found': 0,
            'errors': 0,
            'processing_time': 0,
            'batch_size': self.batch_size
        }
        
        start_time = time.time()
        
        try:
            # Get articles that need deduplication
            articles = await self.article_repo.get_unprocessed(self.batch_size, 'dedupe')
            
            if not articles:
                return stats
            
            logger.info(f"Processing deduplication for {len(articles)} articles")
            
            # Process each article
            for article in articles:
                try:
                    result = await self.process_article_deduplication(article)
                    
                    stats['processed'] += 1
                    if result.get('is_duplicate'):
                        stats['duplicates_found'] += 1
                    
                    if result.get('error'):
                        stats['errors'] += 1
                        
                except Exception as e:
                    stats['errors'] += 1
                    logger.error(f"Error processing article {article.id}: {e}")
            
            stats['processing_time'] = time.time() - start_time
            
            logger.info(
                f"Deduplication batch complete: {stats['processed']} processed, "
                f"{stats['duplicates_found']} duplicates found, "
                f"{stats['errors']} errors in {stats['processing_time']:.2f}s"
            )
            
            # Save batch statistics
            await self.state_repo.set_state(
                'deduplication',
                'batch_processing',
                'last_batch',
                datetime.now(timezone.utc).isoformat(),
                metadata=stats
            )
            
            return stats
            
        except Exception as e:
            stats['errors'] += 1
            stats['processing_time'] = time.time() - start_time
            logger.error(f"Error in deduplication batch processing: {e}")
            return stats
    
    async def get_statistics(self) -> Dict[str, Any]:
        """
        Get comprehensive deduplication statistics.
        
        Returns:
            Dictionary with statistics
        """
        try:
            stats = await self.article_repo.get_statistics()
            
            # Add deduplication-specific stats
            dedup_stats = {
                'total_articles': stats.get('total_articles', 0),
                'duplicate_articles': stats.get('duplicate_articles', 0),
                'duplicate_percentage': 0.0,
                'cache_size': len(self.deduplicator.signature_cache),
                'threshold': self.threshold,
                'last_cache_update': datetime.fromtimestamp(
                    self.last_cache_update, tz=timezone.utc
                ).isoformat() if self.last_cache_update else None
            }
            
            if dedup_stats['total_articles'] > 0:
                dedup_stats['duplicate_percentage'] = (
                    dedup_stats['duplicate_articles'] / dedup_stats['total_articles'] * 100
                )
            
            return dedup_stats
            
        except Exception as e:
            logger.error(f"Error getting deduplication statistics: {e}")
            return {}


async def deduplication_worker():
    """
    Worker function that continuously processes articles for deduplication.
    """
    logger.info("Starting deduplication worker")
    
    # Initialize service
    service = DeduplicationService()
    
    # Configuration
    sleep_interval = 120  # 2 minutes
    consecutive_empty = 0
    max_consecutive_empty = 5
    
    while True:
        try:
            # Process a batch
            stats = await service.process_batch()
            
            # Adjust sleep based on activity
            if stats['processed'] == 0:
                consecutive_empty += 1
                current_sleep = sleep_interval * min(consecutive_empty, max_consecutive_empty)
            else:
                consecutive_empty = 0
                current_sleep = sleep_interval
            
            logger.debug(
                f"Deduplication worker cycle: {stats['processed']} processed, "
                f"{stats['duplicates_found']} duplicates, sleeping {current_sleep}s"
            )
            
            await asyncio.sleep(current_sleep)
            
        except Exception as e:
            logger.error(f"Error in deduplication worker: {e}")
            await asyncio.sleep(sleep_interval)


# Export main functions
__all__ = [
    'DeduplicationService',
    'MinHashDeduplicator', 
    'TextPreprocessor',
    'deduplication_worker'
]