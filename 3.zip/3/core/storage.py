"""
Crypto News Aggregator - Storage Layer
Created: 2025-06-18 19:18:11 UTC
User: phrphrphr
Version: 3.0.0

Модуль для работы с базой данных статей
"""

import hashlib
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from pathlib import Path
from tinydb import TinyDB, Query
from tinydb.operations import delete
import threading
from loguru import logger

class Storage:
    """Класс для работы с хранилищем статей"""
    
    def __init__(self, db_path: str = "data/storage.json"):
        self.db_path = db_path
        self._lock = threading.RLock()  # Для потокобезопасности
        
        # Создаем директорию если её нет
        db_dir = Path(db_path).parent
        db_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            self.db = TinyDB(db_path, indent=2, ensure_ascii=False)
            self.articles = self.db.table('articles')
            logger.info(f"📊 База данных инициализирована: {db_path}")
            logger.info(f"📰 Статей в базе: {len(self.articles.all())}")
        except Exception as e:
            logger.error(f"💥 Ошибка инициализации базы данных: {e}")
            raise
    
    def save_article(self, article: Dict) -> bool:
        """Сохранение статьи в базу данных"""
        with self._lock:
            try:
                # Проверяем обязательные поля
                if not article.get('title') or not article.get('link'):
                    logger.warning("⚠️ Статья без заголовка или ссылки пропущена")
                    return False
                
                # Создаем хэш для дедупликации
                article_content = f"{article.get('title', '')}{article.get('link', '')}"
                article_hash = hashlib.md5(article_content.encode('utf-8')).hexdigest()
                
                # Проверяем, есть ли уже такая статья
                Article = Query()
                existing = self.articles.search(Article.hash == article_hash)
                
                if existing:
                    logger.debug(f"🔄 Статья уже существует: {article.get('title', '')[:50]}...")
                    return False  # Статья уже существует
                
                # Подготавливаем данные для сохранения
                current_time = datetime.utcnow().isoformat() + 'Z'
                
                article_data = {
                    'title': str(article.get('title', 'Без названия')).strip(),
                    'link': str(article.get('link', '')).strip(),
                    'summary': str(article.get('summary', 'Описание недоступно')).strip(),
                    'published': self._normalize_date(article.get('published', current_time)),
                    'source': str(article.get('source', 'Неизвестный источник')).strip(),
                    'hash': article_hash,
                    'created_at': current_time
                }
                
                # Сохраняем
                self.articles.insert(article_data)
                logger.debug(f"💾 Сохранена статья: {article_data['title'][:50]}...")
                return True
                
            except Exception as e:
                logger.error(f"💥 Ошибка сохранения статьи: {e}")
                return False
    
    def _normalize_date(self, date_str: str) -> str:
        """Нормализация даты в ISO формат UTC"""
        if not date_str:
            return datetime.utcnow().isoformat() + 'Z'
        
        try:
            # Если уже в ISO формате
            if 'T' in date_str and (date_str.endswith('Z') or '+' in date_str[-6:] or '-' in date_str[-6:]):
                return date_str if date_str.endswith('Z') else date_str + 'Z'
            
            # Пытаемся парсить и конвертировать
            try:
                dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                return dt.isoformat() + 'Z'
            except ValueError:
                pass
            
            # Пытаемся другие форматы
            try:
                from dateutil import parser
                dt = parser.parse(date_str)
                return dt.isoformat() + 'Z'
            except:
                pass
            
            # Пытаемся RFC 2822 формат (из RSS)
            try:
                from email.utils import parsedate_tz, mktime_tz
                parsed = parsedate_tz(date_str)
                if parsed:
                    timestamp = mktime_tz(parsed)
                    return datetime.utcfromtimestamp(timestamp).isoformat() + 'Z'
            except:
                pass
                
        except Exception as e:
            logger.debug(f"⚠️ Не удалось парсить дату '{date_str}': {e}")
        
        # Возвращаем текущее время если не удалось парсить
        return datetime.utcnow().isoformat() + 'Z'
    
    def get_all_articles(self) -> List[Dict]:
        """Получение всех статей"""
        with self._lock:
            try:
                articles = self.articles.all()
                # Сортируем по дате создания (новые сверху)
                return sorted(articles, key=lambda x: x.get('created_at', ''), reverse=True)
            except Exception as e:
                logger.error(f"💥 Ошибка получения всех статей: {e}")
                return []
    
    def get_recent_articles(self, limit: int = 50) -> List[Dict]:
        """Получение последних статей"""
        with self._lock:
            try:
                all_articles = self.articles.all()
                # Сортируем по дате создания (новые сверху)
                sorted_articles = sorted(
                    all_articles, 
                    key=lambda x: x.get('created_at', ''), 
                    reverse=True
                )
                return sorted_articles[:limit]
            except Exception as e:
                logger.error(f"💥 Ошибка получения последних статей: {e}")
                return []
    
    def get_articles_by_source(self, source: str) -> List[Dict]:
        """Получение статей по источнику"""
        with self._lock:
            try:
                Article = Query()
                articles = self.articles.search(Article.source == source)
                # Сортируем по дате создания (новые сверху)
                return sorted(articles, key=lambda x: x.get('created_at', ''), reverse=True)
            except Exception as e:
                logger.error(f"💥 Ошибка получения статей по источнику {source}: {e}")
                return []
    
    def get_articles_count(self) -> int:
        """Получение количества статей"""
        with self._lock:
            try:
                return len(self.articles.all())
            except Exception as e:
                logger.error(f"💥 Ошибка получения количества статей: {e}")
                return 0
    
    def cleanup_old_articles(self, days: int = 30) -> int:
        """Очистка старых статей"""
        with self._lock:
            try:
                cutoff_date = (datetime.utcnow() - timedelta(days=days)).isoformat() + 'Z'
                
                Article = Query()
                old_articles = self.articles.search(Article.created_at < cutoff_date)
                
                if old_articles:
                    self.articles.remove(Article.created_at < cutoff_date)
                    logger.info(f"🧹 Удалено {len(old_articles)} старых статей (старше {days} дней)")
                    return len(old_articles)
                
                return 0
                
            except Exception as e:
                logger.error(f"💥 Ошибка очистки старых статей: {e}")
                return 0
    
    def get_stats(self) -> Dict:
        """Получение статистики"""
        with self._lock:
            try:
                all_articles = self.articles.all()
                
                # Статистика по источникам
                sources = {}
                for article in all_articles:
                    source = article.get('source', 'Неизвестный')
                    sources[source] = sources.get(source, 0) + 1
                
                # Последнее обновление - берем самую новую статью
                last_updated = datetime.utcnow().isoformat() + 'Z'
                if all_articles:
                    sorted_articles = sorted(all_articles, key=lambda x: x.get('created_at', ''), reverse=True)
                    if sorted_articles:
                        last_updated = sorted_articles[0].get('created_at', last_updated)
                
                return {
                    "total_articles": len(all_articles),
                    "sources_count": len(sources),
                    "sources": sources,
                    "last_updated": last_updated
                }
            except Exception as e:
                logger.error(f"💥 Ошибка получения статистики: {e}")
                return {
                    "total_articles": 0,
                    "sources_count": 0,
                    "sources": {},
                    "last_updated": datetime.utcnow().isoformat() + 'Z'
                }
    
    def get_database_info(self) -> Dict:
        """Получение информации о базе данных"""
        with self._lock:
            try:
                db_path = Path(self.db_path)
                
                return {
                    "database_path": str(db_path.absolute()),
                    "database_exists": db_path.exists(),
                    "database_size_mb": round(db_path.stat().st_size / 1024 / 1024, 2) if db_path.exists() else 0,
                    "tables_count": len(self.db.tables()),
                    "articles_table_exists": 'articles' in self.db.tables(),
                    "total_articles": len(self.articles.all()),
                    "created_at": datetime.utcnow().isoformat() + 'Z'
                }
            except Exception as e:
                logger.error(f"💥 Ошибка получения информации о БД: {e}")
                return {
                    "database_path": self.db_path,
                    "database_exists": False,
                    "error": str(e),
                    "created_at": datetime.utcnow().isoformat() + 'Z'
                }
    
    def validate_database(self) -> Dict:
        """Проверка целостности базы данных"""
        with self._lock:
            try:
                issues = []
                all_articles = self.articles.all()
                
                # Проверяем каждую статью
                valid_articles = 0
                for i, article in enumerate(all_articles):
                    try:
                        # Проверяем обязательные поля
                        required_fields = ['title', 'link', 'hash', 'created_at']
                        missing_fields = [field for field in required_fields if not article.get(field)]
                        
                        if missing_fields:
                            issues.append(f"Статья #{i}: отсутствуют поля {missing_fields}")
                        else:
                            valid_articles += 1
                            
                        # Проверяем валидность дат
                        for date_field in ['created_at', 'published']:
                            if article.get(date_field):
                                try:
                                    datetime.fromisoformat(article[date_field].replace('Z', '+00:00'))
                                except:
                                    issues.append(f"Статья #{i}: неверный формат даты в поле {date_field}")
                            
                    except Exception as e:
                        issues.append(f"Статья #{i}: ошибка валидации - {e}")
                
                # Проверяем дубликаты по хэшу
                hashes = [article.get('hash') for article in all_articles if article.get('hash')]
                duplicates = len(hashes) - len(set(hashes))
                if duplicates > 0:
                    issues.append(f"Найдено {duplicates} дублирующихся статей по хэшу")
                
                # Проверяем дубликаты по ссылке
                links = [article.get('link') for article in all_articles if article.get('link')]
                link_duplicates = len(links) - len(set(links))
                if link_duplicates > 0:
                    issues.append(f"Найдено {link_duplicates} дублирующихся ссылок")
                
                return {
                    "total_articles": len(all_articles),
                    "valid_articles": valid_articles,
                    "issues_count": len(issues),
                    "issues": issues[:10],  # Показываем только первые 10 проблем
                    "is_healthy": len(issues) == 0,
                    "checked_at": datetime.utcnow().isoformat() + 'Z'
                }
                
            except Exception as e:
                logger.error(f"💥 Ошибка валидации БД: {e}")
                return {
                    "is_healthy": False,
                    "error": str(e),
                    "checked_at": datetime.utcnow().isoformat() + 'Z'
                }
    
    def search_articles(self, query: str, limit: int = 50) -> List[Dict]:
        """Поиск статей по тексту"""
        with self._lock:
            try:
                if not query:
                    return []
                
                query_lower = query.lower()
                all_articles = self.articles.all()
                
                matching_articles = []
                for article in all_articles:
                    # Ищем в заголовке и описании
                    title = article.get('title', '').lower()
                    summary = article.get('summary', '').lower()
                    
                    if query_lower in title or query_lower in summary:
                        matching_articles.append(article)
                
                # Сортируем по релевантности (сначала совпадения в заголовке)
                def relevance_score(article):
                    title = article.get('title', '').lower()
                    summary = article.get('summary', '').lower()
                    
                    score = 0
                    if query_lower in title:
                        score += 2
                    if query_lower in summary:
                        score += 1
                    
                    return score
                
                matching_articles.sort(key=relevance_score, reverse=True)
                return matching_articles[:limit]
                
            except Exception as e:
                logger.error(f"💥 Ошибка поиска статей: {e}")
                return []
    
    def get_articles_by_date_range(self, start_date: str, end_date: str) -> List[Dict]:
        """Получение статей за период"""
        with self._lock:
            try:
                Article = Query()
                articles = self.articles.search(
                    (Article.created_at >= start_date) & 
                    (Article.created_at <= end_date)
                )
                return sorted(articles, key=lambda x: x.get('created_at', ''), reverse=True)
            except Exception as e:
                logger.error(f"💥 Ошибка получения статей за период: {e}")
                return []
    
    def backup_database(self, backup_path: str) -> bool:
        """Создание резервной копии базы данных"""
        with self._lock:
            try:
                import shutil
                shutil.copy2(self.db_path, backup_path)
                logger.info(f"💾 Резервная копия создана: {backup_path}")
                return True
            except Exception as e:
                logger.error(f"💥 Ошибка создания резервной копии: {e}")
                return False
    
    def close(self):
        """Закрытие базы данных"""
        try:
            self.db.close()
            logger.info("🔒 База данных закрыта")
        except Exception as e:
            logger.error(f"💥 Ошибка закрытия базы данных: {e}")

# Создаем глобальный экземпляр хранилища
try:
    from core.config import settings
    storage = Storage(settings.db_path)
except ImportError:
    # Fallback если config недоступен
    storage = Storage()