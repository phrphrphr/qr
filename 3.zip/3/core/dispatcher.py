"""
Crypto News Aggregator - Dispatcher
Created: 2025-06-18 19:18:11 UTC
User: phrphrphr
Version: 3.0.0

Диспетчер для управления парсерами RSS лент
"""

import asyncio
from typing import List, Dict
from datetime import datetime
from loguru import logger

try:
    from sources.rss import RSSParser
    from core.storage import storage
    from core.config import settings
except ImportError as e:
    logger.error(f"💥 Ошибка импорта в dispatcher: {e}")
    raise

class Dispatcher:
    """Диспетчер для управления парсерами"""
    
    def __init__(self):
        self.rss_parser = RSSParser()
        self.total_articles_processed = 0
        self.total_new_articles = 0
        self.is_running = False
        self.last_run_time = None
        self.last_run_result = None
    
    async def run_all_parsers(self) -> Dict:
        """Запуск всех парсеров"""
        if self.is_running:
            logger.warning("⚠️ Парсинг уже выполняется")
            return {"status": "already_running", "message": "Парсинг уже выполняется"}
        
        self.is_running = True
        start_time = datetime.utcnow()
        self.last_run_time = start_time.isoformat() + 'Z'
        
        try:
            logger.info("🔄 Начинается парсинг всех RSS лент")
            
            if not settings.rss_feeds:
                logger.warning("⚠️ Список RSS лент пуст!")
                return {
                    "status": "no_feeds", 
                    "message": "Список RSS лент пуст",
                    "execution_time": 0
                }
            
            total_new_articles = 0
            total_processed = 0
            successful_feeds = 0
            failed_feeds = []
            
            # Создаем семафор для ограничения параллелизма
            semaphore = asyncio.Semaphore(3)  # Максимум 3 одновременных запроса
            
            async def parse_single_feed(feed_url: str, index: int) -> Dict:
                async with semaphore:
                    try:
                        logger.info(f"📡 [{index}/{len(settings.rss_feeds)}] Парсинг: {feed_url}")
                        
                        articles = await self.rss_parser.parse_feed(feed_url.strip())
                        processed_count = len(articles)
                        new_articles_count = 0
                        
                        # Сохраняем статьи
                        for article in articles:
                            if storage.save_article(article):
                                new_articles_count += 1
                        
                        logger.info(f"✅ {feed_url}: {new_articles_count}/{processed_count} новых статей")
                        
                        return {
                            "url": feed_url,
                            "status": "success",
                            "processed": processed_count,
                            "new": new_articles_count,
                            "error": None
                        }
                        
                    except Exception as e:
                        logger.error(f"💥 Ошибка парсинга {feed_url}: {e}")
                        return {
                            "url": feed_url,
                            "status": "error",
                            "error": str(e),
                            "processed": 0,
                            "new": 0
                        }
            
            # Запускаем парсинг всех лент параллельно
            tasks = [
                parse_single_feed(feed_url, i) 
                for i, feed_url in enumerate(settings.rss_feeds, 1) 
                if feed_url.strip()
            ]
            
            if not tasks:
                logger.warning("⚠️ Нет валидных RSS лент для парсинга")
                return {
                    "status": "no_valid_feeds",
                    "message": "Нет валидных RSS лент",
                    "execution_time": 0
                }
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Обрабатываем результаты
            for result in results:
                if isinstance(result, Exception):
                    logger.error(f"💥 Исключение при парсинге: {result}")
                    failed_feeds.append({"error": str(result), "url": "unknown"})
                    continue
                
                if result["status"] == "success":
                    total_processed += result["processed"]
                    total_new_articles += result["new"]
                    successful_feeds += 1
                else:
                    failed_feeds.append(result)
            
            # Обновляем статистику
            self.total_articles_processed += total_processed
            self.total_new_articles += total_new_articles
            
            # Итоговый отчет
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            
            logger.info(f"🎯 Парсинг завершен за {execution_time:.2f} секунд:")
            logger.info(f"   📊 Успешно обработано лент: {successful_feeds}/{len(settings.rss_feeds)}")
            logger.info(f"   📰 Всего статей обработано: {total_processed}")
            logger.info(f"   ✨ Новых статей добавлено: {total_new_articles}")
            logger.info(f"   📈 Всего статей в базе: {storage.get_articles_count()}")
            
            if failed_feeds:
                logger.warning(f"   ⚠️ Ошибок при парсинге: {len(failed_feeds)}")
            
            # Очищаем старые статьи периодически
            if self.total_articles_processed % 100 == 0:
                try:
                    cleaned = storage.cleanup_old_articles(30)
                    if cleaned > 0:
                        logger.info(f"🧹 Очищено {cleaned} старых статей")
                except Exception as e:
                    logger.error(f"💥 Ошибка очистки старых статей: {e}")
            
            result = {
                "status": "completed",
                "execution_time": execution_time,
                "feeds_processed": successful_feeds,
                "feeds_failed": len(failed_feeds),
                "feeds_total": len(settings.rss_feeds),
                "articles_processed": total_processed,
                "articles_new": total_new_articles,
                "articles_total": storage.get_articles_count(),
                "failed_feeds": failed_feeds,
                "started_at": start_time.isoformat() + 'Z',
                "completed_at": datetime.utcnow().isoformat() + 'Z'
            }
            
            self.last_run_result = result
            return result
            
        except Exception as e:
            logger.error(f"💥 Критическая ошибка в диспетчере: {e}")
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            result = {
                "status": "error",
                "error": str(e),
                "execution_time": execution_time,
                "started_at": start_time.isoformat() + 'Z',
                "failed_at": datetime.utcnow().isoformat() + 'Z'
            }
            self.last_run_result = result
            return result
        finally:
            self.is_running = False
    
    def get_stats(self) -> Dict:
        """Получение статистики диспетчера"""
        return {
            "total_articles_processed": self.total_articles_processed,
            "total_new_articles": self.total_new_articles,
            "is_running": self.is_running,
            "last_run_time": self.last_run_time,
            "last_run_result": self.last_run_result,
            "rss_parser_stats": self.rss_parser.get_stats(),
            "configured_feeds_count": len(settings.rss_feeds),
            "configured_feeds": settings.rss_feeds
        }
    
    def reset_stats(self):
        """Сброс статистики диспетчера"""
        self.total_articles_processed = 0
        self.total_new_articles = 0
        self.last_run_time = None
        self.last_run_result = None
        self.rss_parser.reset_stats()
        logger.info("📊 Статистика диспетчера сброшена")
    
    def get_last_run_summary(self) -> Dict:
        """Получение краткой сводки последнего запуска"""
        if not self.last_run_result:
            return {
                "status": "never_run",
                "message": "Парсинг еще не запускался"
            }
        
        result = self.last_run_result.copy()
        
        # Добавляем человекочитаемую информацию
        if result.get("status") == "completed":
            success_rate = 0
            if result.get("feeds_total", 0) > 0:
                success_rate = (result.get("feeds_processed", 0) / result.get("feeds_total", 1)) * 100
            
            result["success_rate"] = round(success_rate, 1)
            result["summary"] = f"Обработано {result.get('feeds_processed', 0)}/{result.get('feeds_total', 0)} лент, добавлено {result.get('articles_new', 0)} новых статей"
        
        return result

# Создаем глобальный экземпляр диспетчера
dispatcher = Dispatcher()