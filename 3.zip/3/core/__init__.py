"""
Crypto News Aggregator - Core Module
Created: 2025-06-18 19:22:01 UTC
User: phrphrphr
Version: 3.0.0

Ядро системы агрегации криптоновостей
"""

__version__ = "3.0.0"
__author__ = "phrphrphr"
__created__ = "2025-06-18 19:22:01"
__updated__ = "2025-06-18 19:22:01"
__description__ = "Crypto News Aggregator Core Module"

# Импорты основных компонентов
try:
    from .config import settings
    from .storage import storage
    from .dispatcher import dispatcher
    
    __all__ = [
        'settings',
        'storage', 
        'dispatcher',
        '__version__',
        '__author__',
        '__created__',
        '__updated__',
        '__description__'
    ]
    
    # Логирование успешной инициализации
    import logging
    logger = logging.getLogger(__name__)
    logger.info(f"✅ Core module v{__version__} инициализирован успешно")
    logger.info(f"   📊 Компоненты: settings, storage, dispatcher")
    logger.info(f"   👤 Автор: {__author__}")
    logger.info(f"   📅 Создан: {__created__}")
    
except ImportError as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"💥 Ошибка инициализации core модуля: {e}")
    
    # Fallback экспорт
    __all__ = [
        '__version__',
        '__author__',
        '__created__',
        '__updated__',
        '__description__'
    ]