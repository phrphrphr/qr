"""
Crypto News Aggregator - Configuration
Created: 2025-06-18 19:13:42 UTC
User: phrphrphr
Version: 3.0.0

Модуль конфигурации приложения
"""

import os
from typing import List
from pathlib import Path
import logging

# Базовый логгер для конфигурации
logger = logging.getLogger("config")

# Пытаемся импортировать pydantic, но с fallback
try:
    from pydantic import BaseModel, Field
    from pydantic_settings import BaseSettings
    PYDANTIC_AVAILABLE = True
    logger.info("✅ Pydantic доступен")
except ImportError:
    logger.warning("⚠️ Pydantic недоступен, используем простую конфигурацию")
    PYDANTIC_AVAILABLE = False
    BaseSettings = object
    Field = lambda default=None, **kwargs: default

# Функция для парсинга RSS лент из строки
def parse_rss_feeds(feeds_str: str) -> List[str]:
    """Парсинг RSS лент из строки"""
    if not feeds_str:
        return [
            "https://cointelegraph.com/rss",
            "https://www.coindesk.com/arc/outboundfeeds/rss/",
            "https://forklog.com/feed/",
            "https://decrypt.co/feed"
        ]
    
    feeds = [feed.strip() for feed in feeds_str.split(",") if feed.strip()]
    return feeds if feeds else [
        "https://cointelegraph.com/rss",
        "https://www.coindesk.com/arc/outboundfeeds/rss/"
    ]

if PYDANTIC_AVAILABLE:
    class Settings(BaseSettings):
        """Настройки приложения с Pydantic"""
        
        # Пути и файлы
        db_path: str = Field(default="data/storage.json", description="Путь к базе данных")
        
        # Настройки парсинга
        parsing_interval_seconds: int = Field(default=1800, description="Интервал парсинга в секундах")
        
        # Логирование
        log_level: str = Field(default="INFO", description="Уровень логирования")
        
        # RSS ленты
        rss_feeds: List[str] = Field(default_factory=list, description="Список RSS лент")
        
        # Сетевые настройки
        api_host: str = Field(default="0.0.0.0", description="Хост API")
        api_port: int = Field(default=8001, description="Порт API")
        dashboard_host: str = Field(default="0.0.0.0", description="Хост Dashboard")
        dashboard_port: int = Field(default=5001, description="Порт Dashboard")
        api_url: str = Field(default="http://api:8001", description="URL API для Dashboard")
        
        # Метаданные
        project_version: str = Field(default="3.0.0", description="Версия проекта")
        project_author: str = Field(default="phrphrphr", description="Автор проекта")
        project_created: str = Field(default="2025-06-18 19:13:42", description="Время создания")
        
        class Config:
            env_file = ".env"
            env_file_encoding = "utf-8"
            case_sensitive = False
        
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            
            # Если RSS ленты не заданы, парсим из переменной окружения
            if not self.rss_feeds:
                feeds_str = os.getenv("RSS_FEEDS", "")
                self.rss_feeds = parse_rss_feeds(feeds_str)
            
            # Создаем директории если их нет
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
            
            logger.info(f"✅ Конфигурация Pydantic: {len(self.rss_feeds)} RSS лент")

else:
    # Fallback класс без Pydantic
    class Settings:
        """Простые настройки без Pydantic"""
        
        def __init__(self):
            # Загружаем .env если есть
            if os.path.exists('.env'):
                try:
                    with open('.env', 'r', encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if '=' in line and not line.startswith('#'):
                                key, value = line.split('=', 1)
                                os.environ[key.strip()] = value.strip()
                    logger.info("✅ .env файл загружен")
                except Exception as e:
                    logger.warning(f"⚠️ Ошибка загрузки .env: {e}")
            
            # Инициализируем настройки
            self.db_path = os.getenv("DB_PATH", "data/storage.json")
            self.parsing_interval_seconds = int(os.getenv("PARSING_INTERVAL_SECONDS", "1800"))
            self.log_level = os.getenv("LOG_LEVEL", "INFO")
            
            # Сетевые настройки
            self.api_host = os.getenv("API_HOST", "0.0.0.0")
            self.api_port = int(os.getenv("API_PORT", "8001"))
            self.dashboard_host = os.getenv("DASHBOARD_HOST", "0.0.0.0")
            self.dashboard_port = int(os.getenv("DASHBOARD_PORT", "5001"))
            self.api_url = os.getenv("API_URL", "http://api:8001")
            
            # Метаданные
            self.project_version = os.getenv("PROJECT_VERSION", "3.0.0")
            self.project_author = os.getenv("PROJECT_AUTHOR", "phrphrphr")
            self.project_created = os.getenv("PROJECT_CREATED", "2025-06-18 19:13:42")
            
            # Парсим RSS ленты
            feeds_str = os.getenv("RSS_FEEDS", "")
            self.rss_feeds = parse_rss_feeds(feeds_str)
            
            # Создаем директории
            try:
                Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
                logger.info("✅ Директории созданы")
            except Exception as e:
                logger.error(f"💥 Ошибка создания директорий: {e}")
            
            logger.info(f"✅ Конфигурация Fallback: {len(self.rss_feeds)} RSS лент")

# Создаем глобальный экземпляр настроек
try:
    settings = Settings()
    logger.info("✅ Настройки успешно инициализированы")
    logger.info(f"📊 Конфигурация:")
    logger.info(f"   🗄️ База данных: {settings.db_path}")
    logger.info(f"   ⏰ Интервал парсинга: {settings.parsing_interval_seconds}s")
    logger.info(f"   📡 RSS лент: {len(settings.rss_feeds)}")
    logger.info(f"   🌐 API: {settings.api_host}:{settings.api_port}")
    logger.info(f"   💻 Dashboard: {settings.dashboard_host}:{settings.dashboard_port}")
except Exception as e:
    logger.error(f"💥 Ошибка инициализации настроек: {e}")
    raise