"""
Crypto News Aggregator - REST API
Created: 2025-06-18 19:13:42 UTC
User: phrphrphr
Version: 3.0.0

FastAPI REST API для агрегатора криптоновостей
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Dict, Any

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

print(f"📡 API запускается...")
print(f"⏰ Время: 2025-06-18 19:13:42 UTC")
print(f"👤 Пользователь: phrphrphr")

# Настраиваем базовое логирование
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # Настраиваем продвинутое логирование
    from utils.logging import setup_logging
    setup_logging()
    from loguru import logger
    logger.info("✅ Продвинутое логирование настроено")
except ImportError:
    logger.warning("⚠️ Loguru недоступен, используем стандартное логирование")

from fastapi import FastAPI, HTTPException, Query, BackgroundTasks, Path as FastPath
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

try:
    from core.storage import storage
    from core.dispatcher import dispatcher
    from core.config import settings
    from utils.helpers import create_response
    logger.info("✅ Все модули импортированы успешно")
except ImportError as e:
    logger.error(f"💥 Ошибка импорта: {e}")
    sys.exit(1)

# Модели данных
class Article(BaseModel):
    title: str = Field(..., description="Заголовок статьи")
    link: str = Field(..., description="Ссылка на статью")
    summary: str = Field(..., description="Краткое описание")
    published: str = Field(..., description="Дата публикации")
    source: str = Field(..., description="Источник")
    hash: str = Field(..., description="Хэш статьи")
    created_at: str = Field(..., description="Дата добавления в базу")

class ArticlesResponse(BaseModel):
    articles: List[Dict] = Field(..., description="Список статей")
    count: int = Field(..., description="Количество статей в ответе")
    total_count: int = Field(..., description="Общее количество статей")
    offset: int = Field(..., description="Смещение")
    limit: int = Field(..., description="Лимит")

class StatsResponse(BaseModel):
    total_articles: int = Field(..., description="Общее количество статей")
    sources_count: int = Field(..., description="Количество источников")
    sources: Dict[str, int] = Field(..., description="Статистика по источникам")
    last_updated: str = Field(..., description="Дата последнего обновления")

class HealthResponse(BaseModel):
    status: str = Field(..., description="Статус сервиса")
    timestamp: str = Field(..., description="Время проверки")
    articles_count: int = Field(..., description="Количество статей")
    version: str = Field(..., description="Версия API")
    uptime: str = Field(..., description="Время работы")

# Создание приложения
app = FastAPI(
    title="Crypto News API",
    description="REST API для агрегатора криптоновостей",
    version="3.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "articles", "description": "Операции со статьями"},
        {"name": "stats", "description": "Статистика"},
        {"name": "system", "description": "Системные операции"},
        {"name": "debug", "description": "Отладка и диагностика"},
    ]
)

# Время запуска для подсчета uptime
startup_time = datetime.utcnow()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_startup
async def startup_event():
    """Событие при запуске приложения"""
    logger.info("🚀 API сервер запущен")
    logger.info(f"📊 Статей в базе: {storage.get_articles_count()}")
    logger.info(f"⚙️ RSS лент настроено: {len(settings.rss_feeds)}")
    logger.info(f"🌐 API доступен на: http://{settings.api_host}:{settings.api_port}")

@app.get("/", tags=["system"])
async def root():
    """Главная страница API"""
    uptime = str(datetime.utcnow() - startup_time)
    
    return create_response(
        status="success",
        data={
            "name": "Crypto News API",
            "version": "3.0.0",
            "description": "REST API для агрегатора криптоновостей",
            "created": "2025-06-18 19:13:42 UTC",
            "author": "phrphrphr",
            "uptime": uptime,
            "endpoints": {
                "articles": "/articles",
                "health": "/health",
                "stats": "/stats",
                "docs": "/docs",
                "redoc": "/redoc"
            }
        },
        message="API работает нормально"
    )

@app.get("/health", response_model=HealthResponse, tags=["system"])
async def health_check():
    """Проверка здоровья сервиса"""
    try:
        articles_count = storage.get_articles_count()
        uptime = str(datetime.utcnow() - startup_time)
        
        return HealthResponse(
            status="healthy",
            timestamp=datetime.utcnow().isoformat() + 'Z',
            articles_count=articles_count,
            version="3.0.0",
            uptime=uptime
        )
    except Exception as e:
        logger.error(f"💥 Health check failed: {e}")
        raise HTTPException(status_code=500, detail="Service unhealthy")

@app.get("/articles", response_model=ArticlesResponse, tags=["articles"])
async def get_articles(
    limit: int = Query(50, ge=1, le=200, description="Количество статей"),
    offset: int = Query(0, ge=0, description="Смещение для пагинации"),
    source: Optional[str] = Query(None, description="Фильтр по источнику")
):
    """Получение списка статей с пагинацией и фильтрацией"""
    try:
        if source:
            all_articles = storage.get_articles_by_source(source)
        else:
            all_articles = storage.get_all_articles()
        
        total_count = len(all_articles)
        
        # Сортировка по дате создания (новые сверху)
        sorted_articles = sorted(
            all_articles, 
            key=lambda x: x.get('created_at', ''), 
            reverse=True
        )
        
        # Пагинация
        paginated_articles = sorted_articles[offset:offset + limit]
        
        logger.info(f"📤 Отдано {len(paginated_articles)} статей из {total_count} (offset: {offset}, limit: {limit})")
        
        return ArticlesResponse(
            articles=paginated_articles,
            count=len(paginated_articles),
            total_count=total_count,
            offset=offset,
            limit=limit
        )
    except Exception as e:
        logger.error(f"💥 Ошибка получения статей: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/articles/count", tags=["articles"])
async def get_articles_count():
    """Получение количества статей"""
    try:
        count = storage.get_articles_count()
        return create_response(
            status="success",
            data={"count": count},
            message=f"В базе {count} статей"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка получения количества: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/stats", response_model=StatsResponse, tags=["stats"])
async def get_stats():
    """Получение статистики"""
    try:
        stats = storage.get_stats()
        return StatsResponse(**stats)
    except Exception as e:
        logger.error(f"💥 Ошибка получения статистики: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/articles/latest/{count}", tags=["articles"])
async def get_latest_articles(count: int = FastPath(..., ge=1, le=100)):
    """Получение последних N статей"""
    try:
        articles = storage.get_recent_articles(count)
        return create_response(
            status="success",
            data={
                "articles": articles,
                "count": len(articles)
            },
            message=f"Получено {len(articles)} последних статей"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка получения последних статей: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/parse/trigger", tags=["system"])
async def trigger_parsing(background_tasks: BackgroundTasks):
    """Принудительный запуск парсинга"""
    try:
        if dispatcher.is_running:
            return create_response(
                status="warning",
                message="Парсинг уже выполняется"
            )
        
        # Запускаем парсинг в фоне
        background_tasks.add_task(dispatcher.run_all_parsers)
        
        return create_response(
            status="success",
            message="Парсинг запущен в фоновом режиме"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка запуска парсинга: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/parse/status", tags=["system"])
async def get_parsing_status():
    """Получение статуса парсинга"""
    try:
        stats = dispatcher.get_stats()
        return create_response(
            status="success",
            data=stats,
            message="Статус парсинга получен"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка получения статуса парсинга: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/debug/database", tags=["debug"])
async def get_database_info():
    """Получение информации о базе данных (отладка)"""
    try:
        db_info = storage.get_database_info()
        validation = storage.validate_database()
        
        return create_response(
            status="success",
            data={
                "database_info": db_info,
                "validation": validation,
                "current_time_utc": datetime.utcnow().isoformat() + 'Z'
            },
            message="Информация о базе данных получена"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка получения информации о БД: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/debug/cleanup", tags=["debug"])
async def cleanup_database(days: int = Query(30, ge=1, le=365, description="Количество дней для хранения")):
    """Очистка старых статей"""
    try:
        cleaned_count = storage.cleanup_old_articles(days)
        return create_response(
            status="success",
            data={"cleaned_articles": cleaned_count},
            message=f"Очищено {cleaned_count} статей старше {days} дней"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка очистки БД: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/debug/feeds", tags=["debug"])
async def get_configured_feeds():
    """Получение списка настроенных RSS лент"""
    try:
        return create_response(
            status="success",
            data={
                "feeds": settings.rss_feeds,
                "count": len(settings.rss_feeds),
                "interval_seconds": settings.parsing_interval_seconds
            },
            message="Список RSS лент получен"
        )
    except Exception as e:
        logger.error(f"💥 Ошибка получения списка лент: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    logger.info(f"🚀 Запуск API сервера на {settings.api_host}:{settings.api_port}")
    uvicorn.run(
        app, 
        host=settings.api_host, 
        port=settings.api_port, 
        log_level="info"
    )