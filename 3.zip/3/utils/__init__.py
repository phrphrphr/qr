"""
Crypto News Aggregator - Utils Module
Created: 2025-06-18 19:22:01 UTC
User: phrphrphr
Version: 3.0.0

Утилиты и вспомогательные функции
"""

__version__ = "3.0.0"
__author__ = "phrphrphr"
__created__ = "2025-06-18 19:22:01"
__updated__ = "2025-06-18 19:22:01"
__description__ = "Crypto News Aggregator Utils Module"

# Импорты утилит
try:
    from .logging import setup_logging, get_logger
    from .helpers import (
        clean_text,
        generate_hash,
        extract_domain,
        format_datetime,
        validate_url,
        sanitize_filename,
        get_file_size_mb,
        create_response,
        format_timedelta,
        safe_get,
        normalize_text,
        is_valid_date,
        get_utc_now,
        calculate_age_minutes,
        slugify,
        truncate_words,
        parse_boolean,
        format_file_size,
        escape_html,
        generate_unique_id,
        is_valid_email,
        extract_keywords
    )
    
    __all__ = [
        # Логирование
        'setup_logging',
        'get_logger',
        
        # Основные хелперы
        'clean_text',
        'generate_hash', 
        'extract_domain',
        'format_datetime',
        'validate_url',
        'sanitize_filename',
        'get_file_size_mb',
        'create_response',
        
        # Дополнительные хелперы
        'format_timedelta',
        'safe_get',
        'normalize_text',
        'is_valid_date',
        'get_utc_now',
        'calculate_age_minutes',
        'slugify',
        'truncate_words',
        'parse_boolean',
        'format_file_size',
        'escape_html',
        'generate_unique_id',
        'is_valid_email',
        'extract_keywords',
        
        # Метаданные
        '__version__',
        '__author__',
        '__created__',
        '__updated__',
        '__description__'
    ]
    
    # Логирование успешной инициализации
    import logging
    logger = logging.getLogger(__name__)
    logger.info(f"✅ Utils module v{__version__} инициализирован успешно")
    logger.info(f"   🛠️ Доступно функций: {len(__all__) - 5}")
    logger.info(f"   👤 Автор: {__author__}")
    
except ImportError as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"💥 Ошибка инициализации utils модуля: {e}")
    
    # Fallback экспорт
    __all__ = [
        '__version__',
        '__author__',
        '__created__',
        '__updated__',
        '__description__'
    ]