"""
Crypto News Aggregator - Helper Functions
Created: 2025-06-18 19:18:11 UTC
User: phrphrphr
Version: 3.0.0

Вспомогательные функции и утилиты
"""

import re
import hashlib
from datetime import datetime
from typing import Optional, Dict, Any, Union
from urllib.parse import urlparse
from pathlib import Path

def clean_text(text: str, max_length: int = 500) -> str:
    """Очистка текста от HTML тегов и форматирование"""
    if not text:
        return "Описание недоступно"
    
    # Убираем HTML теги
    clean_text = re.sub(r'<[^>]+>', '', str(text))
    
    # Убираем специальные HTML сущности
    html_entities = {
        '&amp;': '&',
        '&lt;': '<',
        '&gt;': '>',
        '&quot;': '"',
        '&#39;': "'",
        '&nbsp;': ' ',
        '&mdash;': '—',
        '&ndash;': '–',
        '&hellip;': '…',
        '&laquo;': '«',
        '&raquo;': '»'
    }
    
    for entity, replacement in html_entities.items():
        clean_text = clean_text.replace(entity, replacement)
    
    # Убираем лишние пробелы и переносы
    clean_text = re.sub(r'\s+', ' ', clean_text).strip()
    
    # Убираем множественные точки и восклицательные знаки
    clean_text = re.sub(r'\.{3,}', '…', clean_text)
    clean_text = re.sub(r'!{2,}', '!', clean_text)
    clean_text = re.sub(r'\?{2,}', '?', clean_text)
    
    # Ограничиваем длину
    if len(clean_text) > max_length:
        # Ищем последний пробел перед лимитом
        truncated = clean_text[:max_length]
        last_space = truncated.rfind(' ')
        if last_space > max_length * 0.8:  # Если пробел не слишком далеко
            clean_text = truncated[:last_space] + "..."
        else:
            clean_text = truncated + "..."
    
    return clean_text if clean_text else "Описание недоступно"

def generate_hash(content: str) -> str:
    """Генерация MD5 хэша для контента"""
    return hashlib.md5(str(content).encode('utf-8')).hexdigest()

def extract_domain(url: str) -> str:
    """Извлечение домена из URL"""
    try:
        parsed = urlparse(str(url))
        domain = parsed.netloc
        
        # Убираем www. если есть
        if domain.startswith('www.'):
            domain = domain[4:]
        
        return domain or 'Неизвестный источник'
    except Exception:
        return 'Неизвестный источник'

def format_datetime(dt_input: Optional[Union[str, datetime]]) -> str:
    """Форматирование даты и времени в ISO формат UTC"""
    if not dt_input:
        return datetime.utcnow().isoformat() + 'Z'
    
    try:
        # Если уже datetime объект
        if isinstance(dt_input, datetime):
            return dt_input.isoformat() + 'Z'
        
        dt_string = str(dt_input).strip()
        
        # Если уже в правильном ISO формате
        if isinstance(dt_string, str) and 'T' in dt_string:
            # Нормализуем окончание
            if dt_string.endswith('Z'):
                return dt_string
            elif '+' in dt_string[-6:] or dt_string[-6:-3] == '-' and dt_string[-2:].isdigit():
                # Конвертируем в UTC
                try:
                    dt = datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
                    return dt.astimezone().utctimetuple()
                    return datetime(*dt.utctimetuple()[:6]).isoformat() + 'Z'
                except:
                    pass
            else:
                return dt_string + 'Z'
        
        # Пытаемся парсить RFC 2822 формат (из RSS)
        try:
            from email.utils import parsedate_tz, mktime_tz
            parsed = parsedate_tz(dt_string)
            if parsed:
                timestamp = mktime_tz(parsed)
                return datetime.utcfromtimestamp(timestamp).isoformat() + 'Z'
        except:
            pass
        
        # Пытаемся другие форматы с dateutil
        try:
            from dateutil import parser
            dt = parser.parse(dt_string)
            return dt.isoformat() + 'Z'
        except:
            pass
        
        # Пытаемся стандартный парсинг
        try:
            dt = datetime.fromisoformat(str(dt_string).replace('Z', '+00:00'))
            return dt.astimezone().utctimetuple()
            return datetime(*dt.utctimetuple()[:6]).isoformat() + 'Z'
        except:
            pass
        
    except Exception as e:
        pass
    
    # В случае ошибки возвращаем текущее время
    return datetime.utcnow().isoformat() + 'Z'

def validate_url(url: str) -> bool:
    """Проверка валидности URL"""
    try:
        result = urlparse(str(url))
        return all([
            result.scheme in ['http', 'https'], 
            result.netloc,
            len(result.netloc) > 3
        ])
    except Exception:
        return False

def sanitize_filename(filename: str) -> str:
    """Очистка имени файла от недопустимых символов"""
    # Убираем недопустимые символы для имени файла
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', str(filename))
    
    # Убираем точки в начале и конце
    sanitized = sanitized.strip('.')
    
    # Ограничиваем длину
    if len(sanitized) > 100:
        name_part = sanitized[:90]
        extension = sanitized[90:]
        if '.' in extension:
            ext = extension[extension.rfind('.'):]
            sanitized = name_part + ext
        else:
            sanitized = name_part
    
    return sanitized or "unnamed_file"

def get_file_size_mb(file_path: str) -> float:
    """Получение размера файла в мегабайтах"""
    try:
        size_bytes = Path(file_path).stat().st_size
        return round(size_bytes / (1024 * 1024), 2)
    except Exception:
        return 0.0

def create_response(status: str, data: Any = None, message: str = "", **kwargs) -> Dict:
    """Создание стандартного ответа API"""
    response = {
        "status": status,
        "timestamp": datetime.utcnow().isoformat() + 'Z',
        "message": message
    }
    
    if data is not None:
        response["data"] = data
    
    response.update(kwargs)
    return response

def format_timedelta(seconds: float) -> str:
    """Форматирование времени выполнения"""
    if seconds < 1:
        return f"{int(seconds * 1000)}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"

def safe_get(data: Dict, key: str, default: Any = None) -> Any:
    """Безопасное получение значения из словаря"""
    try:
        return data.get(key, default) if isinstance(data, dict) else default
    except Exception:
        return default

def normalize_text(text: str) -> str:
    """Нормализация текста для поиска и сравнения"""
    if not text:
        return ""
    
    # Приводим к нижнему регистру и убираем лишние пробелы
    normalized = re.sub(r'\s+', ' ', str(text).lower().strip())
    
    # Убираем специальные символы, оставляем только буквы, цифры, пробелы и дефисы
    normalized = re.sub(r'[^\w\s-]', '', normalized)
    
    return normalized

def is_valid_date(date_string: str) -> bool:
    """Проверка валидности даты"""
    if not date_string:
        return False
    
    try:
        datetime.fromisoformat(str(date_string).replace('Z', '+00:00'))
        return True
    except:
        try:
            from email.utils import parsedate_tz
            return parsedate_tz(date_string) is not None
        except:
            return False

def get_utc_now() -> str:
    """Получение текущего времени в UTC ISO формате"""
    return datetime.utcnow().isoformat() + 'Z'

def calculate_age_minutes(created_at: str) -> int:
    """Вычисление возраста записи в минутах"""
    try:
        created = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
        now = datetime.utcnow().replace(tzinfo=created.tzinfo)
        return int((now - created).total_seconds() / 60)
    except:
        return 0

def slugify(text: str) -> str:
    """Создание URL-friendly строки"""
    # Приводим к нижнему регистру
    text = str(text).lower()
    
    # Заменяем пробелы и специальные символы на дефисы
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    
    # Убираем дефисы в начале и конце
    return text.strip('-')

def truncate_words(text: str, max_words: int = 50) -> str:
    """Обрезание текста по количеству слов"""
    if not text:
        return ""
    
    words = str(text).split()
    if len(words) <= max_words:
        return text
    
    return ' '.join(words[:max_words]) + "..."

def parse_boolean(value: Any) -> bool:
    """Парсинг булевого значения из строки"""
    if isinstance(value, bool):
        return value
    
    if isinstance(value, str):
        return value.lower() in ('true', '1', 'yes', 'on', 'enabled')
    
    return bool(value)

def format_file_size(size_bytes: int) -> str:
    """Форматирование размера файла в человекочитаемый формат"""
    if size_bytes == 0:
        return "0 B"
    
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    unit_index = 0
    size = float(size_bytes)
    
    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1
    
    return f"{size:.1f} {units[unit_index]}"

def escape_html(text: str) -> str:
    """Экранирование HTML символов"""
    if not text:
        return ""
    
    html_escape_table = {
        "&": "&amp;",
        '"': "&quot;",
        "'": "&#x27;",
        ">": "&gt;",
        "<": "&lt;",
    }
    
    return "".join(html_escape_table.get(c, c) for c in str(text))

def generate_unique_id() -> str:
    """Генерация уникального ID"""
    from uuid import uuid4
    return str(uuid4())

def is_valid_email(email: str) -> bool:
    """Проверка валидности email адреса"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, str(email)) is not None

def extract_keywords(text: str, min_length: int = 3) -> list:
    """Извлечение ключевых слов из текста"""
    if not text:
        return []
    
    # Убираем HTML теги и специальные символы
    clean = re.sub(r'<[^>]+>', '', str(text))
    clean = re.sub(r'[^\w\s]', ' ', clean)
    
    # Разбиваем на слова
    words = clean.lower().split()
    
    # Фильтруем по длине и убираем стоп-слова
    stop_words = {
        'и', 'в', 'на', 'с', 'по', 'для', 'от', 'до', 'из', 'о', 'об', 'к', 'у',
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'
    }
    
    keywords = [
        word for word in words 
        if len(word) >= min_length and word not in stop_words
    ]
    
    # Убираем дубликаты, сохраняя порядок
    seen = set()
    unique_keywords = []
    for word in keywords:
        if word not in seen:
            seen.add(word)
            unique_keywords.append(word)
    
    return unique_keywords[:20]  # Максимум 20 ключевых слов