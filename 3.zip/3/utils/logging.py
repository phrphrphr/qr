"""
Crypto News Aggregator - Logging Configuration
Created: 2025-06-18 19:18:11 UTC
User: phrphrphr
Version: 3.0.0

Настройка системы логирования
"""

import sys
import os
from pathlib import Path

def setup_logging():
    """Настройка системы логирования"""
    
    try:
        from loguru import logger
        
        # Удаляем стандартный обработчик
        logger.remove()
        
        # Получаем уровень логирования из переменной окружения
        log_level = os.getenv("LOG_LEVEL", "INFO")
        
        # Добавляем консольный вывод с цветами
        logger.add(
            sys.stdout,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
            level=log_level,
            colorize=True,
            backtrace=True,
            diagnose=True
        )
        
        # Создаем директорию для логов
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        # Добавляем файловый вывод для всех логов
        logger.add(
            logs_dir / "app.log",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
            level=log_level,
            rotation="10 MB",
            retention="30 days",
            compression="zip",
            encoding="utf-8",
            backtrace=True,
            diagnose=True
        )
        
        # Добавляем отдельный файл для ошибок
        logger.add(
            logs_dir / "errors.log",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
            level="ERROR",
            rotation="5 MB",
            retention="60 days",
            compression="zip",
            encoding="utf-8",
            backtrace=True,
            diagnose=True
        )
        
        # Добавляем отдельный файл для отладки
        logger.add(
            logs_dir / "debug.log",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
            level="DEBUG",
            rotation="20 MB",
            retention="7 days",
            compression="zip",
            encoding="utf-8",
            backtrace=True,
            diagnose=True
        )
        
        # Специальный лог для RSS парсинга
        logger.add(
            logs_dir / "rss_parser.log",
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
            level="INFO",
            rotation="5 MB",
            retention="14 days",
            compression="zip",
            encoding="utf-8",
            filter=lambda record: "rss" in record["name"].lower() or "parser" in record["name"].lower()
        )
        
        logger.info(f"✅ Loguru настроен успешно (уровень: {log_level})")
        logger.info(f"📁 Логи сохраняются в: {logs_dir.absolute()}")
        
        return logger
        
    except ImportError:
        # Fallback на стандартное логирование
        import logging
        from logging.handlers import RotatingFileHandler
        
        # Создаем директорию для логов
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        # Настраиваем форматтер
        formatter = logging.Formatter(
            '%(asctime)s | %(name)-12s | %(levelname)-8s | %(funcName)s:%(lineno)d - %(message)s'
        )
        
        # Создаем логгер
        logger = logging.getLogger('crypto_news')
        logger.setLevel(getattr(logging, os.getenv("LOG_LEVEL", "INFO")))
        
        # Консольный вывод
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # Файловый вывод для всех логов
        file_handler = RotatingFileHandler(
            logs_dir / "app.log",
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        # Файловый вывод для ошибок
        error_handler = RotatingFileHandler(
            logs_dir / "errors.log",
            maxBytes=5*1024*1024,  # 5MB
            backupCount=10,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)
        logger.addHandler(error_handler)
        
        logger.info(f"✅ Стандартное логирование настроено (уровень: {os.getenv('LOG_LEVEL', 'INFO')})")
        logger.info(f"📁 Логи сохраняются в: {logs_dir.absolute()}")
        
        return logger

def get_logger(name: str = None):
    """Получение настроенного логгера"""
    try:
        from loguru import logger
        return logger
    except ImportError:
        import logging
        return logging.getLogger(name or 'crypto_news')

# Инициализируем логирование при импорте
logger = setup_logging()