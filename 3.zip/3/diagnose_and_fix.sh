#!/bin/bash

# Диагностика и исправление проблем
# Current Time: 2025-06-18 19:00:52 UTC
# User: phrphrphr

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}✅ $1${NC}"; }
log_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_step() { echo -e "${BLUE}🔧 $1${NC}"; }

echo -e "${BLUE}🔍 Диагностика проблемы с crypto_backend${NC}"
echo

# 1. Проверяем логи backend контейнера
log_step "Проверяю логи backend контейнера..."
docker-compose logs backend

echo
log_step "Проверяю статус всех контейнеров..."
docker-compose ps

echo
log_step "Проверяю health check backend..."
docker inspect crypto_backend --format='{{.State.Health.Status}}' 2>/dev/null || echo "Health status недоступен"

# 2. Пытаемся запустить backend вручную для диагностики
echo
log_step "Тестирую backend вручную..."
docker run --rm -it \
  -v "$(pwd)/data:/app/data" \
  -v "$(pwd)/logs:/app/logs" \
  --env-file .env \
  2-backend:latest python -c "
import sys
print('Python версия:', sys.version)
try:
    from core.config import settings
    print('✅ Конфигурация загружена')
    print('RSS лент:', len(settings.rss_feeds))
except Exception as e:
    print('❌ Ошибка конфигурации:', e)

try:
    from core.storage import storage
    print('✅ Хранилище инициализировано')
except Exception as e:
    print('❌ Ошибка хранилища:', e)

try:
    from core.dispatcher import dispatcher
    print('✅ Диспетчер инициализирован')
except Exception as e:
    print('❌ Ошибка диспетчера:', e)
"