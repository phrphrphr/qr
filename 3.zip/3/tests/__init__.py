"""
Crypto News Aggregator - Tests Package
Created: 2025-06-18 19:22:01 UTC
User: phrphrphr
Version: 3.0.0

Test suite for the Crypto News Aggregator application
"""

__version__ = "3.0.0"
__author__ = "phrphrphr"
__created__ = "2025-06-18 19:22:01"
__updated__ = "2025-06-18 19:22:01"
__description__ = "Crypto News Aggregator Test Suite"

import sys
from pathlib import Path

# Добавляем родительскую директорию в путь для тестов
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Настройка для тестов
import os
os.environ['LOG_LEVEL'] = 'WARNING'  # Уменьшаем количество логов в тестах
os.environ['DB_PATH'] = 'tests/test_storage.json'  # Тестовая база данных

# Импорты для тестов
try:
    import pytest
    import asyncio
    from unittest.mock import patch, MagicMock
    
    TESTING_DEPENDENCIES_AVAILABLE = True
    
except ImportError:
    TESTING_DEPENDENCIES_AVAILABLE = False
    import warnings
    warnings.warn(
        "Зависимости для тестирования не установлены. "
        "Установите: pip install pytest pytest-asyncio httpx"
    )

# Утилиты для тестов
class TestConfig:
    """Конфигурация для тестов"""
    
    DB_PATH = "tests/test_storage.json"
    TEST_RSS_FEEDS = [
        "https://example.com/test-feed-1.xml",
        "https://example.com/test-feed-2.xml"
    ]
    API_BASE_URL = "http://localhost:8001"
    DASHBOARD_BASE_URL = "http://localhost:5001"

def cleanup_test_files():
    """Очистка тестовых файлов"""
    test_files = [
        Path("tests/test_storage.json"),
        Path("tests/test_logs"),
        Path("tests/__pycache__")
    ]
    
    for file_path in test_files:
        if file_path.exists():
            if file_path.is_file():
                file_path.unlink()
            elif file_path.is_dir():
                import shutil
                shutil.rmtree(file_path)

def setup_test_environment():
    """Настройка тестового окружения"""
    # Создаем директорию для тестов
    Path("tests").mkdir(exist_ok=True)
    
    # Устанавливаем тестовые переменные окружения
    test_env = {
        'DB_PATH': TestConfig.DB_PATH,
        'LOG_LEVEL': 'WARNING',
        'RSS_FEEDS': ','.join(TestConfig.TEST_RSS_FEEDS),
        'PARSING_INTERVAL_SECONDS': '60',  # Короткий интервал для тестов
        'API_HOST': '127.0.0.1',
        'API_PORT': '8001',
        'DASHBOARD_HOST': '127.0.0.1',
        'DASHBOARD_PORT': '5001'
    }
    
    for key, value in test_env.items():
        os.environ[key] = value

# Автоматическая настройка при импорте
if TESTING_DEPENDENCIES_AVAILABLE:
    setup_test_environment()

__all__ = [
    'TestConfig',
    'cleanup_test_files',
    'setup_test_environment',
    'TESTING_DEPENDENCIES_AVAILABLE',
    '__version__',
    '__author__',
    '__created__',
    '__updated__',
    '__description__'
]