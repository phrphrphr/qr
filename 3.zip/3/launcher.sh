#!/bin/bash

# Crypto News Aggregator - Simple Working Launcher
# Created: 2025-06-18 20:23:39 UTC
# User: phrphrphr

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${CYAN}${BOLD}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║         🚀 CRYPTO NEWS AGGREGATOR LAUNCHER 🚀             ║"
echo "║         Created: 2025-06-18 20:23:39 UTC                  ║"
echo "║         User: phrphrphr                                    ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

cd "$(dirname "$0")"

# Функции
msg() { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
err() { echo -e "${RED}❌ $1${NC}"; }
step() { echo -e "${BLUE}🔧 $1${NC}"; }

# Проверка Docker
if ! command -v docker >/dev/null 2>&1; then
    err "Docker не установлен"
    exit 1
fi

if ! command -v docker-compose >/dev/null 2>&1; then
    err "Docker Compose не установлен"
    exit 1
fi

msg "Docker найден"

# Создание файлов
step "Создаю необходимые файлы..."
mkdir -p data logs

# Создаем .env
cat > .env << 'EOF'
FLASK_APP=dashboard.py
FLASK_ENV=production
DB_PATH=data/storage.json
PARSING_INTERVAL_SECONDS=1800
RSS_FEEDS=https://cointelegraph.com/rss,https://www.coindesk.com/arc/outboundfeeds/rss/
LOG_LEVEL=INFO
API_HOST=0.0.0.0
API_PORT=8001
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=5001
API_URL=http://api:8001
EOF

# Создаем базу данных
cat > data/storage.json << 'EOF'
{
  "_default": {},
  "articles": {
    "1": []
  }
}
EOF

msg "Файлы созданы"

# Функция остановки
stop_all() {
    step "Останавливаю контейнеры..."
    docker-compose down --remove-orphans 2>/dev/null || true
    docker stop $(docker ps -q --filter "name=crypto") 2>/dev/null || true
    docker rm $(docker ps -aq --filter "name=crypto") 2>/dev/null || true
    msg "Контейнеры остановлены"
}

# Функция запуска
start_all() {
    step "Запускаю систему..."
    stop_all
    
    step "Сборка образов..."
    docker-compose build --no-cache
    
    step "Запуск контейнеров..."
    docker-compose up -d
    
    step "Ожидание готовности..."
    sleep 15
    
    # Проверка
    if curl -s http://localhost:8001/health >/dev/null; then
        msg "API готов (8001)"
    else
        warn "API не отвечает (8001)"
    fi
    
    if curl -s http://localhost:5001 >/dev/null; then
        msg "Dashboard готов (5001)"
    else
        warn "Dashboard не отвечает (5001)"
    fi
}

# Функция статуса
show_status() {
    step "Статус контейнеров:"
    docker ps --format "table {{.Names}}\t{{.Status}}" --filter "name=crypto" 2>/dev/null || echo "Нет контейнеров"
    
    echo
    step "Проверка сервисов:"
    
    if curl -s http://localhost:8001/health >/dev/null 2>&1; then
        msg "API (8001) - работает"
    else
        err "API (8001) - не работает"
    fi
    
    if curl -s http://localhost:5001 >/dev/null 2>&1; then
        msg "Dashboard (5001) - работает"
    else
        err "Dashboard (5001) - не работает"
    fi
}

# Главное меню
while true; do
    echo
    echo -e "${BOLD}=== ГЛАВНОЕ МЕНЮ ===${NC}"
    echo "1) 🚀 Запустить систему"
    echo "2) ⏹️  Остановить систему" 
    echo "3) 📊 Показать статус"
    echo "4) 📋 Показать логи"
    echo "5) 🌐 Открыть веб-интерфейс"
    echo "0) 🚪 Выход"
    echo
    
    read -p "Выберите действие (0-5): " choice
    
    case $choice in
        1)
            start_all
            echo
            msg "Веб-интерфейс: http://localhost:5001"
            msg "API: http://localhost:8001/docs"
            ;;
        2)
            stop_all
            ;;
        3)
            show_status
            ;;
        4)
            echo "Выберите контейнер:"
            echo "1) Backend"
            echo "2) API"
            echo "3) Dashboard"
            echo "4) Все"
            read -p "Выбор: " log_choice
            
            case $log_choice in
                1) docker-compose logs crypto_backend ;;
                2) docker-compose logs crypto_api ;;
                3) docker-compose logs crypto_dashboard ;;
                4) docker-compose logs ;;
                *) warn "Неверный выбор" ;;
            esac
            ;;
        5)
            if command -v xdg-open >/dev/null 2>&1; then
                xdg-open "http://localhost:5001" &
                msg "Браузер открыт"
            else
                msg "Откройте: http://localhost:5001"
            fi
            ;;
        0)
            msg "Выход"
            exit 0
            ;;
        *)
            warn "Неверный выбор"
            ;;
    esac
    
    echo
    read -p "Нажмите Enter для продолжения..."
done