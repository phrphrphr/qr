"""
Crypto News Aggregator - Web Dashboard
Created: 2025-06-18 19:13:42 UTC
User: phrphrphr
Version: 3.0.0

Flask веб-интерфейс для агрегатора криптоновостей
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

print(f"💻 Dashboard запускается...")
print(f"⏰ Время: 2025-06-18 19:13:42 UTC")
print(f"👤 Пользователь: phrphrphr")

# Настраиваем базовое логирование
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # Настраиваем продвинутое логирование
    from utils.logging import setup_logging
    setup_logging()
    from loguru import logger
    logger.info("✅ Продвинутое логирование настроено")
except ImportError:
    logger.warning("⚠️ Loguru недоступен, используем стандартное логирование")

from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
import requests

try:
    from core.config import settings
    logger.info("✅ Конфигурация загружена")
except ImportError:
    # Fallback настройки
    logger.warning("⚠️ Не удалось загрузить конфигурацию, используем fallback")
    class Settings:
        api_url = os.getenv('API_URL', 'http://localhost:8001')
        dashboard_host = os.getenv('DASHBOARD_HOST', '0.0.0.0')
        dashboard_port = int(os.getenv('DASHBOARD_PORT', '5001'))
    
    settings = Settings()

# Создание приложения Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'crypto-news-secret-key-2025-06-18-19-13-42'
app.config['JSON_AS_ASCII'] = False

# URL API
API_BASE_URL = getattr(settings, 'api_url', os.getenv('API_URL', 'http://api:8001'))

def make_api_request(endpoint: str, timeout: int = 10, **params) -> Dict[str, Any]:
    """Универсальная функция для запросов к API"""
    try:
        url = f"{API_BASE_URL}{endpoint}"
        logger.debug(f"🔍 API запрос: {url} с параметрами {params}")
        
        response = requests.get(url, params=params, timeout=timeout)
        response.raise_for_status()
        
        data = response.json()
        logger.debug(f"📤 API ответ: статус {response.status_code}")
        
        return data
        
    except requests.exceptions.Timeout:
        logger.error(f"⏰ Таймаут запроса к {endpoint}")
        return {"error": "Таймаут запроса", "status": "timeout"}
    except requests.exceptions.ConnectionError:
        logger.error(f"🔌 Ошибка подключения к {endpoint}")
        return {"error": "Нет соединения с API", "status": "connection_error"}
    except requests.exceptions.RequestException as e:
        logger.error(f"💥 Ошибка запроса к {endpoint}: {e}")
        return {"error": str(e), "status": "request_error"}
    except ValueError as e:
        logger.error(f"💥 Ошибка парсинга JSON: {e}")
        return {"error": "Неверный формат ответа", "status": "json_error"}
    except Exception as e:
        logger.error(f"💥 Неожиданная ошибка: {e}")
        return {"error": str(e), "status": "unknown_error"}

@app.route('/')
def index():
    """Главная страница"""
    try:
        # Получаем параметры из URL
        page = max(1, int(request.args.get('page', 1)))
        per_page = max(1, min(int(request.args.get('per_page', 20)), 50))  # Максимум 50
        source_filter = request.args.get('source', '').strip()
        
        # Вычисляем offset
        offset = (page - 1) * per_page
        
        # Параметры для API
        api_params = {'limit': per_page, 'offset': offset}
        if source_filter:
            api_params['source'] = source_filter
        
        # Получаем данные
        articles_response = make_api_request('/articles', **api_params)
        stats_response = make_api_request('/stats', timeout=5)
        
        # Обрабатываем ответы
        articles = articles_response.get('articles', [])
        total_count = articles_response.get('total_count', 0)
        
        # Информация о пагинации
        total_pages = max(1, (total_count + per_page - 1) // per_page) if total_count > 0 else 1
        has_prev = page > 1
        has_next = page < total_pages
        
        # Получаем список источников для фильтра
        sources = []
        if isinstance(stats_response, dict) and 'sources' in stats_response:
            sources = list(stats_response['sources'].keys())
        
        logger.info(f"📰 Отображаю страницу {page} с {len(articles)} статьями")
        
        return render_template(
            'index.html', 
            articles=articles,
            articles_count=len(articles),
            total_count=total_count,
            stats=stats_response,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
            has_prev=has_prev,
            has_next=has_next,
            source_filter=source_filter,
            sources=sources,
            api_error=articles_response.get('error')
        )
        
    except ValueError as e:
        logger.error(f"💥 Ошибка параметров: {e}")
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"💥 Ошибка главной страницы: {e}")
        return render_template(
            'error.html',
            error_title="Ошибка загрузки",
            error_message=str(e)
        ), 500

@app.route('/api/status')
def api_status():
    """Статус системы для AJAX"""
    try:
        health_response = make_api_request('/health', timeout=5)
        
        if health_response.get('status') == 'healthy':
            return jsonify({
                "status": "ok",
                "articles_count": health_response.get("articles_count", 0),
                "timestamp": datetime.utcnow().isoformat() + 'Z',
                "version": health_response.get("version", "unknown"),
                "uptime": health_response.get("uptime", "unknown")
            })
        else:
            return jsonify({
                "status": "error",
                "articles_count": 0,
                "error": health_response.get('error', 'API недоступен'),
                "timestamp": datetime.utcnow().isoformat() + 'Z'
            })
    except Exception as e:
        logger.error(f"💥 Ошибка проверки статуса: {e}")
        return jsonify({
            "status": "error",
            "articles_count": 0,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat() + 'Z'
        })

@app.route('/stats')
def stats_page():
    """Страница статистики"""
    try:
        stats = make_api_request('/stats')
        parse_status = make_api_request('/parse/status')
        db_info = make_api_request('/debug/database')
        
        return render_template(
            'stats.html', 
            stats=stats,
            parse_status=parse_status,
            db_info=db_info
        )
    except Exception as e:
        logger.error(f"💥 Ошибка страницы статистики: {e}")
        return render_template(
            'error.html',
            error_title="Ошибка статистики",
            error_message=str(e)
        ), 500

@app.route('/parse/trigger', methods=['POST'])
def trigger_parse():
    """Принудительный запуск парсинга"""
    try:
        response = requests.post(f"{API_BASE_URL}/parse/trigger", timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            flash(data.get('message', 'Парсинг запущен'), 'success')
        else:
            flash('Ошибка запуска парсинга', 'error')
            
    except Exception as e:
        logger.error(f"💥 Ошибка запуска парсинга: {e}")
        flash(f'Ошибка: {str(e)}', 'error')
    
    return redirect(url_for('stats_page'))

@app.route('/health')
def health():
    """Health check для Docker"""
    try:
        # Проверяем доступность API
        health_response = make_api_request('/health', timeout=3)
        
        if health_response.get('status') == 'healthy':
            return jsonify({
                "status": "healthy", 
                "dashboard": "ok",
                "api_connection": "ok",
                "timestamp": datetime.utcnow().isoformat() + 'Z',
                "version": "3.0.0",
                "created": "2025-06-18 19:13:42 UTC",
                "user": "phrphrphr"
            }), 200
        else:
            return jsonify({
                "status": "unhealthy", 
                "reason": "API unavailable",
                "dashboard": "ok",
                "api_connection": "failed",
                "timestamp": datetime.utcnow().isoformat() + 'Z'
            }), 503
    except Exception as e:
        return jsonify({
            "status": "unhealthy", 
            "reason": str(e),
            "dashboard": "ok",
            "api_connection": "failed",
            "timestamp": datetime.utcnow().isoformat() + 'Z'
        }), 503

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"💥 Внутренняя ошибка: {error}")
    return render_template('500.html'), 500

# Глобальные переменные для шаблонов
@app.context_processor
def inject_globals():
    return {
        'current_year': datetime.now().year,
        'app_version': '3.0.0',
        'api_url': API_BASE_URL,
        'created_time': '2025-06-18 19:13:42 UTC',
        'author': 'phrphrphr'
    }

if __name__ == '__main__':
    logger.info("🚀 Запуск Dashboard сервера")
    logger.info(f"🌐 API URL: {API_BASE_URL}")
    logger.info(f"📍 Dashboard будет доступен на: http://{getattr(settings, 'dashboard_host', '0.0.0.0')}:{getattr(settings, 'dashboard_port', 5001)}")
    
    # Запускаем сервер
    app.run(
        host=getattr(settings, 'dashboard_host', '0.0.0.0'), 
        port=getattr(settings, 'dashboard_port', 5001), 
        debug=False
    )