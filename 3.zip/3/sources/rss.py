"""
Crypto News Aggregator - RSS Parser
Created: 2025-06-18 19:22:01 UTC
User: phrphrphr
Version: 3.0.0

RSS парсер для агрегации криптоновостей
"""

import asyncio
import re
from typing import List, Dict, Optional
import feedparser
from datetime import datetime
from loguru import logger
from utils.helpers import clean_text, extract_domain, format_datetime, validate_url

class RSSParser:
    """Парсер RSS лент"""
    
    def __init__(self):
        self.total_parsed = 0
        self.total_errors = 0
        self.total_feeds_processed = 0
        
        # User-Agent для избежания блокировок
        self.user_agent = "Mozilla/5.0 (compatible; CryptoNewsBot/3.0; +https://cryptonews.example.com/bot) RSS Parser"
        feedparser.USER_AGENT = self.user_agent
        
        # Настройки парсера
        self.timeout = 30  # Таймаут для запросов
        self.max_articles_per_feed = 50  # Максимум статей с одной ленты
        
        logger.info(f"🤖 RSS Parser инициализирован")
        logger.info(f"   User-Agent: {self.user_agent}")
        logger.info(f"   Таймаут: {self.timeout}s")
        logger.info(f"   Макс. статей на ленту: {self.max_articles_per_feed}")
    
    async def parse_feed(self, url: str) -> List[Dict]:
        """Парсинг одной RSS ленты"""
        if not validate_url(url):
            logger.error(f"❌ Невалидный URL: {url}")
            self.total_errors += 1
            return []
        
        try:
            logger.info(f"🔍 Начинаю парсинг: {url}")
            start_time = datetime.utcnow()
            
            # Парсим RSS в отдельном потоке с таймаутом
            feed = await asyncio.wait_for(
                asyncio.to_thread(feedparser.parse, url),
                timeout=self.timeout
            )
            
            # Увеличиваем счетчик обработанных лент
            self.total_feeds_processed += 1
            
            # Проверяем наличие ошибок парсинга
            if hasattr(feed, 'bozo') and feed.bozo:
                logger.warning(f"⚠️ RSS лента имеет проблемы: {url}")
                if hasattr(feed, 'bozo_exception'):
                    logger.warning(f"   Детали ошибки: {feed.bozo_exception}")
                
                # Если критическая ошибка, пропускаем
                if "not well-formed" in str(getattr(feed, 'bozo_exception', '')).lower():
                    logger.error(f"❌ Критическая ошибка XML в {url}")
                    self.total_errors += 1
                    return []
            
            # Проверяем наличие записей
            if not hasattr(feed, 'entries') or not feed.entries:
                logger.warning(f"⚠️ RSS лента пуста или недоступна: {url}")
                return []
            
            articles = []
            source_title = self._get_source_title(feed, url)
            
            logger.info(f"📊 Найдено {len(feed.entries)} записей в {source_title}")
            
            # Обрабатываем записи (максимум установленного лимита)
            processed_count = 0
            for i, entry in enumerate(feed.entries[:self.max_articles_per_feed]):
                try:
                    article = self._parse_entry(entry, source_title)
                    if article:
                        articles.append(article)
                        processed_count += 1
                except Exception as e:
                    logger.error(f"💥 Ошибка обработки записи #{i} из {url}: {e}")
                    continue
            
            # Обновляем статистику
            self.total_parsed += len(articles)
            parsing_time = (datetime.utcnow() - start_time).total_seconds()
            
            logger.info(f"✅ {source_title}: обработано {processed_count}/{len(feed.entries)} записей за {parsing_time:.2f}s")
            
            return articles
            
        except asyncio.TimeoutError:
            logger.error(f"⏰ Таймаут при парсинге {url} (>{self.timeout}s)")
            self.total_errors += 1
            return []
        except Exception as e:
            self.total_errors += 1
            logger.error(f"💥 Критическая ошибка парсинга {url}: {e}")
            return []
    
    def _get_source_title(self, feed, url: str) -> str:
        """Получение названия источника"""
        try:
            if hasattr(feed, 'feed'):
                # Пробуем получить title
                if hasattr(feed.feed, 'title') and feed.feed.title:
                    title = clean_text(feed.feed.title, 100).strip()
                    if title and title != "Описание недоступно":
                        return title
                
                # Пробуем получить subtitle
                if hasattr(feed.feed, 'subtitle') and feed.feed.subtitle:
                    subtitle = clean_text(feed.feed.subtitle, 100).strip()
                    if subtitle and subtitle != "Описание недоступно":
                        return subtitle
                
                # Пробуем получить description
                if hasattr(feed.feed, 'description') and feed.feed.description:
                    description = clean_text(feed.feed.description, 100).strip()
                    if description and description != "Описание недоступно":
                        return description
            
            # Используем домен как fallback
            domain = extract_domain(url)
            
            # Делаем домен более читаемым
            domain_mapping = {
                'cointelegraph.com': 'CoinTelegraph',
                'coindesk.com': 'CoinDesk', 
                'forklog.com': 'ForkLog',
                'decrypt.co': 'Decrypt',
                'bitcoinmagazine.com': 'Bitcoin Magazine',
                'cryptonews.com': 'CryptoNews',
                'ambcrypto.com': 'AMBCrypto',
                'beincrypto.com': 'BeInCrypto'
            }
            
            return domain_mapping.get(domain, domain)
            
        except Exception as e:
            logger.warning(f"⚠️ Ошибка получения названия источника: {e}")
            return extract_domain(url)
    
    def _parse_entry(self, entry, source_title: str) -> Optional[Dict]:
        """Парсинг одной записи RSS"""
        try:
            # Заголовок (обязательное поле)
            title = self._extract_title(entry)
            if not title:
                logger.debug("🔄 Пропускаю запись без заголовка")
                return None
            
            # Ссылка (обязательное поле)
            link = self._extract_link(entry)
            if not link:
                logger.debug(f"🔄 Пропускаю запись без ссылки: {title[:50]}...")
                return None
            
            # Описание
            summary = self._extract_summary(entry)
            
            # Дата публикации
            published = self._extract_published_date(entry)
            
            # Дополнительные поля
            author = self._extract_author(entry)
            categories = self._extract_categories(entry)
            
            article = {
                'title': title,
                'link': link,
                'summary': summary,
                'published': published,
                'source': source_title,
                'author': author,
                'categories': categories
            }
            
            logger.debug(f"📄 Статья обработана: {title[:50]}...")
            return article
            
        except Exception as e:
            logger.error(f"💥 Ошибка парсинга записи: {e}")
            return None
    
    def _extract_title(self, entry) -> str:
        """Извлечение заголовка статьи"""
        title = getattr(entry, 'title', '').strip()
        if not title:
            return ""
        
        # Очищаем заголовок
        title = clean_text(title, 200)
        
        # Убираем префиксы источников если есть
        prefixes_to_remove = [
            'CoinTelegraph: ',
            'CoinDesk: ',
            'Bitcoin Magazine: ',
            'ForkLog: ',
            'Decrypt: '
        ]
        
        for prefix in prefixes_to_remove:
            if title.startswith(prefix):
                title = title[len(prefix):].strip()
        
        return title if title != "Описание недоступно" else ""
    
    def _extract_link(self, entry) -> str:
        """Извлечение ссылки на статью"""
        link = getattr(entry, 'link', '').strip()
        
        # Проверяем валидность ссылки
        if link and validate_url(link):
            return link
        
        # Пробуем альтернативные поля
        if hasattr(entry, 'links') and entry.links:
            for link_obj in entry.links:
                if hasattr(link_obj, 'href') and validate_url(link_obj.href):
                    return link_obj.href
        
        return ""
    
    def _extract_summary(self, entry) -> str:
        """Извлечение описания статьи"""
        # Пробуем различные поля с контентом
        content_fields = ['summary', 'description', 'content']
        
        for field in content_fields:
            if hasattr(entry, field):
                content = getattr(entry, field)
                
                # Если content - список (как в некоторых RSS)
                if isinstance(content, list) and content:
                    content = content[0]
                    if hasattr(content, 'value'):
                        content = content.value
                
                if content:
                    summary = clean_text(str(content), 500)
                    if summary and summary != "Описание недоступно":
                        return summary
        
        return "Описание недоступно"
    
    def _extract_published_date(self, entry) -> str:
        """Извлечение даты публикации"""
        # Пробуем различные поля с датой
        date_fields = ['published', 'updated', 'created', 'pubDate']
        
        for field in date_fields:
            if hasattr(entry, field):
                date_str = getattr(entry, field)
                if date_str:
                    formatted_date = format_datetime(date_str)
                    if formatted_date:
                        return formatted_date
            
            # Также проверяем parsed версии
            parsed_field = f"{field}_parsed"
            if hasattr(entry, parsed_field):
                parsed_date = getattr(entry, parsed_field)
                if parsed_date:
                    try:
                        dt = datetime(*parsed_date[:6])
                        return dt.isoformat() + 'Z'
                    except (TypeError, ValueError, IndexError):
                        continue
        
        # Возвращаем текущее время если не нашли
        return datetime.utcnow().isoformat() + 'Z'
    
    def _extract_author(self, entry) -> str:
        """Извлечение автора статьи"""
        # Пробуем различные поля с автором
        author_fields = ['author', 'author_detail', 'dc_creator']
        
        for field in author_fields:
            if hasattr(entry, field):
                author = getattr(entry, field)
                
                # Если author_detail - объект
                if isinstance(author, dict):
                    author = author.get('name', '') or author.get('email', '')
                
                if author:
                    author = clean_text(str(author), 100)
                    if author and author != "Описание недоступно":
                        return author
        
        return ""
    
    def _extract_categories(self, entry) -> List[str]:
        """Извлечение категорий/тегов статьи"""
        categories = []
        
        # Проверяем поле tags
        if hasattr(entry, 'tags') and entry.tags:
            for tag in entry.tags:
                if hasattr(tag, 'term'):
                    term = clean_text(tag.term, 50)
                    if term and term != "Описание недоступно":
                        categories.append(term)
        
        # Проверяем поле category
        if hasattr(entry, 'category') and entry.category:
            category = clean_text(entry.category, 50)
            if category and category != "Описание недоступно":
                categories.append(category)
        
        # Убираем дубликаты и ограничиваем количество
        return list(set(categories))[:5]
    
    def get_stats(self) -> Dict:
        """Получение статистики парсера"""
        total_requests = self.total_feeds_processed
        success_rate = 0
        
        if total_requests > 0:
            successful_requests = total_requests - self.total_errors
            success_rate = (successful_requests / total_requests) * 100
        
        return {
            "total_parsed": self.total_parsed,
            "total_errors": self.total_errors,
            "total_feeds_processed": self.total_feeds_processed,
            "success_rate": round(success_rate, 2),
            "average_articles_per_feed": round(self.total_parsed / max(1, self.total_feeds_processed), 2)
        }
    
    def reset_stats(self):
        """Сброс статистики парсера"""
        self.total_parsed = 0
        self.total_errors = 0
        self.total_feeds_processed = 0
        logger.info("📊 Статистика RSS парсера сброшена")
    
    def get_detailed_stats(self) -> Dict:
        """Получение детальной статистики"""
        stats = self.get_stats()
        
        # Добавляем дополнительную информацию
        stats.update({
            "user_agent": self.user_agent,
            "timeout_seconds": self.timeout,
            "max_articles_per_feed": self.max_articles_per_feed,
            "last_reset": None,  # TODO: добавить отслеживание времени сброса
            "parser_version": "3.0.0",
            "created_by": "phrphrphr",
            "created_at": "2025-06-18 19:22:01 UTC"
        })
        
        return stats

    async def validate_feed(self, url: str) -> Dict:
        """Валидация RSS ленты без полного парсинга"""
        try:
            logger.info(f"🔍 Валидация RSS ленты: {url}")
            
            if not validate_url(url):
                return {
                    "valid": False,
                    "error": "Невалидный URL",
                    "url": url
                }
            
            # Быстрая проверка доступности
            feed = await asyncio.wait_for(
                asyncio.to_thread(feedparser.parse, url),
                timeout=10  # Короткий таймаут для валидации
            )
            
            if hasattr(feed, 'bozo') and feed.bozo:
                if "not well-formed" in str(getattr(feed, 'bozo_exception', '')).lower():
                    return {
                        "valid": False,
                        "error": f"Некорректный XML: {feed.bozo_exception}",
                        "url": url
                    }
            
            if not hasattr(feed, 'entries') or not feed.entries:
                return {
                    "valid": False,
                    "error": "RSS лента пуста или недоступна",
                    "url": url
                }
            
            source_title = self._get_source_title(feed, url)
            
            return {
                "valid": True,
                "source_title": source_title,
                "entries_count": len(feed.entries),
                "url": url,
                "last_updated": getattr(feed.feed, 'updated', 'Неизвестно'),
                "description": getattr(feed.feed, 'description', 'Нет описания')
            }
            
        except asyncio.TimeoutError:
            return {
                "valid": False,
                "error": "Таймаут при подключении",
                "url": url
            }
        except Exception as e:
            return {
                "valid": False,
                "error": str(e),
                "url": url
            }

    async def test_all_feeds(self, feed_urls: List[str]) -> Dict:
        """Тестирование всех RSS лент"""
        results = []
        
        for url in feed_urls:
            result = await self.validate_feed(url)
            results.append(result)
        
        valid_count = sum(1 for r in results if r.get('valid', False))
        
        return {
            "total_feeds": len(feed_urls),
            "valid_feeds": valid_count,
            "invalid_feeds": len(feed_urls) - valid_count,
            "success_rate": round((valid_count / len(feed_urls)) * 100, 2) if feed_urls else 0,
            "results": results,
            "tested_at": datetime.utcnow().isoformat() + 'Z'
        }