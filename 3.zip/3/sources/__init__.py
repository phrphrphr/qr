"""
Crypto News Aggregator - Sources Module
Created: 2025-06-18 19:22:01 UTC
User: phrphrphr
Version: 3.0.0

Модуль источников новостей
"""

__version__ = "3.0.0"
__author__ = "phrphrphr"
__created__ = "2025-06-18 19:22:01"
__updated__ = "2025-06-18 19:22:01"
__description__ = "Crypto News Aggregator Sources Module"

# Импорты парсеров
try:
    from .rss import RSSParser
    
    __all__ = [
        'RSSParser',
        '__version__',
        '__author__',
        '__created__',
        '__updated__',
        '__description__'
    ]
    
    # Логирование успешной инициализации
    import logging
    logger = logging.getLogger(__name__)
    logger.info(f"✅ Sources module v{__version__} инициализирован успешно")
    logger.info(f"   📡 Доступные парсеры: RSSParser")
    logger.info(f"   👤 Автор: {__author__}")
    
except ImportError as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"💥 Ошибка инициализации sources модуля: {e}")
    
    # Fallback экспорт
    __all__ = [
        '__version__',
        '__author__',
        '__created__',
        '__updated__',
        '__description__'
    ]