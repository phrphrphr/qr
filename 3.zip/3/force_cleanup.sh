#!/bin/bash
# Force Cleanup Script - 2025-06-18 20:10:09 UTC - phrphrphr

echo "🧹 Принудительная очистка всех ресурсов проекта..."

# Останавливаем все контейнеры проекта
docker stop $(docker ps -aq --filter "name=crypto") 2>/dev/null || true
docker rm -f $(docker ps -aq --filter "name=crypto") 2>/dev/null || true

# Удаляем образы проекта
docker rmi -f $(docker images -q "*crypto*") 2>/dev/null || true

# Удаляем сети
docker network rm crypto_network 2>/dev/null || true

# Очищаем все неиспользуемые ресурсы
docker system prune -af

echo "✅ Очистка завершена. Теперь можно запускать: docker-compose up -d"