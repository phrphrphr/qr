/**
 * Crypto News Aggregator - Main JavaScript
 * Created: 2025-06-18 19:40:03 UTC
 * User: phrphrphr
 * Version: 3.0.0
 *
 * Основной JavaScript файл для агрегатора криптоновостей
 */

(function() {
    'use strict';

    // Глобальная конфигурация приложения
    window.CryptoNewsApp = {
        version: '3.0.0',
        author: 'phrphrphr',
        created: '2025-06-18 19:40:03',
        updated: '2025-06-18 19:40:03',
        user: 'phrphrphr',
        
        // Настройки
        config: {
            statusUpdateInterval: 30000,    // 30 секунд
            autoRefreshInterval: 600000,    // 10 минут
            apiTimeout: 10000,              // 10 секунд
            animationDuration: 300,         // 300ms
            debounceDelay: 250,             // 250ms
            retryAttempts: 3,               // Количество попыток
            retryDelay: 1000                // Задержка между попытками
        },
        
        // Состояние приложения
        state: {
            isOnline: navigator.onLine,
            lastStatusUpdate: null,
            statusCheckInterval: null,
            autoRefreshInterval: null,
            currentPage: 1,
            totalPages: 1,
            articlesCount: 0,
            isLoading: false,
            apiErrors: 0,
            lastApiCall: null
        },
        
        // Кэш
        cache: {
            status: null,
            lastFetch: null,
            ttl: 30000 // 30 секунд
        },
        
        // API эндпоинты
        endpoints: {
            status: '/api/status',
            health: '/health',
            articles: '/articles',
            stats: '/stats',
            parse: '/parse/trigger'
        }
    };

    const app = window.CryptoNewsApp;

    // ===== УТИЛИТЫ =====
    const utils = {
        /**
         * Debounce функция для ограничения частоты вызовов
         */
        debounce: function(func, wait, immediate = false) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    timeout = null;
                    if (!immediate) func(...args);
                };
                const callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func(...args);
            };
        },

        /**
         * Throttle функция для ограничения частоты выполнения
         */
        throttle: function(func, limit) {
            let inThrottle;
            return function() {
                const args = arguments;
                const context = this;
                if (!inThrottle) {
                    func.apply(context, args);
                    inThrottle = true;
                    setTimeout(() => inThrottle = false, limit);
                }
            };
        },

        /**
         * Форматирование даты в читаемый вид
         */
        formatDate: function(dateString) {
            if (!dateString) return 'Неизвестно';
            
            try {
                const date = new Date(dateString);
                const now = new Date();
                const diffMs = now - date;
                const diffMins = Math.floor(diffMs / 60000);
                const diffHours = Math.floor(diffMs / 3600000);
                const diffDays = Math.floor(diffMs / 86400000);

                if (diffMins < 1) return 'Только что';
                if (diffMins < 60) return `${diffMins} мин назад`;
                if (diffHours < 24) return `${diffHours} ч назад`;
                if (diffDays < 7) return `${diffDays} дн назад`;
                
                return date.toLocaleDateString('ru-RU', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
            } catch (e) {
                console.warn('⚠️ Ошибка форматирования даты:', e);
                return 'Неизвестно';
            }
        },

        /**
         * Форматирование числа с разделителями
         */
        formatNumber: function(num) {
            if (typeof num !== 'number') return '0';
            return num.toLocaleString('ru-RU');
        },

        /**
         * Показать уведомление пользователю
         */
        showNotification: function(message, type = 'info', duration = 5000) {
            // Удаляем предыдущие уведомления того же типа
            const existingNotifications = document.querySelectorAll(`.notification-${type}`);
            existingNotifications.forEach(notification => notification.remove());

            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <span class="notification-icon">${this.getNotificationIcon(type)}</span>
                    <span class="notification-message">${this.escapeHtml(message)}</span>
                    <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
            `;

            // Добавляем стили если их нет
            this.ensureNotificationStyles();

            document.body.appendChild(notification);
            
            // Анимация появления
            requestAnimationFrame(() => {
                notification.classList.add('show');
            });

            // Автоудаление
            if (duration > 0) {
                setTimeout(() => {
                    notification.classList.remove('show');
                    setTimeout(() => {
                        if (notification.parentNode) {
                            notification.remove();
                        }
                    }, app.config.animationDuration);
                }, duration);
            }

            // Лог уведомления
            this.log(`Notification: ${message}`, type === 'error' ? 'error' : 'info');

            return notification;
        },

        /**
         * Получить иконку для типа уведомления
         */
        getNotificationIcon: function(type) {
            const icons = {
                info: 'ℹ️',
                success: '✅',
                warning: '⚠️',
                error: '❌',
                loading: '⏳'
            };
            return icons[type] || icons.info;
        },

        /**
         * Экранирование HTML
         */
        escapeHtml: function(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },

        /**
         * Добавление стилей для уведомлений
         */
        ensureNotificationStyles: function() {
            if (document.querySelector('#notification-styles')) return;

            const styles = document.createElement('style');
            styles.id = 'notification-styles';
            styles.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 1000;
                    max-width: 400px;
                    min-width: 300px;
                    padding: 16px;
                    border-radius: 12px;
                    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
                    transform: translateX(100%);
                    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                    font-family: inherit;
                    backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                }
                .notification.show {
                    transform: translateX(0);
                }
                .notification-info {
                    background: rgba(59, 130, 246, 0.9);
                    color: white;
                }
                .notification-success {
                    background: rgba(16, 185, 129, 0.9);
                    color: white;
                }
                .notification-warning {
                    background: rgba(245, 158, 11, 0.9);
                    color: white;
                }
                .notification-error {
                    background: rgba(239, 68, 68, 0.9);
                    color: white;
                }
                .notification-loading {
                    background: rgba(107, 114, 128, 0.9);
                    color: white;
                }
                .notification-content {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }
                .notification-message {
                    flex: 1;
                    font-size: 14px;
                    line-height: 1.4;
                }
                .notification-close {
                    background: none;
                    border: none;
                    color: inherit;
                    cursor: pointer;
                    font-size: 18px;
                    padding: 0;
                    width: 28px;
                    height: 28px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 6px;
                    opacity: 0.8;
                    transition: all 0.2s ease;
                }
                .notification-close:hover {
                    opacity: 1;
                    background: rgba(255, 255, 255, 0.2);
                    transform: scale(1.1);
                }
                @media (max-width: 768px) {
                    .notification {
                        right: 10px;
                        left: 10px;
                        max-width: none;
                        min-width: auto;
                    }
                }
            `;
            document.head.appendChild(styles);
        },

        /**
         * Логирование с метками времени и контекстом
         */
        log: function(message, level = 'info') {
            const timestamp = new Date().toISOString();
            const prefix = `[${timestamp}] [CryptoNews v${app.version}] [${app.user}] [${level.toUpperCase()}]`;
            
            const logMessage = `${prefix} ${message}`;
            
            switch (level) {
                case 'error':
                    console.error(logMessage);
                    break;
                case 'warn':
                    console.warn(logMessage);
                    break;
                case 'debug':
                    console.debug(logMessage);
                    break;
                default:
                    console.log(logMessage);
            }
        },

        /**
         * Ожидание появления элемента в DOM
         */
        waitForElement: function(selector, timeout = 5000) {
            return new Promise((resolve, reject) => {
                const element = document.querySelector(selector);
                if (element) {
                    resolve(element);
                    return;
                }

                const observer = new MutationObserver(() => {
                    const element = document.querySelector(selector);
                    if (element) {
                        observer.disconnect();
                        resolve(element);
                    }
                });

                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });

                setTimeout(() => {
                    observer.disconnect();
                    reject(new Error(`Element ${selector} not found within ${timeout}ms`));
                }, timeout);
            });
        },

        /**
         * Безопасный HTTP запрос с повторными попытками
         */
        fetchWithRetry: async function(url, options = {}, retries = app.config.retryAttempts) {
            const defaultOptions = {
                timeout: app.config.apiTimeout,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            };

            const finalOptions = { ...defaultOptions, ...options };

            for (let i = 0; i <= retries; i++) {
                try {
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), finalOptions.timeout);

                    const response = await fetch(url, {
                        ...finalOptions,
                        signal: controller.signal
                    });

                    clearTimeout(timeoutId);

                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }

                    const data = await response.json();
                    app.state.lastApiCall = Date.now();
                    app.state.apiErrors = Math.max(0, app.state.apiErrors - 1);
                    
                    return data;

                } catch (error) {
                    app.state.apiErrors++;
                    
                    if (i === retries) {
                        this.log(`API request failed after ${retries + 1} attempts: ${error.message}`, 'error');
                        throw error;
                    }

                    const delay = app.config.retryDelay * Math.pow(2, i); // Экспоненциальная задержка
                    this.log(`API request failed (attempt ${i + 1}/${retries + 1}), retrying in ${delay}ms: ${error.message}`, 'warn');
                    
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        },

        /**
         * Сохранение в localStorage с обработкой ошибок
         */
        saveToStorage: function(key, value) {
            try {
                localStorage.setItem(`cryptonews_${key}`, JSON.stringify({
                    value: value,
                    timestamp: Date.now(),
                    version: app.version
                }));
                return true;
            } catch (error) {
                this.log(`Failed to save to localStorage: ${error.message}`, 'warn');
                return false;
            }
        },

        /**
         * Загрузка из localStorage с проверкой версии
         */
        loadFromStorage: function(key, maxAge = 3600000) { // 1 час по умолчанию
            try {
                const item = localStorage.getItem(`cryptonews_${key}`);
                if (!item) return null;

                const parsed = JSON.parse(item);
                const age = Date.now() - parsed.timestamp;

                // Проверяем возраст данных
                if (age > maxAge) {
                    localStorage.removeItem(`cryptonews_${key}`);
                    return null;
                }

                // Проверяем версию (опционально)
                if (parsed.version && parsed.version !== app.version) {
                    this.log(`Storage version mismatch for ${key}, clearing`, 'info');
                    localStorage.removeItem(`cryptonews_${key}`);
                    return null;
                }

                return parsed.value;
            } catch (error) {
                this.log(`Failed to load from localStorage: ${error.message}`, 'warn');
                localStorage.removeItem(`cryptonews_${key}`);
                return null;
            }
        },

        /**
         * Генерация уникального ID
         */
        generateId: function() {
            return Date.now().toString(36) + Math.random().toString(36).substr(2);
        },

        /**
         * Проверка поддержки функций браузером
         */
        checkBrowserSupport: function() {
            const required = [
                'fetch',
                'Promise',
                'localStorage',
                'addEventListener'
            ];

            const missing = required.filter(feature => !(feature in window));
            
            if (missing.length > 0) {
                this.log(`Browser missing required features: ${missing.join(', ')}`, 'error');
                return false;
            }

            return true;
        }
    };

    // ===== API МОДУЛЬ =====
    const api = {
        /**
         * Получение статуса системы
         */
        getStatus: async function() {
            try {
                const data = await utils.fetchWithRetry(app.endpoints.status);
                app.cache.status = data;
                app.cache.lastFetch = Date.now();
                return data;
            } catch (error) {
                utils.log(`Failed to get status: ${error.message}`, 'error');
                return { 
                    status: 'error', 
                    error: error.message,
                    timestamp: new Date().toISOString()
                };
            }
        },

        /**
         * Получение статистики
         */
        getStats: async function() {
            try {
                return await utils.fetchWithRetry('/stats');
            } catch (error) {
                utils.log(`Failed to get stats: ${error.message}`, 'error');
                throw error;
            }
        },

        /**
         * Запуск парсинга
         */
        triggerParsing: async function() {
            try {
                const data = await utils.fetchWithRetry(app.endpoints.parse, {
                    method: 'POST'
                });
                utils.showNotification('Парсинг запущен успешно', 'success');
                return data;
            } catch (error) {
                utils.log(`Failed to trigger parsing: ${error.message}`, 'error');
                utils.showNotification('Ошибка запуска парсинга: ' + error.message, 'error');
                throw error;
            }
        }
    };

    // ===== УПРАВЛЕНИЕ СТАТУСОМ =====
    const statusManager = {
        /**
         * Обновление статуса системы
         */
        updateStatus: async function() {
            const statusElement = document.getElementById('status');
            if (!statusElement) return;

            try {
                // Показываем индикатор загрузки
                statusElement.className = 'status info';
                statusElement.innerHTML = `
                    <div class="loading-spinner"></div>
                    <span>Проверка статуса системы...</span>
                `;

                const status = await api.getStatus();
                app.state.lastStatusUpdate = Date.now();

                if (status.status === 'ok') {
                    statusElement.className = 'status success';
                    statusElement.innerHTML = `
                        <span>✅</span>
                        <span>Система работает нормально • ${utils.formatNumber(status.articles_count)} статей</span>
                        <small>Обновлено: ${utils.formatDate(status.timestamp)}</small>
                    `;
                } else {
                    statusElement.className = 'status error';
                    statusElement.innerHTML = `
                        <span>❌</span>
                        <span>Проблемы с системой: ${status.error || 'Неизвестная ошибка'}</span>
                        <button onclick="statusManager.updateStatus()" class="btn btn-sm">🔄 Повторить</button>
                    `;
                }

                // Обновляем статистику в футере
                this.updateFooterStats(status);

            } catch (error) {
                statusElement.className = 'status error';
                statusElement.innerHTML = `
                    <span>❌</span>
                    <span>Ошибка подключения к системе</span>
                    <button onclick="statusManager.updateStatus()" class="btn btn-sm">🔄 Повторить</button>
                `;
                utils.log(`Status update failed: ${error.message}`, 'error');
            }
        },

        /**
         * Обновление статистики в футере
         */
        updateFooterStats: function(status) {
            const footerStats = document.getElementById('footer-stats');
            if (!footerStats || !status) return;

            footerStats.innerHTML = `
                <p>📰 Статей: ${utils.formatNumber(status.articles_count || 0)}</p>
                <p>🕐 Обновлено: ${utils.formatDate(status.timestamp)}</p>
            `;
        },

        /**
         * Запуск автоматического обновления статуса
         */
        startAutoUpdate: function() {
            // Очищаем существующий интервал
            if (app.state.statusCheckInterval) {
                clearInterval(app.state.statusCheckInterval);
            }

            // Первое обновление сразу
            this.updateStatus();

            // Затем периодически
            app.state.statusCheckInterval = setInterval(() => {
                this.updateStatus();
            }, app.config.statusUpdateInterval);

            utils.log('Status auto-update started', 'info');
        },

        /**
         * Остановка автоматического обновления
         */
        stopAutoUpdate: function() {
            if (app.state.statusCheckInterval) {
                clearInterval(app.state.statusCheckInterval);
                app.state.statusCheckInterval = null;
                utils.log('Status auto-update stopped', 'info');
            }
        }
    };

    // ===== УПРАВЛЕНИЕ СТРАНИЦЕЙ =====
    const pageManager = {
        /**
         * Обновление страницы
         */
        refresh: function() {
            const loadingIndicator = document.getElementById('loading-indicator');
            if (loadingIndicator) {
                loadingIndicator.style.display = 'block';
            }

            utils.showNotification('Обновление страницы...', 'loading', 2000);
            
            setTimeout(() => {
                window.location.reload();
            }, 500);
        },

        /**
         * Навигация между страницами
         */
        navigate: function(url) {
            const loadingIndicator = document.getElementById('loading-indicator');
            if (loadingIndicator) {
                loadingIndicator.style.display = 'block';
            }

            window.location.href = url;
        },

        /**
         * Обработка ошибок загрузки
         */
        handleLoadError: function(error) {
            utils.log(`Page load error: ${error.message}`, 'error');
            utils.showNotification('Ошибка загрузки страницы', 'error');
        }
    };

    // ===== ОБРАБОТЧИКИ СОБЫТИЙ =====
    const eventHandlers = {
        /**
         * Инициализация обработчиков
         */
        init: function() {
            // Обработчик состояния сети
            window.addEventListener('online', this.handleOnline.bind(this));
            window.addEventListener('offline', this.handleOffline.bind(this));

            // Обработчик видимости страницы
            document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));

            // Обработчик горячих клавиш
            document.addEventListener('keydown', this.handleKeyboard.bind(this));

            // Обработчик ошибок
            window.addEventListener('error', this.handleError.bind(this));
            window.addEventListener('unhandledrejection', this.handlePromiseRejection.bind(this));

            // Обработчик загрузки изображений
            this.handleImageErrors();

            utils.log('Event handlers initialized', 'info');
        },

        /**
         * Обработчик восстановления сети
         */
        handleOnline: function() {
            app.state.isOnline = true;
            utils.showNotification('Соединение восстановлено', 'success');
            statusManager.updateStatus();
        },

        /**
         * Обработчик потери сети
         */
        handleOffline: function() {
            app.state.isOnline = false;
            utils.showNotification('Соединение потеряно', 'warning');
        },

        /**
         * Обработчик изменения видимости страницы
         */
        handleVisibilityChange: function() {
            if (document.hidden) {
                statusManager.stopAutoUpdate();
            } else {
                statusManager.startAutoUpdate();
            }
        },

        /**
         * Обработчик горячих клавиш
         */
        handleKeyboard: function(event) {
            // Только если не в поле ввода
            if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
                return;
            }

            switch(event.key.toLowerCase()) {
                case 'r':
                    event.preventDefault();
                    pageManager.refresh();
                    break;
                    
                case 's':
                    if (event.ctrlKey || event.metaKey) {
                        event.preventDefault();
                        statusManager.updateStatus();
                    }
                    break;

                case 'arrowleft':
                    if (event.ctrlKey) {
                        event.preventDefault();
                        const prevBtn = document.querySelector('.pagination-prev');
                        if (prevBtn) prevBtn.click();
                    }
                    break;

                case 'arrowright':
                    if (event.ctrlKey) {
                        event.preventDefault();
                        const nextBtn = document.querySelector('.pagination-next');
                        if (nextBtn) nextBtn.click();
                    }
                    break;
            }
        },

        /**
         * Обработчик общих ошибок
         */
        handleError: function(event) {
            utils.log(`JavaScript error: ${event.error?.message || event.message}`, 'error');
        },

        /**
         * Обработчик отклоненных промисов
         */
        handlePromiseRejection: function(event) {
            utils.log(`Unhandled promise rejection: ${event.reason}`, 'error');
        },

        /**
         * Обработчик ошибок загрузки изображений
         */
        handleImageErrors: function() {
            document.addEventListener('error', function(event) {
                if (event.target.tagName === 'IMG') {
                    event.target.style.display = 'none';
                    utils.log(`Image load error: ${event.target.src}`, 'warn');
                }
            }, true);
        }
    };

    // ===== ИНИЦИАЛИЗАЦИЯ ПРИЛОЖЕНИЯ =====
    function initApp() {
        utils.log(`🚀 Crypto News Aggregator v${app.version} initializing...`, 'info');
        utils.log(`👤 User: ${app.user}`, 'info');
        utils.log(`📅 Created: ${app.created}`, 'info');
        utils.log(`🕐 Current time: ${new Date().toISOString()}`, 'info');

        // Проверяем поддержку браузера
        if (!utils.checkBrowserSupport()) {
            utils.showNotification(
                'Ваш браузер не поддерживается. Пожалуйста, обновите браузер.', 
                'error', 
                0
            );
            return;
        }

        try {
            // Инициализируем компоненты
            eventHandlers.init();
            statusManager.startAutoUpdate();

            // Обновляем время на странице
            updateRelativeTimes();
            setInterval(updateRelativeTimes, 60000); // Каждую минуту

            // Показываем приветственное сообщение в консоли
            showWelcomeMessage();

            utils.log('✅ Application initialized successfully', 'info');
            
        } catch (error) {
            utils.log(`💥 Initialization error: ${error.message}`, 'error');
            utils.showNotification('Ошибка инициализации приложения', 'error');
        }
    }

    // ===== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ =====

    /**
     * Обновление относительного времени на странице
     */
    function updateRelativeTimes() {
        const timeElements = document.querySelectorAll('.relative-time, [data-time]');
        timeElements.forEach(element => {
            const dateTime = element.getAttribute('data-time') || element.textContent;
            if (dateTime) {
                element.textContent = utils.formatDate(dateTime);
            }
        });
    }

    /**
     * Глобальная функция обновления страницы
     */
    window.refreshPage = function() {
        pageManager.refresh();
    };

    /**
     * Показать приветственное сообщение в консоли
     */
    function showWelcomeMessage() {
        const styles = [
            'font-size: 16px',
            'font-weight: bold',
            'color: #667eea',
            'text-shadow: 1px 1px 1px #000'
        ].join(';');

        console.log(`%c🚀 Crypto News Aggregator v${app.version}`, styles);
        console.log(`%cСоздано: ${app.created}`, 'color: #10b981');
        console.log(`%cАвтор: ${app.author}`, 'color: #f59e0b');
        console.log(`%cПользователь: ${app.user}`, 'color: #ef4444');
        console.log('');
        console.log('%cДоступные команды:', 'font-weight: bold; color: #8b5cf6');
        console.log('• CryptoNewsApp.utils.showNotification(message, type) - показать уведомление');
        console.log('• refreshPage() - обновить страницу');
        console.log('• statusManager.updateStatus() - обновить статус');
        console.log('');
        console.log('%cГорячие клавиши:', 'font-weight: bold; color: #06b6d4');
        console.log('• R - обновить страницу');
        console.log('• Ctrl+S - обновить статус');
        console.log('• Ctrl+← - предыдущая страница');
        console.log('• Ctrl+→ - следующая страница');
    }

    // ===== ЭКСПОРТ API =====
    
    // Делаем доступными полезные функции глобально
    window.statusManager = statusManager;
    window.CryptoNewsApp.utils = utils;
    window.CryptoNewsApp.api = api;

    // ===== ЗАПУСК ПРИЛОЖЕНИЯ =====

    // Запускаем инициализацию после загрузки DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApp);
    } else {
        // DOM уже загружен
        initApp();
    }

    // Очистка при выгрузке страницы
    window.addEventListener('beforeunload', function() {
        statusManager.stopAutoUpdate();
        utils.log('Application cleanup completed', 'info');
    });

    utils.log('Main.js loaded successfully', 'info');

})();

/*
 * Конец main.js
 * Создан: 2025-06-18 19:40:03 UTC
 * Пользователь: phrphrphr
 * Размер: ~20KB
 * Функций: 30+
 * Совместимость: ES6+, современные браузеры
 */