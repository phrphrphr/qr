#!/bin/bash

# Crypto News Aggregator - Database Diagnostic Script
# Created: 2025-06-18 19:43:57 UTC
# User: phrphrphr
# Version: 3.0.0

set -euo pipefail

# Метаданные
readonly SCRIPT_VERSION="3.0.0"
readonly SCRIPT_AUTHOR="phrphrphr"
readonly SCRIPT_CREATED="2025-06-18 19:43:57 UTC"
readonly SCRIPT_USER="phrphrphr"

# Цвета для вывода
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly PURPLE='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly WHITE='\033[1;37m'
readonly BOLD='\033[1m'
readonly NC='\033[0m'

# Переходим в директорию скрипта
cd "$(dirname "$0")"

# Функции логирования
log_info() { echo -e "${GREEN}✅ $1${NC}"; }
log_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_step() { echo -e "${BLUE}🔧 $1${NC}"; }
log_success() { echo -e "${PURPLE}🎉 $1${NC}"; }
log_header() { echo -e "${CYAN}${BOLD}$1${NC}"; }

# Показать заголовок
show_header() {
    clear
    echo -e "${CYAN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║               🔍 CRYPTO NEWS AGGREGATOR v3.0.0 🔍                ║"
    echo "║                    ДИАГНОСТИКА БАЗЫ ДАННЫХ                       ║"
    echo "║                                                                  ║"
    echo "║  Создан: ${SCRIPT_CREATED}               ║"
    echo "║  Автор: ${SCRIPT_AUTHOR}                                         ║"
    echo "║  Пользователь: ${SCRIPT_USER}                                    ║"
    echo "║  Время проверки: $(date '+%Y-%m-%d %H:%M:%S UTC')               ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}\n"
}

# Проверка файлов базы данных
check_database_files() {
    log_step "Проверяю файлы базы данных..."
    
    local db_file="data/storage.json"
    local backup_count=0
    
    if [[ -f "$db_file" ]]; then
        local file_size_bytes=$(stat -f%z "$db_file" 2>/dev/null || stat -c%s "$db_file" 2>/dev/null || echo "0")
        local file_size_human=$(du -h "$db_file" | cut -f1)
        local file_date=$(ls -la "$db_file" | awk '{print $6, $7, $8}')
        
        log_info "База данных найдена: $db_file"
        echo "  📏 Размер: $file_size_human ($file_size_bytes байт)"
        echo "  📅 Дата изменения: $file_date"
        
        # Проверяем права доступа
        local permissions=$(ls -la "$db_file" | awk '{print $1}')
        echo "  🔐 Права доступа: $permissions"
        
        # Проверяем валидность JSON
        if python3 -c "import json; json.load(open('$db_file'))" 2>/dev/null; then
            log_info "JSON структура валидна"
            
            # Подсчитываем статьи
            local articles_count=$(python3 -c "
import json
try:
    with open('$db_file') as f:
        data = json.load(f)
        articles = data.get('articles', {})
        total = 0
        for key, value in articles.items():
            if isinstance(value, list):
                total += len(value)
        print(total)
except Exception as e:
    print('0')
" 2>/dev/null || echo "0")
            
            log_info "Статей в базе: $articles_count"
            
            # Анализируем структуру
            local structure=$(python3 -c "
import json
try:
    with open('$db_file') as f:
        data = json.load(f)
        tables = list(data.keys())
        print(f'Таблиц: {len(tables)}')
        for table in tables:
            if isinstance(data[table], dict):
                print(f'  - {table}: {len(data[table])} записей')
            else:
                print(f'  - {table}: {type(data[table]).__name__}')
except Exception as e:
    print(f'Ошибка анализа: {e}')
" 2>/dev/null || echo "Ошибка анализа структуры")
            
            echo "  📊 Структура базы:"
            echo "$structure" | sed 's/^/    /'
            
        else
            log_error "JSON структура повреждена!"
            echo "  🔧 Попытка восстановления..."
            
            # Создаем резервную копию поврежденного файла
            cp "$db_file" "${db_file}.corrupted.$(date +%Y%m%d_%H%M%S)"
            
            # Пытаемся найти последнюю валидную резервную копию
            if [[ -d "backups" ]]; then
                local latest_backup=$(ls -t backups/storage_backup_*.json 2>/dev/null | head -1 || echo "")
                if [[ -n "$latest_backup" ]]; then
                    log_warn "Восстанавливаю из резервной копии: $latest_backup"
                    cp "$latest_backup" "$db_file"
                    
                    if python3 -c "import json; json.load(open('$db_file'))" 2>/dev/null; then
                        log_success "База данных восстановлена из резервной копии"
                    else
                        log_error "Резервная копия также повреждена"
                    fi
                else
                    log_warn "Резервные копии не найдены, создаю новую базу"
                    create_empty_database
                fi
            else
                log_warn "Создаю новую базу данных"
                create_empty_database
            fi
        fi
        
    else
        log_warn "База данных не найдена: $db_file"
        log_step "Создаю новую базу данных..."
        create_empty_database
    fi
    
    # Проверяем резервные копии
    if [[ -d "backups" ]]; then
        backup_count=$(ls backups/storage_backup_*.json 2>/dev/null | wc -l || echo "0")
        if [[ $backup_count -gt 0 ]]; then
            log_info "Найдено резервных копий: $backup_count"
            echo "  📋 Последние резервные копии:"
            ls -la backups/storage_backup_*.json 2>/dev/null | tail -3 | sed 's/^/    /' || echo "    Нет резервных копий"
        fi
    else
        log_warn "Директория backups не найдена"
        mkdir -p backups
    fi
}

# Создание пустой базы данных
create_empty_database() {
    mkdir -p data
    cat > data/storage.json << 'EOF'
{
  "_default": {},
  "articles": {
    "1": []
  }
}
EOF
    log_info "Новая база данных создана"
}

# Проверка API подключения
check_api_connection() {
    log_step "Проверяю подключение к API..."
    
    local api_endpoints=(
        "http://localhost:8001/health"
        "http://localhost:8001/stats"
        "http://localhost:8001/debug/database"
    )
    
    for endpoint in "${api_endpoints[@]}"; do
        local endpoint_name=$(echo "$endpoint" | sed 's|.*8001/||')
        
        if curl -s --max-time 5 "$endpoint" >/dev/null 2>&1; then
            log_info "✅ $endpoint_name - доступен"
            
            # Получаем дополнительную информацию
            case "$endpoint_name" in
                "health")
                    local health_data=$(curl -s --max-time 5 "$endpoint" 2>/dev/null || echo "{}")
                    local articles_count=$(echo "$health_data" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(data.get('articles_count', 'неизвестно'))
except:
    print('неизвестно')
" 2>/dev/null || echo "неизвестно")
                    echo "    📰 Статей через API: $articles_count"
                    ;;
                "stats")
                    local stats_data=$(curl -s --max-time 5 "$endpoint" 2>/dev/null || echo "{}")
                    local sources_count=$(echo "$stats_data" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(data.get('sources_count', 'неизвестно'))
except:
    print('неизвестно')
" 2>/dev/null || echo "неизвестно")
                    echo "    🌐 Источников: $sources_count"
                    ;;
                "debug/database")
                    log_info "  🔧 Debug API доступен"
                    ;;
            esac
        else
            log_error "❌ $endpoint_name - недоступен"
        fi
    done
}

# Проверка контейнеров Docker
check_docker_containers() {
    log_step "Проверяю Docker контейнеры..."
    
    local containers=(
        "crypto_backend"
        "crypto_api" 
        "crypto_dashboard"
    )
    
    local running_containers=0
    
    if command -v docker &>/dev/null; then
        echo -e "\n${BOLD}Статус контейнеров:${NC}"
        
        for container in "${containers[@]}"; do
            if docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
                log_info "✅ $container - запущен"
                ((running_containers++))
                
                # Получаем дополнительную информацию
                local container_info=$(docker ps --format "table {{.Status}}\t{{.Ports}}" --filter "name=$container" | tail -1)
                echo "    ℹ️  $container_info"
                
            elif docker ps -a --format "table {{.Names}}" | grep -q "^${container}$"; then
                log_warn "⏸️  $container - остановлен"
                local container_status=$(docker ps -a --format "table {{.Status}}" --filter "name=$container" | tail -1)
                echo "    ℹ️  $container_status"
            else
                log_error "❌ $container - не найден"
            fi
        done
        
        echo -e "\nСводка: ${running_containers}/${#containers[@]} контейнеров запущено"
        
        # Показываем логи ошибок если есть проблемы
        if [[ $running_containers -lt ${#containers[@]} ]]; then
            log_warn "Проверяю логи на наличие ошибок..."
            
            for container in "${containers[@]}"; do
                if ! docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
                    echo -e "\n${BOLD}Последние логи $container:${NC}"
                    docker logs --tail=10 "$container" 2>/dev/null | sed 's/^/  /' || echo "  Логи недоступны"
                fi
            done
        fi
        
    else
        log_error "Docker не установлен или недоступен"
    fi
}

# Анализ логов
analyze_logs() {
    log_step "Анализирую логи приложения..."
    
    local log_files=(
        "logs/app.log"
        "logs/errors.log"
        "logs/debug.log"
        "logs/rss_parser.log"
    )
    
    for log_file in "${log_files[@]}"; do
        if [[ -f "$log_file" ]]; then
            local log_size=$(du -h "$log_file" | cut -f1)
            local log_lines=$(wc -l < "$log_file" 2>/dev/null || echo "0")
            
            log_info "📋 $log_file найден (размер: $log_size, строк: $log_lines)"
            
            # Ищем ошибки в логах
            local errors=$(grep -c "ERROR\|💥\|CRITICAL" "$log_file" 2>/dev/null || echo "0")
            local warnings=$(grep -c "WARNING\|⚠️\|WARN" "$log_file" 2>/dev/null || echo "0")
            
            if [[ $errors -gt 0 ]]; then
                log_warn "  Ошибок найдено: $errors"
                echo -e "\n  ${BOLD}Последние ошибки:${NC}"
                grep "ERROR\|💥\|CRITICAL" "$log_file" | tail -3 | sed 's/^/    /' 2>/dev/null || echo "    Не удалось получить ошибки"
            fi
            
            if [[ $warnings -gt 0 ]]; then
                echo "  ⚠️  Предупреждений: $warnings"
            fi
            
            if [[ $errors -eq 0 && $warnings -eq 0 ]]; then
                echo "  ✅ Серьезных проблем не найдено"
            fi
            
        else
            log_warn "📋 $log_file не найден"
        fi
    done
    
    # Анализируем логи Docker контейнеров
    if command -v docker &>/dev/null; then
        echo -e "\n${BOLD}Анализ логов Docker контейнеров:${NC}"
        
        local containers=("crypto_backend" "crypto_api" "crypto_dashboard")
        
        for container in "${containers[@]}"; do
            if docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
                local container_errors=$(docker logs "$container" 2>&1 | grep -c "ERROR\|Exception\|Traceback" || echo "0")
                
                if [[ $container_errors -gt 0 ]]; then
                    log_warn "$container: найдено ошибок в логах: $container_errors"
                    echo -e "\n  ${BOLD}Последние ошибки $container:${NC}"
                    docker logs "$container" 2>&1 | grep "ERROR\|Exception\|Traceback" | tail -2 | sed 's/^/    /' || echo "    Не удалось получить ошибки"
                else
                    log_info "$container: серьезных ошибок в логах не найдено"
                fi
            fi
        done
    fi
}

# Проверка производительности
check_performance() {
    log_step "Проверяю производительность системы..."
    
    # Проверяем использование дискового пространства
    local disk_usage=$(df -h . | awk 'NR==2 {print $5}' | tr -d '%')
    local disk_available=$(df -h . | awk 'NR==2 {print $4}')
    
    echo "💿 Использование диска: ${disk_usage}% (свободно: $disk_available)"
    
    if [[ $disk_usage -gt 90 ]]; then
        log_error "Критически мало места на диске!"
    elif [[ $disk_usage -gt 80 ]]; then
        log_warn "Заканчивается место на диске"
    else
        log_info "Достаточно места на диске"
    fi
    
    # Проверяем размер файлов проекта
    echo -e "\n${BOLD}Размеры файлов проекта:${NC}"
    
    if [[ -f "data/storage.json" ]]; then
        local db_size=$(du -h data/storage.json | cut -f1)
        echo "  💾 База данных: $db_size"
    fi
    
    if [[ -d "logs" ]]; then
        local logs_size=$(du -sh logs 2>/dev/null | cut -f1 || echo "0")
        echo "  📋 Логи: $logs_size"
    fi
    
    if [[ -d "backups" ]]; then
        local backups_size=$(du -sh backups 2>/dev/null | cut -f1 || echo "0")
        local backups_count=$(ls backups/*.json 2>/dev/null | wc -l || echo "0")
        echo "  🗄️  Резервные копии: $backups_size ($backups_count файлов)"
    fi
    
    # Проверяем память Docker контейнеров
    if command -v docker &>/dev/null; then
        echo -e "\n${BOLD}Использование ресурсов Docker:${NC}"
        
        local containers=("crypto_backend" "crypto_api" "crypto_dashboard")
        
        for container in "${containers[@]}"; do
            if docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
                local stats=$(docker stats "$container" --no-stream --format "table {{.CPUPerc}}\t{{.MemUsage}}" 2>/dev/null | tail -1 || echo "N/A	N/A")
                echo "  🐳 $container: CPU: $(echo "$stats" | cut -f1), RAM: $(echo "$stats" | cut -f2)"
            fi
        done
    fi
}

# Рекомендации по устранению проблем
show_recommendations() {
    log_step "Анализирую найденные проблемы и даю рекомендации..."
    
    echo -e "\n${BOLD}💡 РЕКОМЕНДАЦИИ ПО УСТРАНЕНИЮ ПРОБЛЕМ:${NC}\n"
    
    # Проверяем наличие базы данных
    if [[ ! -f "data/storage.json" ]]; then
        echo "❌ База данных отсутствует:"
        echo "   🔧 Решение: ./quick_fix_and_restart.sh"
        echo
    fi
    
    # Проверяем JSON
    if [[ -f "data/storage.json" ]] && ! python3 -c "import json; json.load(open('data/storage.json'))" 2>/dev/null; then
        echo "❌ База данных повреждена:"
        echo "   🔧 Решение: cp data/storage.json data/storage.json.backup && ./quick_fix_and_restart.sh"
        echo
    fi
    
    # Проверяем контейнеры
    local running_containers=0
    if command -v docker &>/dev/null; then
        local containers=("crypto_backend" "crypto_api" "crypto_dashboard")
        for container in "${containers[@]}"; do
            if docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
                ((running_containers++))
            fi
        done
        
        if [[ $running_containers -eq 0 ]]; then
            echo "❌ Все контейнеры остановлены:"
            echo "   🔧 Решение: docker-compose up -d"
            echo "   🔧 Альтернатива: ./launcher.sh"
            echo
        elif [[ $running_containers -lt 3 ]]; then
            echo "⚠️  Не все контейнеры запущены:"
            echo "   🔧 Решение: docker-compose restart"
            echo "   🔧 Если не помогает: ./quick_fix_and_restart.sh"
            echo
        fi
    fi
    
    # Проверяем API
    if ! curl -s --max-time 5 "http://localhost:8001/health" >/dev/null 2>&1; then
        echo "❌ API недоступен:"
        echo "   🔧 Решение: docker-compose restart crypto_api"
        echo "   🔧 Проверить логи: docker-compose logs crypto_api"
        echo
    fi
    
    # Проверяем место на диске
    local disk_usage=$(df -h . | awk 'NR==2 {print $5}' | tr -d '%')
    if [[ $disk_usage -gt 90 ]]; then
        echo "❌ Критически мало места на диске ($disk_usage%):"
        echo "   🔧 Очистить логи: rm -rf logs/*.log.* && docker system prune -f"
        echo "   🔧 Очистить резервные копии: rm -rf backups/*"
        echo "   🔧 Полная очистка Docker: docker system prune -af"
        echo
    fi
    
    # Общие рекомендации
    echo -e "${BOLD}🛠️  ОБЩИЕ ИНСТРУМЕНТЫ ДИАГНОСТИКИ:${NC}"
    echo "   📋 Просмотр логов:        docker-compose logs -f"
    echo "   🔄 Перезапуск системы:    docker-compose restart"
    echo "   🧹 Полная переустановка: ./quick_fix_and_restart.sh"
    echo "   🎛️  Интерактивное управление: ./launcher.sh"
    echo "   📊 Мониторинг ресурсов:   docker stats"
    echo "   🔍 Статус контейнеров:    docker-compose ps"
    echo
    
    echo -e "${BOLD}🌐 ПОЛЕЗНЫЕ ССЫЛКИ:${NC}"
    echo "   📰 Веб-интерфейс:         http://localhost:5001"
    echo "   📡 API документация:      http://localhost:8001/docs"
    echo "   💚 Health check:          http://localhost:8001/health"
    echo "   📊 Статистика:            http://localhost:8001/stats"
    echo "   🔧 Debug информация:      http://localhost:8001/debug/database"
}

# Создание отчета
create_report() {
    local report_file="diagnostic_report_$(date +%Y%m%d_%H%M%S).txt"
    
    log_step "Создаю отчет диагностики: $report_file"
    
    {
        echo "════════════════════════════════════════════════════════════════════"
        echo "ОТЧЕТ ДИАГНОСТИКИ CRYPTO NEWS AGGREGATOR"
        echo "════════════════════════════════════════════════════════════════════"
        echo "Версия: $SCRIPT_VERSION"
        echo "Автор: $SCRIPT_AUTHOR"
        echo "Создан: $SCRIPT_CREATED"
        echo "Пользователь: $SCRIPT_USER"
        echo "Время диагностики: $(date '+%Y-%m-%d %H:%M:%S UTC')"
        echo "Сервер: $(hostname)"
        echo "ОС: $(uname -a)"
        echo "════════════════════════════════════════════════════════════════════"
        echo
        
        # Файлы базы данных
        echo "1. ФАЙЛЫ БАЗЫ ДАННЫХ"
        echo "────────────────────"
        if [[ -f "data/storage.json" ]]; then
            echo "Файл базы данных: НАЙДЕН"
            echo "Размер: $(du -h data/storage.json | cut -f1)"
            echo "Дата изменения: $(ls -la data/storage.json | awk '{print $6, $7, $8}')"
            
            if python3 -c "import json; json.load(open('data/storage.json'))" 2>/dev/null; then
                echo "JSON валидность: ВАЛИДЕН"
                local articles_count=$(python3 -c "
import json
try:
    with open('data/storage.json') as f:
        data = json.load(f)
        articles = data.get('articles', {})
        total = 0
        for key, value in articles.items():
            if isinstance(value, list):
                total += len(value)
        print(total)
except:
    print('0')
" 2>/dev/null || echo "0")
                echo "Количество статей: $articles_count"
            else
                echo "JSON валидность: ПОВРЕЖДЕН"
            fi
        else
            echo "Файл базы данных: НЕ НАЙДЕН"
        fi
        echo
        
        # Docker контейнеры
        echo "2. DOCKER КОНТЕЙНЕРЫ"
        echo "──────────────────"
        if command -v docker &>/dev/null; then
            docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" --filter "name=crypto_" || echo "Контейнеры не найдены"
        else
            echo "Docker недоступен"
        fi
        echo
        
        # API статус
        echo "3. API СТАТУС"
        echo "─────────────"
        if curl -s --max-time 5 "http://localhost:8001/health" >/dev/null 2>&1; then
            echo "API Health: ДОСТУПЕН"
            curl -s --max-time 5 "http://localhost:8001/health" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(f'Статей в API: {data.get(\"articles_count\", \"неизвестно\")}')
    print(f'Время ответа: {data.get(\"timestamp\", \"неизвестно\")}')
except:
    print('Ошибка парсинга ответа API')
" 2>/dev/null || echo "Ошибка получения данных API"
        else
            echo "API Health: НЕДОСТУПЕН"
        fi
        echo
        
        # Системные ресурсы
        echo "4. СИСТЕМНЫЕ РЕСУРСЫ"
        echo "──────────────────"
        echo "Использование диска: $(df -h . | awk 'NR==2 {print $5}')"
        echo "Свободно места: $(df -h . | awk 'NR==2 {print $4}')"
        
        if [[ -d "logs" ]]; then
            echo "Размер логов: $(du -sh logs 2>/dev/null | cut -f1 || echo '0')"
        fi
        
        if [[ -d "backups" ]]; then
            local backups_count=$(ls backups/*.json 2>/dev/null | wc -l || echo "0")
            echo "Резервных копий: $backups_count"
        fi
        echo
        
        # Логи ошибок
        echo "5. АНАЛИЗ ЛОГОВ"
        echo "──────────────"
        for log_file in logs/*.log; do
            if [[ -f "$log_file" ]]; then
                local errors=$(grep -c "ERROR\|💥\|CRITICAL" "$log_file" 2>/dev/null || echo "0")
                local warnings=$(grep -c "WARNING\|⚠️\|WARN" "$log_file" 2>/dev/null || echo "0")
                echo "$(basename "$log_file"): Ошибок: $errors, Предупреждений: $warnings"
            fi
        done
        echo
        
        echo "════════════════════════════════════════════════════════════════════"
        echo "КОНЕЦ ОТЧЕТА"
        echo "════════════════════════════════════════════════════════════════════"
        
    } > "$report_file"
    
    log_success "Отчет создан: $report_file"
    
    # Показываем размер отчета
    local report_size=$(du -h "$report_file" | cut -f1)
    echo "  📄 Размер отчета: $report_size"
    
    # Предлагаем просмотреть отчет
    read -p "Просмотреть отчет? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cat "$report_file"
    fi
}

# Главная функция
main() {
    show_header
    
    log_step "Начинаю диагностику базы данных..."
    echo "Время начала: $(date '+%Y-%m-%d %H:%M:%S UTC')"
    echo "Пользователь: $SCRIPT_USER"
    echo
    
    # Выполняем все проверки
    check_database_files
    echo
    
    check_api_connection
    echo
    
    check_docker_containers
    echo
    
    analyze_logs
    echo
    
    check_performance
    echo
    
    show_recommendations
    
    # Предлагаем создать отчет
    echo
    read -p "Создать подробный отчет диагностики? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        create_report
    fi
    
    echo
    log_success "Диагностика завершена!"
    echo "Время завершения: $(date '+%Y-%m-%d %H:%M:%S UTC')"
}

# Обработка аргументов командной строки
case "${1:-}" in
    --help|-h)
        echo "Crypto News Aggregator - Database Diagnostic Script"
        echo "Version: $SCRIPT_VERSION"
        echo "Created: $SCRIPT_CREATED"
        echo "User: $SCRIPT_USER"
        echo
        echo "Выполняет полную диагностику базы данных и системы:"
        echo "• Проверка файлов базы данных"
        echo "• Валидация JSON структуры"
        echo "• Тестирование API подключения"
        echo "• Статус Docker контейнеров"
        echo "• Анализ логов на ошибки"
        echo "• Проверка производительности"
        echo "• Рекомендации по устранению проблем"
        echo "• Создание отчета диагностики"
        echo
        echo "Использование: $0 [--help|--version|--quick|--report-only]"
        echo
        echo "Опции:"
        echo "  --help        Показать справку"
        echo "  --version     Показать версию"
        echo "  --quick       Быстрая проверка (только критичные тесты)"
        echo "  --report-only Создать только отчет без интерактивности"
        exit 0
        ;;
    --version|-v)
        echo "Database Diagnostic Script v$SCRIPT_VERSION"
        echo "Created: $SCRIPT_CREATED"
        echo "Author: $SCRIPT_AUTHOR"
        echo "User: $SCRIPT_USER"
        exit 0
        ;;
    --quick)
        show_header
        log_step "Быстрая диагностика..."
        check_database_files
        check_api_connection
        check_docker_containers
        log_success "Быстрая диагностика завершена"
        exit 0
        ;;
    --report-only)
        show_header
        log_step "Создание отчета диагностики..."
        check_database_files >/dev/null 2>&1
        check_api_connection >/dev/null 2>&1
        check_docker_containers >/dev/null 2>&1
        analyze_logs >/dev/null 2>&1
        check_performance >/dev/null 2>&1
        create_report
        exit 0
        ;;
    "")
        main
        ;;
    *)
        log_error "Неизвестный аргумент: $1"
        echo "Используйте $0 --help для справки"
        exit 1
        ;;
esac