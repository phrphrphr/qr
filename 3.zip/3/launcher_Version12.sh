#!/bin/bash

# Crypto News Aggregator - Working Launcher
# Created: 2025-06-18 20:18:20 UTC
# User: phrphrphr
# Version: 3.0.0

set -euo pipefail

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m'

# Переходим в директорию скрипта
cd "$(dirname "$0")"

# Функции логирования
log_info() { echo -e "${GREEN}✅ $1${NC}"; }
log_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_step() { echo -e "${BLUE}🔧 $1${NC}"; }
log_success() { echo -e "${PURPLE}🎉 $1${NC}"; }

# Показать заголовок
show_header() {
    local server_ip=$(hostname -I | awk '{print $1}' 2>/dev/null || echo "localhost")
    
    clear
    echo -e "${CYAN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                🚀 CRYPTO NEWS AGGREGATOR v3.0.0 🚀               ║"
    echo "║                     РАБОЧИЙ ЛАУНЧЕР                              ║"
    echo "║                                                                  ║"
    echo "║  Создан: 2025-06-18 20:18:20 UTC                                ║"
    echo "║  Автор: phrphrphr                                                ║"
    echo "║  Пользователь: phrphrphr                                         ║"
    echo "║  Сервер: ${server_ip}                                           ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}\n"
}

# Проверка Docker
check_docker() {
    if ! command -v docker &> /dev/null; then
        log_error "Docker не установлен!"
        echo "Установите Docker: https://docs.docker.com/get-docker/"
        exit 1
    fi

    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose не установлен!"
        echo "Установите Docker Compose: https://docs.docker.com/compose/install/"
        exit 1
    fi

    if ! docker info &> /dev/null; then
        log_error "Docker daemon не запущен!"
        echo "Запустите Docker daemon"
        exit 1
    fi

    log_info "Docker готов к работе"
}

# Создание необходимых файлов
ensure_files() {
    log_step "Проверяю необходимые файлы..."
    
    # Создаем директории
    mkdir -p data logs backups

    # Создаем .env если нет
    if [ ! -f ".env" ]; then
        log_step "Создаю .env файл..."
        cat > .env << 'EOF'
# Crypto News Aggregator Configuration
# Created: 2025-06-18 20:18:20 UTC
# User: phrphrphr

FLASK_APP=dashboard.py
FLASK_ENV=production
DB_PATH=data/storage.json
PARSING_INTERVAL_SECONDS=1800
RSS_FEEDS=https://cointelegraph.com/rss,https://www.coindesk.com/arc/outboundfeeds/rss/,https://forklog.com/feed/
LOG_LEVEL=INFO
API_HOST=0.0.0.0
API_PORT=8001
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=5001
API_URL=http://api:8001
PROJECT_VERSION=3.0.0
PROJECT_AUTHOR=phrphrphr
PROJECT_CREATED=2025-06-18
EOF
        log_info ".env файл создан"
    fi

    # Создаем базу данных если нет
    if [ ! -f "data/storage.json" ]; then
        log_step "Создаю базу данных..."
        cat > data/storage.json << 'EOF'
{
  "_default": {},
  "articles": {
    "1": []
  }
}
EOF
        log_info "База данных создана"
    fi

    # Проверяем docker-compose.yml
    if [ ! -f "docker-compose.yml" ]; then
        log_error "docker-compose.yml не найден! Создайте файл конфигурации Docker"
        exit 1
    fi

    log_info "Все файлы готовы"
}

# Полная остановка всех контейнеров
full_stop() {
    log_step "Останавливаю ВСЕ контейнеры проекта..."
    
    # Останавливаем через docker-compose
    docker-compose down --remove-orphans --volumes 2>/dev/null || true
    
    # Находим и останавливаем ВСЕ crypto контейнеры
    local crypto_containers=$(docker ps -aq --filter "name=crypto" 2>/dev/null || true)
    if [ -n "$crypto_containers" ]; then
        echo "$crypto_containers" | xargs docker stop 2>/dev/null || true
        echo "$crypto_containers" | xargs docker rm -f 2>/dev/null || true
    fi
    
    # Контейнеры по образам
    local image_containers=$(docker ps -aq --filter "ancestor=crypto_news_aggregator-api" --filter "ancestor=crypto_news_aggregator-backend" --filter "ancestor=crypto_news_aggregator-dashboard" 2>/dev/null || true)
    if [ -n "$image_containers" ]; then
        echo "$image_containers" | xargs docker stop 2>/dev/null || true
        echo "$image_containers" | xargs docker rm -f 2>/dev/null || true
    fi
    
    # Удаляем сеть
    docker network rm crypto_network 2>/dev/null || true
    
    log_info "Все контейнеры остановлены"
}

# Проверка портов
check_ports() {
    log_step "Проверяю порты 8001 и 5001..."
    
    local busy_ports=()
    
    if lsof -Pi :8001 -sTCP:LISTEN -t >/dev/null 2>&1; then
        busy_ports+=(8001)
    fi
    
    if lsof -Pi :5001 -sTCP:LISTEN -t >/dev/null 2>&1; then
        busy_ports+=(5001)
    fi
    
    if [ ${#busy_ports[@]} -ne 0 ]; then
        log_warn "Заняты порты: ${busy_ports[*]}"
        log_step "Освобождаю порты..."
        
        for port in "${busy_ports[@]}"; do
            local pids=$(lsof -Pi :$port -sTCP:LISTEN -t 2>/dev/null || true)
            if [ -n "$pids" ]; then
                echo "$pids" | xargs kill -9 2>/dev/null || true
                log_info "Порт $port освобожден"
            fi
        done
    fi
}

# Запуск системы
start_system() {
    log_step "Запускаю систему..."
    
    # Полная остановка перед запуском
    full_stop
    
    # Освобождаем порты
    check_ports
    
    # Собираем и запускаем
    log_step "Сборка образов..."
    if ! docker-compose build --no-cache; then
        log_error "Ошибка сборки образов!"
        return 1
    fi
    
    log_step "Запуск контейнеров..."
    if ! docker-compose up -d --force-recreate; then
        log_error "Ошибка запуска контейнеров!"
        docker-compose logs
        return 1
    fi
    
    # Ждем готовности
    log_step "Ожидание готовности сервисов (60 сек)..."
    local max_wait=60
    local wait_time=0
    
    while [ $wait_time -lt $max_wait ]; do
        local api_ready=false
        local dashboard_ready=false
        
        if curl -sf http://localhost:8001/health >/dev/null 2>&1; then
            api_ready=true
        fi
        
        if curl -sf http://localhost:5001/health >/dev/null 2>&1; then
            dashboard_ready=true
        fi
        
        echo -ne "\r  ⏳ API: $([ "$api_ready" = true ] && echo "✅" || echo "❌") Dashboard: $([ "$dashboard_ready" = true ] && echo "✅" || echo "❌") (${wait_time}s)"
        
        if [ "$api_ready" = true ] && [ "$dashboard_ready" = true ]; then
            echo
            log_success "Все сервисы готовы!"
            return 0
        fi
        
        sleep 2
        ((wait_time += 2))
    done
    
    echo
    log_error "Не все сервисы запустились за ${max_wait} секунд"
    return 1
}

# Проверка статуса
check_status() {
    log_step "Проверяю статус системы..."
    
    local containers=("crypto_backend" "crypto_api" "crypto_dashboard")
    local running=0
    
    echo -e "\n${BOLD}Статус контейнеров:${NC}"
    for container in "${containers[@]}"; do
        if docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
            echo -e "  ${GREEN}✅ $container${NC} - запущен"
            ((running++))
        else
            echo -e "  ${RED}❌ $container${NC} - остановлен"
        fi
    done
    
    echo -e "\n${BOLD}Статус сервисов:${NC}"
    if curl -sf http://localhost:8001/health >/dev/null 2>&1; then
        echo -e "  ${GREEN}✅ API (8001)${NC} - доступен"
    else
        echo -e "  ${RED}❌ API (8001)${NC} - недоступен"
    fi
    
    if curl -sf http://localhost:5001/health >/dev/null 2>&1; then
        echo -e "  ${GREEN}✅ Dashboard (5001)${NC} - доступен"
    else
        echo -e "  ${RED}❌ Dashboard (5001)${NC} - недоступен"
    fi
    
    echo -e "\nЗапущено: $running/3 контейнеров"
    
    if [ $running -eq 3 ]; then
        return 0
    else
        return 1
    fi
}

# Показать URLs
show_urls() {
    local server_ip=$(hostname -I | awk '{print $1}' 2>/dev/null || echo "localhost")
    
    echo -e "\n${BOLD}🌐 Адреса для доступа:${NC}"
    echo -e "  📰 Веб-интерфейс:    ${WHITE}http://${server_ip}:5001${NC}"
    echo -e "  📡 REST API:         ${WHITE}http://${server_ip}:8001${NC}"
    echo -e "  📖 Документация API: ${WHITE}http://${server_ip}:8001/docs${NC}"
    echo -e "  📚 ReDoc:            ${WHITE}http://${server_ip}:8001/redoc${NC}"
    echo -e "  💚 Health Check:     ${WHITE}http://${server_ip}:8001/health${NC}"
}

# Показать логи
show_logs() {
    echo -e "\n${BOLD}Выберите контейнер:${NC}"
    echo "  1) Backend"
    echo "  2) API" 
    echo "  3) Dashboard"
    echo "  4) Все"
    echo "  0) Назад"
    
    read -p "Ваш выбор: " choice
    
    case $choice in
        1) docker-compose logs -f crypto_backend ;;
        2) docker-compose logs -f crypto_api ;;
        3) docker-compose logs -f crypto_dashboard ;;
        4) docker-compose logs -f ;;
        0) return ;;
        *) log_error "Неверный выбор" ;;
    esac
}

# Полная переустановка
full_reinstall() {
    echo -e "${YELLOW}⚠️  Это удалит ВСЕ данные и контейнеры!${NC}"
    read -p "Продолжить? (yes/no): " confirm
    
    if [[ "$confirm" != "yes" ]]; then
        log_info "Переустановка отменена"
        return
    fi
    
    log_step "Полная переустановка..."
    
    # Останавливаем все
    full_stop
    
    # Удаляем образы
    docker rmi -f $(docker images -q "*crypto*") 2>/dev/null || true
    
    # Очищаем данные
    rm -rf data/* logs/* 2>/dev/null || true
    
    # Пересоздаем файлы
    ensure_files
    
    # Запускаем
    if start_system; then
        log_success "Переустановка завершена!"
        show_urls
    else
        log_error "Ошибка переустановки"
    fi
}

# Главное меню
main_menu() {
    while true; do
        show_header
        
        # Быстрая проверка статуса
        if check_status >/dev/null 2>&1; then
            echo -e "${GREEN}🟢 Система запущена${NC}"
            show_urls
        else
            echo -e "${RED}🔴 Система остановлена${NC}"
        fi
        
        echo -e "\n${BOLD}📋 ГЛАВНОЕ МЕНЮ${NC}"
        echo "  1) 🚀 ЗАПУСТИТЬ систему"
        echo "  2) ⏹️  ОСТАНОВИТЬ систему"
        echo "  3) 🔄 ПЕРЕЗАПУСТИТЬ систему"
        echo "  4) 📊 СТАТУС системы"
        echo "  5) 📋 ЛОГИ контейнеров"
        echo "  6) 🧹 ПОЛНАЯ ПЕРЕУСТАНОВКА"
        echo "  7) 🌐 ОТКРЫТЬ веб-интерфейс"
        echo "  0) 🚪 ВЫХОД"
        
        read -p $'\nВаш выбор: ' choice
        
        case $choice in
            1)
                if start_system; then
                    log_success "Система запущена!"
                    show_urls
                    
                    read -p "Открыть веб-интерфейс? (y/n): " open_web
                    if [[ "$open_web" =~ ^[Yy]$ ]]; then
                        if command -v xdg-open &>/dev/null; then
                            xdg-open "http://localhost:5001" 2>/dev/null &
                        elif command -v open &>/dev/null; then
                            open "http://localhost:5001" 2>/dev/null &
                        fi
                    fi
                else
                    log_error "Ошибка запуска системы"
                    echo -e "\n${BOLD}Логи ошибок:${NC}"
                    docker-compose logs --tail=20
                fi
                read -p "Нажмите Enter..."
                ;;
            2)
                full_stop
                log_success "Система остановлена"
                read -p "Нажмите Enter..."
                ;;
            3)
                log_step "Перезапускаю систему..."
                full_stop
                if start_system; then
                    log_success "Система перезапущена!"
                    show_urls
                else
                    log_error "Ошибка перезапуска"
                fi
                read -p "Нажмите Enter..."
                ;;
            4)
                check_status
                echo -e "\n${BOLD}Docker контейнеры:${NC}"
                docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" --filter "name=crypto"
                read -p "Нажмите Enter..."
                ;;
            5)
                show_logs
                ;;
            6)
                full_reinstall
                read -p "Нажмите Enter..."
                ;;
            7)
                if command -v xdg-open &>/dev/null; then
                    xdg-open "http://localhost:5001" 2>/dev/null &
                    log_info "Веб-интерфейс открыт в браузере"
                elif command -v open &>/dev/null; then
                    open "http://localhost:5001" 2>/dev/null &
                    log_info "Веб-интерфейс открыт в браузере"
                else
                    echo "Откройте http://localhost:5001 в браузере"
                fi
                read -p "Нажмите Enter..."
                ;;
            0)
                log_info "Выход из лаунчера"
                exit 0
                ;;
            *)
                log_error "Неверный выбор"
                read -p "Нажмите Enter..."
                ;;
        esac
    done
}

# Быстрые команды
case "${1:-}" in
    start)
        check_docker
        ensure_files
        start_system && show_urls
        ;;
    stop)
        full_stop
        ;;
    status)
        check_status
        ;;
    logs)
        docker-compose logs -f
        ;;
    restart)
        check_docker
        ensure_files
        full_stop
        start_system && show_urls
        ;;
    reinstall)
        check_docker
        full_reinstall
        ;;
    *)
        # Интерактивный режим
        check_docker
        ensure_files
        main_menu
        ;;
esac