# ... (предыдущий код остается)

# Исправленная функция остановки контейнеров  
stop_containers() {
    log_step "Останавливаю все контейнеры..."
    
    # 1. Останавливаем через docker-compose
    docker-compose down --remove-orphans --volumes 2>/dev/null || true
    
    # 2. Находим и останавливаем ВСЕ контейнеры проекта
    local all_crypto_containers=$(docker ps -aq --filter "name=crypto" 2>/dev/null || true)
    if [ -n "$all_crypto_containers" ]; then
        log_step "Принудительно останавливаю все crypto контейнеры..."
        echo "$all_crypto_containers" | xargs docker stop 2>/dev/null || true
        echo "$all_crypto_containers" | xargs docker rm -f 2>/dev/null || true
    fi
    
    # 3. Находим контейнеры по образам
    local crypto_images=$(docker ps -aq --filter "ancestor=crypto_news_aggregator-api" --filter "ancestor=crypto_news_aggregator-backend" --filter "ancestor=crypto_news_aggregator-dashboard" 2>/dev/null || true)
    if [ -n "$crypto_images" ]; then
        log_step "Останавливаю контейнеры по образам..."
        echo "$crypto_images" | xargs docker stop 2>/dev/null || true
        echo "$crypto_images" | xargs docker rm -f 2>/dev/null || true
    fi
    
    # 4. Удаляем сети
    docker network rm crypto_network 2>/dev/null || true
    
    # 5. Очищаем неиспользуемые ресурсы
    docker system prune -f 2>/dev/null || true
    
    log_info "Все контейнеры остановлены и очищены"
}

# Исправленная функция сборки и запуска
build_and_start() {
    log_step "Собираю и запускаю контейнеры..."
    
    # Убеждаемся что все старые контейнеры удалены
    stop_containers
    
    # Пересобираем образы с нуля
    log_step "Пересборка образов..."
    if docker-compose build --no-cache --pull; then
        log_info "Образы пересобраны"
    else
        log_error "Ошибка сборки образов"
        
        # Показываем логи сборки
        echo -e "\n${BOLD}Логи сборки:${NC}"
        docker-compose build --no-cache 2>&1 | tail -20
        return 1
    fi
    
    # Запускаем контейнеры
    log_step "Запуск контейнеров..."
    if docker-compose up -d --force-recreate --remove-orphans; then
        log_info "Контейнеры запущены"
    else
        log_error "Ошибка запуска контейнеров"
        
        # Показываем логи запуска
        echo -e "\n${BOLD}Логи запуска:${NC}"
        docker-compose logs --tail=20
        return 1
    fi
    
    # Ждем запуска сервисов с прогресс-баром
    log_step "Ожидание готовности сервисов..."
    local max_wait=60
    local wait_time=0
    
    while [ $wait_time -lt $max_wait ]; do
        local ready_count=0
        
        # Проверяем каждый контейнер
        if docker ps --format "table {{.Names}}" | grep -q "^crypto_backend$"; then
            ((ready_count++))
        fi
        
        if docker ps --format "table {{.Names}}" | grep -q "^crypto_api$"; then
            if curl -sf http://localhost:8001/health >/dev/null 2>&1; then
                ((ready_count++))
            fi
        fi
        
        if docker ps --format "table {{.Names}}" | grep -q "^crypto_dashboard$"; then
            if curl -sf http://localhost:5001/health >/dev/null 2>&1; then
                ((ready_count++))
            fi
        fi
        
        # Показываем прогресс
        echo -ne "\r  ⏳ Готово сервисов: $ready_count/3 (${wait_time}s/${max_wait}s)"
        
        if [ $ready_count -eq 3 ]; then
            echo -e "\n"
            break
        fi
        
        sleep 2
        ((wait_time += 2))
    done
    
    # Финальная проверка
    local containers=("crypto_backend" "crypto_api" "crypto_dashboard")
    local running_count=0
    
    echo -e "\n${BOLD}Финальная проверка:${NC}"
    for container in "${containers[@]}"; do
        if docker ps --format "table {{.Names}}" | grep -q "^${container}$"; then
            log_info "✅ $container - запущен"
            ((running_count++))
        else
            log_error "❌ $container - не запущен"
            
            # Показываем логи проблемного контейнера
            echo -e "\n${BOLD}Логи $container:${NC}"
            docker logs "$container" 2>&1 | tail -10 | sed 's/^/  /'
        fi
    done
    
    if [ $running_count -eq ${#containers[@]} ]; then
        log_success "Все контейнеры успешно запущены!"
        return 0
    else
        log_error "Не все контейнеры запущены ($running_count/${#containers[@]})"
        return 1
    fi
}