"""
Crypto News Aggregator - Backend Main
Created: 2025-06-18 19:13:42 UTC
User: phrphrphr
Version: 3.0.0

Основной модуль фонового парсера RSS лент
"""

import asyncio
import signal
import sys
import os
from pathlib import Path
import time

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

print(f"🚀 Backend запускается...")
print(f"⏰ Время: 2025-06-18 19:13:42 UTC")
print(f"👤 Пользователь: phrphrphr")
print(f"📁 Рабочая директория: {os.getcwd()}")
print(f"🐍 Python версия: {sys.version}")

# Настраиваем базовое логирование сначала
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)-12s | %(levelname)-8s | %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("backend")

try:
    # Создаем директории
    os.makedirs("data", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    logger.info("📁 Директории созданы")
    
    # Настраиваем продвинутое логирование
    from utils.logging import setup_logging
    setup_logging()
    from loguru import logger
    logger.info("✅ Продвинутое логирование настроено")
except ImportError as e:
    logger.error(f"⚠️ Не удалось настроить loguru: {e}, используем стандартное логирование")

try:
    from core.config import settings
    logger.info(f"✅ Конфигурация загружена: {len(settings.rss_feeds)} RSS лент")
    logger.info(f"📊 Интервал парсинга: {settings.parsing_interval_seconds} секунд")
    logger.info(f"💾 База данных: {settings.db_path}")
except ImportError as e:
    logger.error(f"💥 Ошибка импорта конфигурации: {e}")
    sys.exit(1)

try:
    from core.dispatcher import dispatcher
    logger.info("✅ Диспетчер инициализирован")
except ImportError as e:
    logger.error(f"💥 Ошибка импорта диспетчера: {e}")
    sys.exit(1)

try:
    from core.storage import storage
    logger.info(f"✅ Хранилище инициализировано: {storage.get_articles_count()} статей")
except ImportError as e:
    logger.error(f"💥 Ошибка импорта хранилища: {e}")
    sys.exit(1)

class GracefulExit:
    """Класс для корректного завершения работы"""
    
    def __init__(self):
        self.exit_now = False
        signal.signal(signal.SIGINT, self._exit_gracefully)
        signal.signal(signal.SIGTERM, self._exit_gracefully)

    def _exit_gracefully(self, signum, frame):
        logger.info(f"🛑 Получен сигнал {signum}, начинаю graceful shutdown")
        self.exit_now = True

async def main_loop():
    """Основной цикл парсера"""
    logger.info("🚀 Запуск фонового парсера криптоновостей")
    logger.info(f"📡 RSS лент для мониторинга: {len(settings.rss_feeds)}")
    
    exit_handler = GracefulExit()
    
    # Ждем немного для инициализации других сервисов
    logger.info("⏳ Ожидание инициализации системы...")
    await asyncio.sleep(10)
    
    # Первый запуск сразу
    try:
        logger.info("🔄 Начинаю первый парсинг...")
        result = await dispatcher.run_all_parsers()
        
        if result.get('status') == 'completed':
            logger.info(f"🎯 Первый парсинг завершен успешно:")
            logger.info(f"   📰 Добавлено новых статей: {result.get('articles_new', 0)}")
            logger.info(f"   📊 Всего статей в базе: {result.get('articles_total', 0)}")
            logger.info(f"   ⏱️ Время выполнения: {result.get('execution_time', 0):.2f}s")
        else:
            logger.warning(f"⚠️ Первый парсинг завершен с предупреждениями: {result.get('status')}")
        
    except Exception as e:
        logger.error(f"💥 Ошибка при первом запуске: {e}")
        # Не завершаем работу, продолжаем
    
    # Основной цикл
    cycle_count = 0
    while not exit_handler.exit_now:
        try:
            cycle_count += 1
            logger.info(f"⏰ Цикл #{cycle_count}: Ожидание {settings.parsing_interval_seconds} секунд до следующего парсинга")
            
            # Ждем с проверкой сигнала остановки каждые 10 секунд
            for i in range(0, settings.parsing_interval_seconds, 10):
                if exit_handler.exit_now:
                    break
                await asyncio.sleep(min(10, settings.parsing_interval_seconds - i))
            
            if not exit_handler.exit_now:
                try:
                    logger.info(f"🔄 Начинаю парсинг (цикл #{cycle_count})...")
                    result = await dispatcher.run_all_parsers()
                    
                    if result.get('status') == 'completed':
                        logger.info(f"🎯 Парсинг #{cycle_count} завершен:")
                        logger.info(f"   📰 Новых статей: {result.get('articles_new', 0)}")
                        logger.info(f"   📊 Всего в базе: {result.get('articles_total', 0)}")
                        logger.info(f"   ⏱️ Время: {result.get('execution_time', 0):.2f}s")
                        logger.info(f"   📡 Обработано лент: {result.get('feeds_processed', 0)}/{len(settings.rss_feeds)}")
                    else:
                        logger.warning(f"⚠️ Парсинг #{cycle_count} завершен с ошибками: {result.get('status')}")
                        
                except Exception as e:
                    logger.error(f"💥 Ошибка при парсинге (цикл #{cycle_count}): {e}")
                
        except Exception as e:
            logger.error(f"💥 Ошибка в основном цикле: {e}")
            if not exit_handler.exit_now:
                logger.info("⏳ Ожидание 60 секунд перед повтором...")
                await asyncio.sleep(60)
    
    logger.info("✅ Парсер корректно остановлен")

if __name__ == "__main__":
    try:
        # Проверяем наличие .env файла
        if not os.path.exists('.env'):
            logger.warning("⚠️ .env файл не найден, будут использованы значения по умолчанию")
        
        # Запускаем основной цикл
        logger.info("🎬 Запускаю главный цикл...")
        asyncio.run(main_loop())
        
    except KeyboardInterrupt:
        logger.info("🛑 Остановка по Ctrl+C")
    except Exception as e:
        logger.error(f"💥 Критическая ошибка: {e}")
        import traceback
        logger.error(f"Stack trace: {traceback.format_exc()}")
        sys.exit(1)